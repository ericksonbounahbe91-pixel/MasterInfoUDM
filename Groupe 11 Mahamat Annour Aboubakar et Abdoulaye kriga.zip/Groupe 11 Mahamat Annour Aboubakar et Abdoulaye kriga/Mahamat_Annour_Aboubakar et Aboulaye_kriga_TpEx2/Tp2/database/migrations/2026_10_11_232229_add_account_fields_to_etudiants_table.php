
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('etudiants', function (Blueprint $table) {
            $table->foreignId('user_id')
                ->nullable()
                ->unique()
                ->constrained('users')
                ->nullOnDelete();

            $table->string('matricule')->nullable()->unique();
            $table->date('date_naissance')->nullable();
            $table->string('telephone')->nullable();
            $table->string('faculte')->nullable();
            $table->string('filiere')->nullable();
            $table->string('niveau')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('etudiants', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->dropUnique(['user_id']);
            $table->dropUnique(['matricule']);

            $table->dropColumn([
                'user_id',
                'matricule',
                'date_naissance',
                'telephone',
                'faculte',
                'filiere',
                'niveau',
            ]);
        });
    }
};
