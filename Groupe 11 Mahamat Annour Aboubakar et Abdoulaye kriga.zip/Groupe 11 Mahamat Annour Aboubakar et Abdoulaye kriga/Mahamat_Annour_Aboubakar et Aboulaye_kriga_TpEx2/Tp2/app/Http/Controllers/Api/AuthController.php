<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Etudiant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $donnees = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'matricule' => 'required|string|max:100|unique:etudiants,matricule',
            'date_naissance' => 'required|date|before:today',
            'telephone' => 'required|string|max:30',
            'faculte' => 'required|string|max:255',
            'filiere' => 'required|string|max:255',
            'niveau' => 'required|string|max:100',
            'email' => 'required|email|max:255|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = DB::transaction(function () use ($donnees) {
            $user = new User();
            $user->name = $donnees['prenom'] . ' ' . $donnees['nom'];
            $user->email = $donnees['email'];
            $user->password = Hash::make($donnees['password']);
            $user->statut_compte = 'en_attente';
            $user->save();

            Etudiant::create([
                'user_id' => $user->id,
                'nom' => $donnees['nom'],
                'prenom' => $donnees['prenom'],
                'email' => $donnees['email'],
                'matricule' => $donnees['matricule'],
                'date_naissance' => $donnees['date_naissance'],
                'telephone' => $donnees['telephone'],
                'faculte' => $donnees['faculte'],
                'filiere' => $donnees['filiere'],
                'niveau' => $donnees['niveau'],
            ]);

            return $user;
        });

        return response()->json([
            'message' => 'Demande d’inscription envoyée. Votre compte est en attente de validation par l’administration.',
            'statut_compte' => $user->statut_compte,
            'etudiant' => [
                'nom' => $donnees['nom'],
                'prenom' => $donnees['prenom'],
                'matricule' => $donnees['matricule'],
                'email' => $donnees['email'],
            ],
        ], 201);
    }

    public function login(Request $request)
    {
        $donnees = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $donnees['email'])->first();

        if (!$user || !Hash::check($donnees['password'], $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['Adresse e-mail ou mot de passe incorrecte.'],
            ]);
        }

        if ($user->statut_compte !== 'approuve') {
            return response()->json([
                'message' => 'Votre compte est en attente de validation par l’administration.',
                'statut_compte' => $user->statut_compte,
            ], 403);
        }

        $token = $user->createToken('application-mobile')->plainTextToken;

        return response()->json([
            'message' => 'Connexion réussie.',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
        ]);
    }

    public function me(Request $request)
    {
        return response()->json([
            'user' => $request->user(),
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json([
            'message' => 'Déconnexion réussie.',
        ]);
    }
}
