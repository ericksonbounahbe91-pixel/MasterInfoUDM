<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Etudiant;
use App\Models\User;
use Illuminate\Http\RedirectResponse;

class AdminController extends Controller
{
    public function index()
    {
        $utilisateurs = User::where('statut_compte', 'en_attente')
            ->orderBy('created_at', 'desc')
            ->get();

        $totalEnAttente = User::where('statut_compte', 'en_attente')->count();
        $totalApprouves = User::where('statut_compte', 'approuve')->count();
        $totalRefuses = User::where('statut_compte', 'refuse')->count();

        return view('admin.index', compact(
            'utilisateurs',
            'totalEnAttente',
            'totalApprouves',
            'totalRefuses'
        ));
    }

    public function approuver(User $user): RedirectResponse
    {
        if ($user->statut_compte !== 'en_attente') {
            return redirect()->route('admin.index')
                ->with('error', 'Cette demande a déjà été traitée.');
        }

        $dossierExiste = Etudiant::where('user_id', $user->id)->exists();

        if (!$dossierExiste) {
            return redirect()->route('admin.index')
                ->with('error', 'Impossible d’approuver : le dossier étudiant associé est introuvable.');
        }

        $user->statut_compte = 'approuve';
        $user->save();

        return redirect()->route('admin.index')
            ->with('success', 'Le compte a été approuvé.');
    }

    public function refuser(User $user): RedirectResponse
    {
        if ($user->statut_compte !== 'en_attente') {
            return redirect()->route('admin.index')
                ->with('error', 'Cette demande a déjà été traitée.');
        }

        $user->statut_compte = 'refuse';
        $user->save();

        return redirect()->route('admin.index')
            ->with('success', 'La demande a été refusée. Les données sont conservées.');
    }
}
