<?php

namespace App\Http\Controllers;

use App\Models\Etudiant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function showInscription()
    {
        return view('auth.inscription');
    }

    public function inscription(Request $request)
    {
        $donnees = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'matricule' => 'required|string|max:100|unique:etudiants,matricule',
            'date_naissance' => 'required|date|before:today',
            'telephone' => 'required|string|max:30',
            'faculte' => 'required|string|max:255',
            'filiere' => 'required|string|max:255',
            'niveau' => 'required|string|max:100',
            'email' => 'required|email|max:255|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        DB::transaction(function () use ($donnees) {
            $user = User::create([
                'name' => $donnees['prenom'] . ' ' . $donnees['nom'],
                'email' => $donnees['email'],
                'password' => $donnees['password'],
            ]);

            Etudiant::create([
                'user_id' => $user->id,
                'nom' => $donnees['nom'],
                'prenom' => $donnees['prenom'],
                'matricule' => $donnees['matricule'],
                'date_naissance' => $donnees['date_naissance'],
                'telephone' => $donnees['telephone'],
                'faculte' => $donnees['faculte'],
                'filiere' => $donnees['filiere'],
                'niveau' => $donnees['niveau'],
                'email' => $donnees['email'],
            ]);
        });

        return redirect()
            ->route('connexion')
            ->with('success', 'Inscription réussie ! Vous pouvez maintenant vous connecter.');
    }


    public function showConnexion()
    {
        return view('auth.connexion');
    }

    public function connexion(Request $request)
    {
        $identifiants = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if (!\Illuminate\Support\Facades\Auth::attempt($identifiants)) {
            return back()
                ->withErrors([
                    'email' => 'Adresse e-mail ou mot de passe incorrect.',
                ])
                ->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()->route('etudiant.dashboard');
    }

    public function deconnexion(Request $request)
    {
        \Illuminate\Support\Facades\Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('connexion');
    }

    public function dashboard()
    {
        $etudiant = \App\Models\Etudiant::where(
            'user_id',
            auth()->id()
        )->firstOrFail();

        return view('auth.dashboard', compact('etudiant'));
    }

}
