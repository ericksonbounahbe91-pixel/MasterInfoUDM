<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Gestion des étudiants</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #064b9b;
            color: white;
            padding: 22px 6%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            font-size: 23px;
        }

        header p {
            margin: 7px 0 0;
            color: #dbeafe;
        }

        .btn-deconnexion {
            background: white;
            color: #064b9b;
            padding: 10px 16px;
            border: none;
            border-radius: 7px;
            font-weight: bold;
            cursor: pointer;
        }

        main {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .bienvenue {
            margin-bottom: 25px;
        }

        .bienvenue h2 {
            margin-bottom: 8px;
            font-size: 25px;
        }

        .bienvenue p {
            color: #64748b;
            margin-top: 0;
        }

        .statistiques {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .carte {
            background: white;
            padding: 23px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05);
            border-left: 5px solid #2563eb;
        }

        .carte h3 {
            margin: 0 0 14px;
            font-size: 15px;
            color: #64748b;
        }

        .nombre {
            font-size: 32px;
            font-weight: bold;
        }

        .attente {
            border-left-color: #f59e0b;
        }

        .approuves {
            border-left-color: #16a34a;
        }

        .refuses {
            border-left-color: #dc2626;
        }

        .section {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05);
        }

        .section h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        .message {
            padding: 13px 16px;
            margin-bottom: 20px;
            border-radius: 7px;
        }

        .succes {
            background: #dcfce7;
            color: #166534;
        }

        .erreur {
            background: #fee2e2;
            color: #991b1b;
        }

        .table-conteneur {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        th, td {
            text-align: left;
            padding: 14px 12px;
            border-bottom: 1px solid #e2e8f0;
        }

        th {
            background: #f8fafc;
            color: #475569;
            font-size: 13px;
        }

        .badge-attente {
            background: #fef3c7;
            color: #92400e;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .actions {
            display: flex;
            gap: 8px;
        }

        .btn {
            border: none;
            border-radius: 6px;
            padding: 9px 11px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-approuver {
            background: #16a34a;
        }

        .btn-refuser {
            background: #dc2626;
        }

        .vide {
            text-align: center;
            padding: 35px 15px;
            color: #64748b;
        }

        footer {
            text-align: center;
            color: #64748b;
            padding: 20px;
            font-size: 13px;
        }

        @media (max-width: 750px) {
            .statistiques {
                grid-template-columns: 1fr;
            }

            header h1 {
                font-size: 19px;
            }

            .section {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>Administration des étudiants</h1>
        <p>Gestion des demandes d'inscription</p>
    </div>

    <form action="{{ route('deconnexion') }}" method="POST">
        @csrf
        <button class="btn-deconnexion" type="submit">
            Déconnexion
        </button>
    </form>
</header>

<main>
    <div class="bienvenue">
        <h2>Tableau de bord</h2>
        <p>Suivez les inscriptions et gérez les demandes des étudiants.</p>
    </div>

    @if (session('success'))
        <div class="message succes">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="message erreur">
            {{ session('error') }}
        </div>
    @endif

    <div class="statistiques">
        <div class="carte attente">
            <h3>Demandes en attente</h3>
            <div class="nombre">{{ $totalEnAttente }}</div>
        </div>

        <div class="carte approuves">
            <h3>Comptes approuvés</h3>
            <div class="nombre">{{ $totalApprouves }}</div>
        </div>

        <div class="carte refuses">
            <h3>Comptes refusés</h3>
            <div class="nombre">{{ $totalRefuses }}</div>
        </div>
    </div>

    <section class="section">
        <h2>Demandes d'inscription en attente</h2>

        @if ($utilisateurs->isEmpty())
            <div class="vide">
                <h3>Aucune demande en attente</h3>
                <p>Les nouvelles inscriptions apparaîtront ici.</p>
            </div>
        @else
            <div class="table-conteneur">
                <table>
                    <thead>
                        <tr>
                            <th>Nom de l'étudiant</th>
                            <th>E-mail</th>
                            <th>Statut</th>
                            <th>Date d'inscription</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        @foreach ($utilisateurs as $utilisateur)
                            <tr>
                                <td>{{ $utilisateur->name }}</td>
                                <td>{{ $utilisateur->email }}</td>
                                <td>
                                    <span class="badge-attente">
                                        En attente
                                    </span>
                                </td>
                                <td>
                                    {{ $utilisateur->created_at?->format('d/m/Y H:i') }}
                                </td>
                                <td>
                                    <div class="actions">
                                        <form
                                            action="{{ route('admin.approuver', $utilisateur->id) }}"
                                            method="POST">
                                            @csrf
                                            @method('PATCH')

                                            <button
                                                type="submit"
                                                class="btn btn-approuver">
                                                Approuver
                                            </button>
                                        </form>

                                        <form
                                            action="{{ route('admin.refuser', $utilisateur->id) }}"
                                            method="POST"
                                            onsubmit="return confirm('Confirmer le refus de cette demande ?')">
                                            @csrf
                                            @method('PATCH')

                                            <button
                                                type="submit"
                                                class="btn btn-refuser">
                                                Refuser
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </section>
</main>

<footer>
    Système de gestion des étudiants — Administration
</footer>

</body>
</html>
