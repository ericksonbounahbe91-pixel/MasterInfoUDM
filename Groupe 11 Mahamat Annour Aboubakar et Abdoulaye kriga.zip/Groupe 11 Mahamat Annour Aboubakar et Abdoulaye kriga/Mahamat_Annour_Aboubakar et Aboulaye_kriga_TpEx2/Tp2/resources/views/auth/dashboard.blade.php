
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon espace étudiant - Université de Moundou</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #1246a0;
            color: white;
            padding: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 { margin: 0 0 8px; }

        main {
            max-width: 1000px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .carte {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 20px #0000000d;
            margin-bottom: 24px;
        }

        h2 { color: #1246a0; }

        .informations {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .information {
            padding: 14px;
            background: #f8fafc;
            border-radius: 8px;
            overflow-wrap: anywhere;
        }

        .information strong {
            display: block;
            margin-bottom: 7px;
            color: #475569;
        }

        .bouton {
            display: inline-block;
            padding: 11px 17px;
            border: 0;
            border-radius: 7px;
            background: white;
            color: #1246a0;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
            font-size: 15px;
        }

        .bouton-bleu {
            background: #1246a0;
            color: white;
        }

        @media (max-width: 600px) {
            .informations { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>
<header>
    <div>
        <h1>Université de Moundou</h1>
        <p>Mon espace étudiant</p>
    </div>

    <form action="{{ route('deconnexion') }}" method="POST">
        @csrf
        <button class="bouton" type="submit">Se déconnecter</button>
    </form>
</header>

<main>
    <section class="carte">
        <h2>Bienvenue, {{ $etudiant->prenom }} {{ $etudiant->nom }} !</h2>
        <p>Vous êtes connecté à votre espace étudiant personnel.</p>
    </section>

    <section class="carte">
        <h2>Mes informations</h2>

        <div class="informations">
            <div class="information">
                <strong>Matricule</strong>
                {{ $etudiant->matricule }}
            </div>

            <div class="information">
                <strong>Adresse e-mail</strong>
                {{ $etudiant->email }}
            </div>

            <div class="information">
                <strong>Date de naissance</strong>
                {{ $etudiant->date_naissance }}
            </div>

            <div class="information">
                <strong>Téléphone</strong>
                {{ $etudiant->telephone }}
            </div>

            <div class="information">
                <strong>Faculté</strong>
                {{ $etudiant->faculte }}
            </div>

            <div class="information">
                <strong>Filière</strong>
                {{ $etudiant->filiere }}
            </div>

            <div class="information">
                <strong>Niveau d'études</strong>
                {{ $etudiant->niveau }}
            </div>
        </div>
    </section>

    <section class="carte">
        <h2>Mes résultats</h2>
        <p>Aucun résultat n'est encore disponible dans cet espace.</p>
        <p>Les résultats seront affichés ici lorsque nous aurons créé le module de gestion des notes.</p>
    </section>

    <a class="bouton bouton-bleu" href="{{ route('accueil') }}">
        Retour à l'accueil
    </a>
</main>
</body>
</html>
