package com.example.universite_moundou

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
