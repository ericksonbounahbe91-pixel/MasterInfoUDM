
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const UniversiteMoundouApp());
}

// Adresse du serveur Laravel sur le réseau local.
const String apiUrl = 'http://192.168.0.200:8000/api';

const Color bleu = Color(0xFF0755A5);
const Color fond = Color(0xFFF4F7FC);

// ==================================================
// APPLICATION
// ==================================================

class UniversiteMoundouApp extends StatelessWidget {
  const UniversiteMoundouApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Université de Moundou',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: bleu),
        scaffoldBackgroundColor: fond,
        appBarTheme: const AppBarTheme(
          backgroundColor: bleu,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const AccueilPage(),
    );
  }
}

// ==================================================
// FONCTIONS COMMUNES
// ==================================================

InputDecoration decorationChamp(
  String label, {
  IconData? icone,
}) {
  return InputDecoration(
    labelText: label,
    prefixIcon: icone == null ? null : Icon(icone, color: bleu),
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xFFD5DEEA)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: bleu, width: 1.5),
    ),
  );
}

String? obligatoire(String? valeur) {
  if (valeur == null || valeur.trim().isEmpty) {
    return 'Ce champ est obligatoire.';
  }
  return null;
}

String messageErreur(dynamic donnees) {
  if (donnees is Map) {
    final erreurs = donnees['errors'];

    if (erreurs is Map && erreurs.isNotEmpty) {
      final premiere = erreurs.values.first;

      if (premiere is List && premiere.isNotEmpty) {
        return premiere.first.toString();
      }
    }

    if (donnees['message'] != null) {
      return donnees['message'].toString();
    }
  }

  return 'Une erreur est survenue. Réessaie.';
}

void afficherMessage(
  BuildContext context,
  String message, {
  bool erreur = false,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: erreur ? Colors.red.shade700 : Colors.green.shade700,
      duration: const Duration(seconds: 4),
    ),
  );
}

// ==================================================
// PAGE D'ACCUEIL
// ==================================================

class AccueilPage extends StatelessWidget {
  const AccueilPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 35),
              Container(
                width: 95,
                height: 95,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: bleu,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: const Icon(
                  Icons.school_rounded,
                  color: Colors.white,
                  size: 58,
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'UNIVERSITÉ DE MOUNDOU',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: bleu,
                  fontSize: 23,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'PORTAIL ÉTUDIANT',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.blueGrey,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 45),
              const Text(
                'Bienvenue !',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF172B4D),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Accédez à votre espace étudiant et retrouvez '
                'les services de votre université depuis votre téléphone.',
                style: TextStyle(
                  fontSize: 16,
                  height: 1.6,
                  color: Color(0xFF64748B),
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 55,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ConnexionPage(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.login),
                  label: const Text('Se connecter'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: bleu,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 15),
              SizedBox(
                height: 55,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const InscriptionPage(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.person_add),
                  label: const Text('Créer un compte'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: bleu,
                    side: const BorderSide(color: bleu),
                  ),
                ),
              ),
              const SizedBox(height: 35),
              Card(
                color: Colors.white,
                child: const Padding(
                  padding: EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Icon(
                        Icons.menu_book_rounded,
                        color: bleu,
                        size: 42,
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Votre avenir commence ici',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              'Un accès simple aux services étudiants.',
                              style: TextStyle(color: Colors.blueGrey),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 25),
              const Text(
                'Université de Moundou • Tchad',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.blueGrey, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================================================
// PAGE D'INSCRIPTION
// ==================================================

class InscriptionPage extends StatefulWidget {
  const InscriptionPage({super.key});

  @override
  State<InscriptionPage> createState() => _InscriptionPageState();
}

class _InscriptionPageState extends State<InscriptionPage> {
  final formKey = GlobalKey<FormState>();

  final nom = TextEditingController();
  final prenom = TextEditingController();
  final matricule = TextEditingController();
  final telephone = TextEditingController();
  final faculte = TextEditingController();
  final filiere = TextEditingController();
  final niveau = TextEditingController();
  final email = TextEditingController();
  final motDePasse = TextEditingController();
  final confirmation = TextEditingController();

  DateTime? dateNaissance;
  bool chargement = false;
  bool cacherMotDePasse = true;
  bool cacherConfirmation = true;

  @override
  void dispose() {
    nom.dispose();
    prenom.dispose();
    matricule.dispose();
    telephone.dispose();
    faculte.dispose();
    filiere.dispose();
    niveau.dispose();
    email.dispose();
    motDePasse.dispose();
    confirmation.dispose();
    super.dispose();
  }

  Future<void> choisirDate() async {
    final aujourdHui = DateTime.now();

    final resultat = await showDatePicker(
      context: context,
      initialDate: DateTime(2002, 1, 1),
      firstDate: DateTime(1950),
      lastDate: DateTime(
        aujourdHui.year,
        aujourdHui.month,
        aujourdHui.day,
      ).subtract(const Duration(days: 1)),
      helpText: 'Choisir la date de naissance',
    );

    if (resultat != null && mounted) {
      setState(() => dateNaissance = resultat);
    }
  }

  Future<void> inscrire() async {
    FocusScope.of(context).unfocus();

    if (!formKey.currentState!.validate()) return;

    if (dateNaissance == null) {
      afficherMessage(
        context,
        'Choisis ta date de naissance.',
        erreur: true,
      );
      return;
    }

    if (motDePasse.text != confirmation.text) {
      afficherMessage(
        context,
        'Les mots de passe ne correspondent pas.',
        erreur: true,
      );
      return;
    }

    setState(() => chargement = true);

    try {
      final date = dateNaissance!;
      final dateFormatee =
          '${date.year.toString().padLeft(4, '0')}-'
          '${date.month.toString().padLeft(2, '0')}-'
          '${date.day.toString().padLeft(2, '0')}';

      final reponse = await http
          .post(
            Uri.parse('$apiUrl/register'),
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'nom': nom.text.trim(),
              'prenom': prenom.text.trim(),
              'matricule': matricule.text.trim(),
              'date_naissance': dateFormatee,
              'telephone': telephone.text.trim(),
              'faculte': faculte.text.trim(),
              'filiere': filiere.text.trim(),
              'niveau': niveau.text.trim(),
              'email': email.text.trim(),
              'password': motDePasse.text,
              'password_confirmation': confirmation.text,
            }),
          )
          .timeout(const Duration(seconds: 20));

      final donnees = jsonDecode(reponse.body);

      if (!mounted) return;

      if (reponse.statusCode == 201) {
        afficherMessage(
          context,
          donnees['message']?.toString() ??
              'Inscription envoyée avec succès.',
        );
        Navigator.pop(context);
      } else {
        afficherMessage(
          context,
          messageErreur(donnees),
          erreur: true,
        );
      }
    } catch (_) {
      if (mounted) {
        afficherMessage(
          context,
          'Impossible de contacter Laravel. Vérifie le réseau '
          'et l’adresse du serveur.',
          erreur: true,
        );
      }
    } finally {
      if (mounted) {
        setState(() => chargement = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inscription étudiant')),
      body: SafeArea(
        child: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Icon(Icons.school, color: bleu, size: 55),
              const SizedBox(height: 10),
              const Text(
                'CRÉER UN COMPTE',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: bleu,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 25),
              TextFormField(
                controller: nom,
                textCapitalization: TextCapitalization.words,
                decoration: decorationChamp('Nom', icone: Icons.person),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: prenom,
                textCapitalization: TextCapitalization.words,
                decoration: decorationChamp('Prénom', icone: Icons.person),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: matricule,
                decoration: decorationChamp(
                  'Matricule étudiant',
                  icone: Icons.badge,
                ),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              OutlinedButton.icon(
                onPressed: choisirDate,
                icon: const Icon(Icons.calendar_month),
                label: Text(
                  dateNaissance == null
                      ? 'Choisir la date de naissance'
                      : 'Date de naissance : '
                          '${dateNaissance!.day.toString().padLeft(2, '0')}/'
                          '${dateNaissance!.month.toString().padLeft(2, '0')}/'
                          '${dateNaissance!.year}',
                ),
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: telephone,
                keyboardType: TextInputType.phone,
                decoration: decorationChamp('Téléphone', icone: Icons.phone),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: faculte,
                decoration: decorationChamp(
                  'Faculté',
                  icone: Icons.account_balance,
                ),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: filiere,
                decoration: decorationChamp(
                  'Filière',
                  icone: Icons.menu_book,
                ),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: niveau,
                decoration: decorationChamp(
                  'Niveau (ex. Licence 1)',
                  icone: Icons.school,
                ),
                validator: obligatoire,
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                decoration: decorationChamp(
                  'Adresse e-mail',
                  icone: Icons.email,
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Saisis ton adresse e-mail.';
                  }
                  if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
                      .hasMatch(value.trim())) {
                    return 'Adresse e-mail invalide.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: motDePasse,
                obscureText: cacherMotDePasse,
                decoration: decorationChamp(
                  'Mot de passe (8 caractères minimum)',
                  icone: Icons.lock,
                ).copyWith(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        cacherMotDePasse = !cacherMotDePasse;
                      });
                    },
                    icon: Icon(
                      cacherMotDePasse
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.length < 8) {
                    return 'Utilise au moins 8 caractères.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),
              TextFormField(
                controller: confirmation,
                obscureText: cacherConfirmation,
                decoration: decorationChamp(
                  'Confirmer le mot de passe',
                  icone: Icons.lock_outline,
                ).copyWith(
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        cacherConfirmation = !cacherConfirmation;
                      });
                    },
                    icon: Icon(
                      cacherConfirmation
                          ? Icons.visibility
                          : Icons.visibility_off,
                    ),
                  ),
                ),
                validator: (value) {
                  if (value != motDePasse.text) {
                    return 'Les mots de passe ne correspondent pas.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 25),
              SizedBox(
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: chargement ? null : inscrire,
                  icon: chargement
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.person_add),
                  label: Text(
                    chargement
                        ? 'Inscription en cours...'
                        : 'Créer mon compte',
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: bleu,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ConnexionPage(),
                    ),
                  );
                },
                child: const Text('J’ai déjà un compte : me connecter'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================================================
// PAGE DE CONNEXION
// ==================================================

class ConnexionPage extends StatefulWidget {
  const ConnexionPage({super.key});

  @override
  State<ConnexionPage> createState() => _ConnexionPageState();
}

class _ConnexionPageState extends State<ConnexionPage> {
  final formKey = GlobalKey<FormState>();
  final email = TextEditingController();
  final motDePasse = TextEditingController();

  bool chargement = false;
  bool cacherMotDePasse = true;

  @override
  void dispose() {
    email.dispose();
    motDePasse.dispose();
    super.dispose();
  }

  Future<void> connecter() async {
    FocusScope.of(context).unfocus();

    if (!formKey.currentState!.validate()) return;

    setState(() => chargement = true);

    try {
      final reponse = await http
          .post(
            Uri.parse('$apiUrl/login'),
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'email': email.text.trim(),
              'password': motDePasse.text,
            }),
          )
          .timeout(const Duration(seconds: 20));

      final donnees = jsonDecode(reponse.body);

      if (!mounted) return;

      if (reponse.statusCode == 200) {
        final utilisateur = donnees['user'];
        final token = donnees['token']?.toString() ?? '';

        if (token.isEmpty) {
          afficherMessage(
            context,
            'Le serveur n’a pas fourni de jeton de connexion.',
            erreur: true,
          );
          return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => EspaceEtudiantPage(
              nom: utilisateur is Map
                  ? utilisateur['name']?.toString() ?? 'Étudiant'
                  : 'Étudiant',
              email: utilisateur is Map
                  ? utilisateur['email']?.toString() ?? email.text.trim()
                  : email.text.trim(),
              token: token,
            ),
          ),
        );
      } else {
        afficherMessage(
          context,
          messageErreur(donnees),
          erreur: true,
        );
      }
    } catch (_) {
      if (mounted) {
        afficherMessage(
          context,
          'Impossible de contacter Laravel. Vérifie le réseau '
          'et l’adresse du serveur.',
          erreur: true,
        );
      }
    } finally {
      if (mounted) {
        setState(() => chargement = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connexion étudiant')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(
                  Icons.lock_open_rounded,
                  color: bleu,
                  size: 75,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Bienvenue dans votre espace',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: bleu,
                    fontSize: 23,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Connectez-vous avec votre adresse e-mail '
                  'et votre mot de passe.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.blueGrey,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 30),
                TextFormField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  autocorrect: false,
                  decoration: decorationChamp(
                    'Adresse e-mail',
                    icone: Icons.email,
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Saisis ton adresse e-mail.';
                    }
                    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
                        .hasMatch(value.trim())) {
                      return 'Adresse e-mail invalide.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 15),
                TextFormField(
                  controller: motDePasse,
                  obscureText: cacherMotDePasse,
                  decoration: decorationChamp(
                    'Mot de passe',
                    icone: Icons.lock,
                  ).copyWith(
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          cacherMotDePasse = !cacherMotDePasse;
                        });
                      },
                      icon: Icon(
                        cacherMotDePasse
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Saisis ton mot de passe.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 25),
                SizedBox(
                  height: 54,
                  child: ElevatedButton.icon(
                    onPressed: chargement ? null : connecter,
                    icon: chargement
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.login),
                    label: Text(
                      chargement
                          ? 'Connexion en cours...'
                          : 'Se connecter',
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: bleu,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const InscriptionPage(),
                      ),
                    );
                  },
                  child: const Text('Pas encore de compte ? S’inscrire'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================================================
// ESPACE ÉTUDIANT
// ==================================================

class EspaceEtudiantPage extends StatelessWidget {
  final String nom;
  final String email;
  final String token;

  const EspaceEtudiantPage({
    super.key,
    required this.nom,
    required this.email,
    required this.token,
  });

  Future<void> deconnecter(BuildContext context) async {
    try {
      await http.post(
        Uri.parse('$apiUrl/logout'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        },
      ).timeout(const Duration(seconds: 15));
    } catch (_) {
      // Le retour à l'accueil reste possible si le serveur est indisponible.
    }

    if (!context.mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => const AccueilPage(),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Espace étudiant'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            tooltip: 'Déconnexion',
            onPressed: () => deconnecter(context),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          const SizedBox(height: 20),
          const Icon(
            Icons.account_circle,
            color: bleu,
            size: 100,
          ),
          const SizedBox(height: 20),
          const Text(
            'Bienvenue dans votre espace !',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: bleu,
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 25),
          Card(
            color: Colors.white,
            child: ListTile(
              leading: const Icon(Icons.person, color: bleu),
              title: const Text('Nom'),
              subtitle: Text(nom),
            ),
          ),
          Card(
            color: Colors.white,
            child: ListTile(
              leading: const Icon(Icons.email, color: bleu),
              title: const Text('Adresse e-mail'),
              subtitle: Text(email),
            ),
          ),
          const SizedBox(height: 25),
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () => deconnecter(context),
              icon: const Icon(Icons.logout),
              label: const Text('Se déconnecter'),
              style: ElevatedButton.styleFrom(
                backgroundColor: bleu,
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
