import 'package:flutter_test/flutter_test.dart';
import 'package:universite_moundou/main.dart';

void main() {
  testWidgets('L’application affiche la page d’accueil',
      (WidgetTester tester) async {
    await tester.pumpWidget(const UniversiteMoundouApp());

    expect(find.text('UNIVERSITÉ DE MOUNDOU'), findsOneWidget);
    expect(find.text('Bienvenue !'), findsOneWidget);
    expect(find.text('Se connecter'), findsOneWidget);
    expect(find.text('Créer un compte'), findsOneWidget);
  });
}