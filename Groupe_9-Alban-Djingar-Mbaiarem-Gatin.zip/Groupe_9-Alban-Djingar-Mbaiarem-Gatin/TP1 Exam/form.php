<?php
$id = $_GET['id'] ?? null;
/** TP5 – Formulaire partagé création / modification.
 *  GET ?id=XXX : charge l'étudiant à modifier ; sans id : formulaire vierge. */
require 'config.php';


$etu = array_fill_keys(CHAMPS, '');
if ($id !== null) {
    $stmt = $pdo->prepare('SELECT * FROM etudiant WHERE idEtu = ?');
    $stmt->execute([$id]);
    $etu = $stmt->fetch() ?: exit('Étudiant introuvable.');
}
$libelles = ['idEtu'=>'Matricule','nomEtu'=>'Nom','prenomEtu'=>'Prénom','sexeEtu'=>'Sexe','dateNaiss'=>'Date de naissance',
  'lieuNaiss'=>'Lieu de naissance','photoEtu'=>'Photo de l’étudiant',
  'emailEtu'=>'Email','numTelEtu'=>'Téléphone','regEtu'=>'Région','departEtu'=>'Département',
  'arrondisEtu'=>'Arrondissement','mentionEtu'=>'Mention','cycleEtu'=>'Cycle','ParcoursEtu'=>'Parcours'];
$sexesSelectionnes = $etu['sexeEtu'] !== '' ? explode(',', $etu['sexeEtu']) : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $id ? 'Modifier' : 'Créer' ?> un étudiant</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4" style="max-width:680px">
  <h1 class="h3 text-primary mb-3"><?= $id ? 'Modifier' : 'Nouvel' ?> étudiant</h1>
  <form method="post" action="save.php" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">
    <input type="hidden" name="mode" value="<?= $id ? 'update' : 'create' ?>">
    <?php foreach (CHAMPS as $c): ?>
      <div class="mb-3">
        <?php if ($c === 'sexeEtu'): ?>
          <span class="form-label"><?= $libelles[$c] ?></span>
        <?php else: ?>
          <label class="form-label" for="<?= $c ?>"><?= $libelles[$c] ?></label>
        <?php endif; ?>
        <?php if ($c === 'sexeEtu'): ?>
          <div>
            <?php foreach (['Masculin','Féminin','Autre'] as $sexe): ?>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="sexe<?= h($sexe) ?>" name="sexeEtu[]" value="<?= h($sexe) ?>"
                       <?= in_array($sexe, $sexesSelectionnes, true) ? 'checked' : '' ?>>
                <label class="form-check-label" for="sexe<?= h($sexe) ?>"><?= h($sexe) ?></label>
              </div>
            <?php endforeach; ?>
          </div>
        <?php elseif ($c === 'photoEtu'): ?>
          <?php if (!empty($etu[$c])): ?><img src="<?= h($etu[$c]) ?>" alt="Photo actuelle" class="d-block mb-2" style="max-width:120px"><?php endif; ?>
          <input class="form-control" id="<?= $c ?>" name="<?= $c ?>" type="file" accept="image/jpeg,image/png,image/webp"
                 <?= empty($etu[$c]) ? 'required' : '' ?>>
          <?php if (!empty($etu[$c])): ?><div class="form-text">Laissez vide pour conserver la photo actuelle.</div><?php endif; ?>
        <?php elseif ($c === 'mentionEtu' || $c === 'cycleEtu'): ?>
          <?php $options = $c === 'mentionEtu'
              ? ['Informatique', 'Mécatronique', 'Mathématiques']
              : ['Licence', 'Master', 'Doctorat']; ?>
          <select class="form-select" id="<?= $c ?>" name="<?= $c ?>" required>
            <option value="">-- Choisir --</option>
            <?php foreach ($options as $option): ?>
              <option value="<?= h($option) ?>" <?= $etu[$c] === $option ? 'selected' : '' ?>><?= h($option) ?></option>
            <?php endforeach; ?>
          </select>
        <?php else: ?>
        <input class="form-control" id="<?= $c ?>" name="<?= $c ?>"
               type="<?= $c === 'dateNaiss' ? 'date' : ($c === 'emailEtu' ? 'email' : ($c === 'numTelEtu' ? 'tel' : 'text')) ?>"
               <?= $c === 'idEtu' ? 'maxlength="20" placeholder="ex. 25ADI016 ou 25IRS012"' : '' ?>
               <?= $c === 'numTelEtu' ? 'maxlength="30" placeholder="ex. +235... ou +234..."' : '' ?>
               value="<?= h($etu[$c]) ?>" required
               <?= ($id && $c === 'idEtu') ? 'readonly' : '' ?>>  <!-- la clé primaire n'est pas modifiable -->
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <button class="btn btn-primary">Enregistrer</button>
    <a class="btn btn-link" href="index.php">Annuler</a>
  </form>
</div>
</body>
</html>
