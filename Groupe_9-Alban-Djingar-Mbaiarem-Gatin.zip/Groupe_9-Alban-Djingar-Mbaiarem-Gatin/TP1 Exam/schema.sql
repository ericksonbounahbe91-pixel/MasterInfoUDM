CREATE DATABASE IF NOT EXISTS universite
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE universite;

CREATE TABLE IF NOT EXISTS etudiant (
  idEtu VARCHAR(20) NOT NULL,
  nomEtu VARCHAR(50) NOT NULL,
  prenomEtu VARCHAR(50) NOT NULL,
  sexeEtu VARCHAR(50) NOT NULL,
  dateNaiss DATE NOT NULL,
  lieuNaiss VARCHAR(150) NOT NULL,
  photoEtu VARCHAR(255) NOT NULL,
  emailEtu VARCHAR(255) NOT NULL,
  numTelEtu VARCHAR(30) NOT NULL,
  regEtu VARCHAR(100) NOT NULL,
  departEtu VARCHAR(100) NOT NULL,
  arrondisEtu VARCHAR(100) NOT NULL,
  mentionEtu VARCHAR(100) NOT NULL,
  cycleEtu VARCHAR(50) NOT NULL,
  ParcoursEtu VARCHAR(100) NOT NULL,
  PRIMARY KEY (idEtu),
  UNIQUE KEY uq_etudiant_email (emailEtu)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
