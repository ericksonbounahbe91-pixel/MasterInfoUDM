# Rapport du projet TP1 - Gestion des étudiants

## 1. Contexte
Ce projet a pour objectif la gestion des étudiants d’une université à partir d’une base de données MySQL et d’une interface web PHP.

## 2. Objectif
Gérer le cycle de vie des étudiants :
- ajout d’un étudiant
- modification d’un étudiant
- suppression d’un étudiant
- recherche par nom ou prénom
- affichage des données dans une liste structurée

## 3. Technologies utilisées
- PHP
- MySQL / MariaDB
- HTML
- CSS / Bootstrap
- JavaScript (validation côté client)

## 4. Structure principale
- `index.php` : liste des étudiants et recherche
- `form.php` : formulaire d’ajout / modification
- `save.php` : enregistrement des données
- `delete.php` : suppression d’un étudiant
- `config.php` : configuration de connexion à la base
- `schema.sql` : schéma de la base de données
- `validation.js` : validations du formulaire

## 5. Fonctionnalités principales
- affichage de la liste des étudiants
- recherche dynamique par nom/prénom
- ajout d’un nouvel étudiant
- mise à jour des informations existantes
- suppression sécurisée avec confirmation
- gestion des photos, email unique et validation des champs

## 6. Modèle de données
La table `etudiant` contient les informations suivantes :
- identifiant
- nom et prénom
- sexe
- date et lieu de naissance
- photo
- email
- téléphone
- région, département, arrondissement
- mention, cycle et parcours

## 7. Points forts
- architecture simple et claire
- utilisation de requêtes préparées pour la sécurité
- interface utilisateur lisible et rapide
- gestion des validations côté client et côté serveur

## 8. État du projet
Le projet est fonctionnel et correspond à une application de gestion académique simple mais complète pour les opérations CRUD de base.
