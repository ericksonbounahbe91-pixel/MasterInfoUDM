/**
 * Leçon 2 – Validation côté client du formulaire d'inscription étudiant.
 *
 * Principe : chaque champ est associé à une règle (fonction qui retourne
 * un message d'erreur, ou une chaîne vide si la valeur est valide).
 * Cette approche « pilotée par les données » évite la répétition de code
 * et facilite l'ajout de nouveaux champs.
 *
 * Rappel de sécurité : la validation côté client améliore l'expérience
 * utilisateur mais ne protège pas le système. Le serveur (Node/PHP, TP4 et
 * TP5) doit revalider systématiquement toutes les données reçues.
 */
'use strict';

const form = document.getElementById('formEtudiant');

// Expressions régulières réutilisables
const REGEX = {
  matricule: /^[A-Za-z0-9]{5,20}$/,
  nom: /^[A-Za-zÀ-ÖØ-öø-ÿ' -]{2,50}$/,                      // lettres, espace, tiret, apostrophe
  nomParent: /^[A-Za-zÀ-ÖØ-öø-ÿ.' -]{2,50}$/,                // idem + point (ex. B.VANGILA)
  email: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
  telephone: /^\+?[0-9().\s-]+$/
};

/** Règles par champ : retourne '' si valide, sinon le message d'erreur. */
const regles = {
  idEtu:       v => REGEX.matricule.test(v) ? '' : 'Matricule invalide (5 à 20 lettres ou chiffres).',
  nomEtu:      v => REGEX.nom.test(v) ? '' : 'Nom invalide (2 à 50 lettres).',
  prenomEtu:   v => REGEX.nom.test(v) ? '' : 'Prénom invalide (2 à 50 lettres).',
  sexeEtu:     v => Array.isArray(v) && v.length > 0 &&
    v.every(sexe => ['Masculin', 'Féminin', 'Autre'].includes(sexe)) ? '' : 'Veuillez cocher au moins une option pour le sexe.',
  dateNaiss:   v => verifierDateNaissance(v),
  lieuNaiss:   v => v.length >= 2 ? '' : 'Le lieu de naissance est obligatoire.',
  photoEtu:    v => {
    if (!v) return form.elements.photoEtu.required ? 'Veuillez choisir une photo.' : '';
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(v.type)) return 'Format accepté : JPG, PNG ou WebP.';
    return v.size <= 5 * 1024 * 1024 ? '' : 'La photo ne doit pas dépasser 5 Mo.';
  },
  emailEtu:    v => REGEX.email.test(v) ? '' : 'Adresse email invalide.',
  numTelEtu:   v => {
    const chiffres = v.replace(/\D/g, '');
    return REGEX.telephone.test(v) && chiffres.length >= 7 && chiffres.length <= 15
      ? '' : 'Numéro invalide (indicatif international facultatif, 7 à 15 chiffres).';
  },
  nomParent:   v => REGEX.nomParent.test(v) ? '' : 'Nom du parent invalide (2 à 50 lettres).',
  regEtu:      v => v.length >= 2 ? '' : 'La région est obligatoire.',
  departEtu:   v => v.length >= 2 ? '' : 'Le département est obligatoire.',
  arrondisEtu: v => v.length >= 2 ? '' : "L'arrondissement est obligatoire.",
  mentionEtu:  v => v !== '' ? '' : 'Veuillez choisir une mention.',
  cycleEtu:    v => v !== '' ? '' : 'Veuillez choisir un cycle.',
  ParcoursEtu: v => v.length >= 2 ? '' : 'Le parcours est obligatoire.'
};

/** La date doit être valide, passée, et correspondre à un âge entre 15 et 70 ans. */
function verifierDateNaissance(valeur) {
  if (!valeur) return 'La date de naissance est obligatoire.';
  const naissance = new Date(valeur);
  const aujourdhui = new Date();
  let age = aujourdhui.getFullYear() - naissance.getFullYear();
  const anniversairePasse =
    aujourdhui.getMonth() > naissance.getMonth() ||
    (aujourdhui.getMonth() === naissance.getMonth() && aujourdhui.getDate() >= naissance.getDate());
  if (!anniversairePasse) age--;
  return (age >= 15 && age <= 70) ? '' : 'Âge incohérent (entre 15 et 70 ans).';
}

/**
 * Affiche ou efface l'erreur sous un champ. Retourne true si le champ est valide.
 * Les cases du sexe sont contrôlées en groupe pour prendre en compte les choix multiples.
 */
function validerChamp(champ) {
  const estGroupeSexe = champ.type === 'checkbox' && champ.name === 'sexeEtu[]';
  let valeur;
  if (estGroupeSexe) {
    valeur = [...form.querySelectorAll('input[name="sexeEtu[]"]:checked')]
      .map(caseSexe => caseSexe.value);
  } else if (champ.type === 'file') {
    valeur = champ.files[0];
  } else {
    valeur = champ.value.trim();
  }
  const nomRegle = estGroupeSexe ? 'sexeEtu' : champ.name;
  const message = regles[nomRegle](valeur);
  const conteneur = champ.closest('.champ');

  if (estGroupeSexe) {
    form.querySelectorAll('input[name="sexeEtu[]"]')
      .forEach(caseSexe => caseSexe.classList.toggle('invalide', message !== ''));
    conteneur.classList.toggle('groupe-invalide', message !== '');
  } else {
    champ.classList.toggle('invalide', message !== '');
  }
  conteneur.querySelector('.erreur').textContent = message;
  return message === '';
}

// Validation en temps réel : blur puis saisie pour les champs texte,
// événement change pour cases à cocher et fichier.
form.querySelectorAll('input:not([type="hidden"]), select').forEach(champ => {
  if (champ.type === 'checkbox') {
    champ.addEventListener('change', () => validerChamp(champ));
    return;
  }
  if (champ.type === 'file') {
    champ.addEventListener('change', () => validerChamp(champ));
    return;
  }
  champ.addEventListener('blur', () => validerChamp(champ));
  champ.addEventListener('input', () => { if (champ.classList.contains('invalide')) validerChamp(champ); });
});

// Validation globale à la soumission
form.addEventListener('submit', evenement => {
  evenement.preventDefault();
  const champs = [...form.querySelectorAll('input:not([type="hidden"]), select')];
  // map() évalue TOUS les champs afin d'afficher toutes les erreurs d'un coup
  const toutValide = champs.map(validerChamp).every(Boolean);
  const resultat = document.getElementById('resultat');

  if (toutValide) {
    form.submit();
  } else {
    resultat.textContent = '';
    form.querySelector('.invalide')?.focus();   // place le curseur sur la 1re erreur
  }
});
