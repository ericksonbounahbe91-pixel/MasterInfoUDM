<?php
/** CREATE et UPDATE : traitement du formulaire étudiant (POST uniquement). */
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Méthode non autorisée.');
}

function retourErreur(string $message): void {
    header('Location: index.php?err=' . urlencode($message));
    exit;
}

function supprimerPhoto(?string $chemin): void {
    if ($chemin !== null && preg_match('~^uploads/[a-f0-9]{32}\.(jpg|png|webp)$~', $chemin)) {
        $fichier = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $chemin);
        if (is_file($fichier)) {
            unlink($fichier);
        }
    }
}

$mode = $_POST['mode'] ?? 'create';
if (!in_array($mode, ['create', 'update'], true)) {
    retourErreur('Mode de formulaire invalide.');
}

$d = [];
foreach (array_diff(CHAMPS, ['photoEtu', 'sexeEtu']) as $c) {
    $valeur = $_POST[$c] ?? '';
    if (!is_string($valeur)) {
        retourErreur("Valeur invalide pour le champ : $c");
    }
    $d[$c] = trim($valeur);
    if ($d[$c] === '') {
        retourErreur("Champ manquant : $c");
    }
}
$sexesDisponibles = ['Masculin', 'Féminin', 'Autre'];
$sexesSoumis = $_POST['sexeEtu'] ?? [];
if (!is_array($sexesSoumis) || !$sexesSoumis) {
    retourErreur('Veuillez cocher au moins une option pour le sexe.');
}
$sexesChoisis = [];
foreach ($sexesSoumis as $sexe) {
    if (!is_string($sexe) || !in_array($sexe, $sexesDisponibles, true)) {
        retourErreur('Valeur de sexe invalide.');
    }
    $sexesChoisis[] = $sexe;
}
$d['sexeEtu'] = implode(',', array_unique($sexesChoisis));
if (!preg_match('/^[A-Za-z0-9]{5,20}$/', $d['idEtu'])) {
    retourErreur('Matricule invalide : utilisez 5 à 20 lettres ou chiffres.');
}
if (!preg_match('/^\+?[0-9()\s.-]+$/', $d['numTelEtu'])) {
    retourErreur('Format de téléphone invalide.');
}
$chiffresTelephone = preg_replace('/\D/', '', $d['numTelEtu']);
if (strlen($chiffresTelephone) < 7 || strlen($chiffresTelephone) > 15) {
    retourErreur('Le numéro doit contenir entre 7 et 15 chiffres.');
}
if (!filter_var($d['emailEtu'], FILTER_VALIDATE_EMAIL)) {
    retourErreur('Email invalide.');
}
if (!in_array($d['mentionEtu'], ['Informatique', 'Mécatronique', 'Mathématiques'], true)) {
    retourErreur('Veuillez choisir une mention valide.');
}
if (!in_array($d['cycleEtu'], ['Licence', 'Master', 'Doctorat'], true)) {
    retourErreur('Veuillez choisir un cycle valide.');
}

$anciennePhoto = null;
if ($mode === 'update') {
    $stmt = $pdo->prepare('SELECT photoEtu FROM etudiant WHERE idEtu = ?');
    $stmt->execute([$d['idEtu']]);
    $anciennePhoto = $stmt->fetchColumn();
    if ($anciennePhoto === false) {
        retourErreur('Étudiant introuvable.');
    }
}

$photo = $_FILES['photoEtu'] ?? null;
$nouvellePhoto = null;
if ($photo !== null) {
    if (!is_array($photo) || !isset($photo['error'], $photo['size'], $photo['tmp_name'])
        || !is_int($photo['error']) || !is_int($photo['size']) || !is_string($photo['tmp_name'])) {
        retourErreur('Données de photo invalides.');
    }
}
if ($photo !== null && $photo['error'] !== UPLOAD_ERR_NO_FILE) {
    if ($photo['error'] !== UPLOAD_ERR_OK || $photo['size'] > 5 * 1024 * 1024
        || !is_uploaded_file($photo['tmp_name'])) {
        retourErreur('Échec du téléversement ou photo supérieure à 5 Mo.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $extension = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ][$finfo->file($photo['tmp_name'])] ?? null;
    if ($extension === null) {
        retourErreur('Format de photo invalide. Formats acceptés : JPG, PNG ou WebP.');
    }

    $dossierPhotos = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
    if (!is_dir($dossierPhotos) && !mkdir($dossierPhotos, 0755, true) && !is_dir($dossierPhotos)) {
        retourErreur('Impossible de préparer le dossier de stockage des photos.');
    }
    $nomPhoto = bin2hex(random_bytes(16)) . '.' . $extension;
    if (!move_uploaded_file($photo['tmp_name'], $dossierPhotos . DIRECTORY_SEPARATOR . $nomPhoto)) {
        retourErreur('Impossible d’enregistrer la photo téléversée.');
    }
    $nouvellePhoto = 'uploads/' . $nomPhoto;
}

$d['photoEtu'] = $nouvellePhoto ?? $anciennePhoto;
if (!$d['photoEtu']) {
    retourErreur('Veuillez choisir une photo.');
}

try {
    if ($mode === 'update') {
        $champsModifiables = array_diff(CHAMPS, ['idEtu']);
        $set = implode(', ', array_map(fn($c) => "$c = :$c", $champsModifiables));
        $pdo->prepare("UPDATE etudiant SET $set WHERE idEtu = :idEtu")->execute($d);
    } else {
        $cols = implode(', ', CHAMPS);
        $params = implode(', ', array_map(fn($c) => ":$c", CHAMPS));
        $pdo->prepare("INSERT INTO etudiant ($cols) VALUES ($params)")->execute($d);
    }
    if ($nouvellePhoto !== null) {
        supprimerPhoto($anciennePhoto);
    }
    header('Location: index.php?ok=1');
} catch (PDOException $e) {
    if ($nouvellePhoto !== null) {
        supprimerPhoto($nouvellePhoto);
    }
    error_log($e->getMessage());
    $msg = ($e->getCode() === '23000') ? 'Matricule ou email déjà utilisé.' : 'Erreur lors de l\'enregistrement.';
    retourErreur($msg);
}
