<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('departements', function (Blueprint $table) {
            $table->id('idDep');
            $table->string('nomDep', 120);
            $table->timestamps();
        });

        Schema::create('regions', function (Blueprint $table) {
            $table->id('idRegion');
            $table->string('nomRegion', 120);
            $table->foreignId('idDep')->constrained('departements', 'idDep')->restrictOnDelete();
            $table->timestamps();
        });

        Schema::create('clients', function (Blueprint $table) {
            $table->id('idCli');
            $table->string('nomCli', 120);
            $table->string('prenomCli', 120);
            $table->string('email')->unique();
            $table->string('photo')->nullable();
            $table->foreignId('idRegion')->constrained('regions', 'idRegion')->restrictOnDelete();
            $table->timestamps();
        });

        Schema::create('produits', function (Blueprint $table) {
            $table->id('idProd');
            $table->string('designProd', 180);
            $table->unsignedInteger('qteStock')->default(0);
            $table->decimal('prixUProd', 12, 2);
            $table->string('photoProd')->nullable();
            $table->timestamps();
        });

        Schema::create('commandes', function (Blueprint $table) {
            $table->id('idCmd');
            $table->date('dateCmd');
            $table->foreignId('idCli')->constrained('clients', 'idCli')->restrictOnDelete();
            $table->timestamps();
        });

        Schema::create('ligne_commandes', function (Blueprint $table) {
            $table->foreignId('idCmd')->constrained('commandes', 'idCmd')->cascadeOnDelete();
            $table->foreignId('idProd')->constrained('produits', 'idProd')->restrictOnDelete();
            $table->unsignedInteger('qteCmd');
            $table->timestamps();
            $table->primary(['idCmd', 'idProd']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ligne_commandes');
        Schema::dropIfExists('commandes');
        Schema::dropIfExists('produits');
        Schema::dropIfExists('clients');
        Schema::dropIfExists('regions');
        Schema::dropIfExists('departements');
    }
};
