<?php

namespace Database\Seeders;

use App\Models\Client;
use App\Models\Commande;
use App\Models\Departement;
use App\Models\Produit;
use App\Models\Region;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('ligne_commandes')->delete();
        DB::table('commandes')->delete();
        DB::table('produits')->delete();
        DB::table('clients')->delete();
        DB::table('regions')->delete();
        DB::table('departements')->delete();

        $dakar = Departement::create(['nomDep' => 'Dakar']);
        $saintLouis = Departement::create(['nomDep' => 'Saint-Louis']);

        $region1 = Region::create(['nomRegion' => 'Dakar', 'idDep' => $dakar->idDep]);
        $region2 = Region::create(['nomRegion' => 'Thiès', 'idDep' => $dakar->idDep]);
        $region3 = Region::create(['nomRegion' => 'Saint-Louis', 'idDep' => $saintLouis->idDep]);

        $clients = [
            ['nomCli' => 'Diop', 'prenomCli' => 'Awa', 'email' => 'awa.diop@example.com', 'photo' => null, 'idRegion' => $region1->idRegion],
            ['nomCli' => 'Ndiaye', 'prenomCli' => 'Moussa', 'email' => 'moussa.ndiaye@example.com', 'photo' => null, 'idRegion' => $region2->idRegion],
            ['nomCli' => 'Fall', 'prenomCli' => 'Saliou', 'email' => 'saliou.fall@example.com', 'photo' => null, 'idRegion' => $region3->idRegion],
        ];

        foreach ($clients as $client) {
            Client::create($client);
        }

        $produits = [
            ['designProd' => 'Laptop Dell XPS 13', 'qteStock' => 18, 'prixUProd' => 850000, 'photoProd' => 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80'],
            ['designProd' => 'Smartphone Samsung A54', 'qteStock' => 30, 'prixUProd' => 280000, 'photoProd' => 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80'],
            ['designProd' => 'Imprimante HP Laser', 'qteStock' => 10, 'prixUProd' => 175000, 'photoProd' => 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80'],
            ['designProd' => 'Écouteurs Bluetooth', 'qteStock' => 50, 'prixUProd' => 35000, 'photoProd' => 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=900&q=80'],
            ['designProd' => 'Clavier mécanique', 'qteStock' => 22, 'prixUProd' => 65000, 'photoProd' => 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80'],
        ];

        foreach ($produits as $produit) {
            Produit::create($produit);
        }

        $commande1 = Commande::create(['dateCmd' => '2026-10-01', 'idCli' => 1]);
        $commande2 = Commande::create(['dateCmd' => '2026-10-08', 'idCli' => 2]);
        $commande3 = Commande::create(['dateCmd' => '2026-10-12', 'idCli' => 3]);

        $commande1->produits()->attach([
            1 => ['qteCmd' => 2],
            4 => ['qteCmd' => 3],
        ]);

        $commande2->produits()->attach([
            2 => ['qteCmd' => 5],
            5 => ['qteCmd' => 2],
        ]);

        $commande3->produits()->attach([
            3 => ['qteCmd' => 1],
            1 => ['qteCmd' => 1],
        ]);
    }
}
