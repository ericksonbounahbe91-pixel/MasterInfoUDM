# Rapport du projet TP2 - Gestion des commandes

## 1. Contexte
Ce projet consiste en une application de gestion commerciale développée avec Laravel. Il permet de gérer les clients, les produits, les commandes et les lignes de commande.

## 2. Objectif
Mettre en place une plateforme de gestion complète pour :
- gérer les clients
- gérer les produits
- créer et suivre des commandes
- associer des produits à une commande
- contrôler les stocks
- sécuriser l’accès aux pages privées via un système de connexion

## 3. Technologies utilisées
- Laravel PHP
- Blade (templates HTML)
- MySQL / SQLite (selon configuration)
- Tailwind CSS
- Eloquent ORM
- Routing Laravel

## 4. Structure principale
- `app/Http/Controllers/OrderManagementController.php` : logique métier
- `app/Models/Client.php` : modèle du client
- `app/Models/Produit.php` : modèle du produit
- `app/Models/Commande.php` : modèle de la commande
- `resources/views/` : vues Blade
- `routes/web.php` : routes de navigation
- `database/` : schéma et migrations

## 5. Fonctionnalités principales
- authentification avec login / mot de passe
- tableau de bord de suivi général
- gestion des clients
- gestion des produits
- gestion des commandes
- ajout de produits dans une commande
- suppression d’un produit d’une commande
- contrôle de stock avant validation
- affichage des produits déjà associés à une commande
- gestion des erreurs et messages de validation

## 6. Gestion des commandes
Le système permet d’associer plusieurs produits à une commande et de conserver la quantité commandée pour chaque produit via la table de jointure `ligne_commandes`.

La logique inclut :
- validation obligatoire du produit
- validation de la quantité
- contrôle de la disponibilité du stock
- ajout ou mise à jour de la quantité dans la commande

## 7. Sécurité et qualité
- accès protégé aux pages sensibles
- validation des données côté serveur
- messages d’erreur explicites
- contrôle des identifiants et des permissions de session

## 8. Points forts
- architecture MVC propre
- utilisation de Laravel et Eloquent
- code lisible et bien structuré
- interface moderne avec Tailwind
- logique métier cohérente et orientée métier

## 9. État du projet
Le projet est fonctionnel et prêt pour une utilisation de démonstration. Il couvre les besoins essentiels de gestion de commandes et de stock dans un cadre académique.
