<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Gestion des commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0D79DF] text-[#04506E]">
    <div class="max-w-7xl mx-auto py-10 px-4">
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold">Tableau de bord</h1>
                <p class="text-[#04506E]">Statistiques de la ligne de commande</p>
            </div>
            <nav class="flex gap-3 flex-wrap items-center">
                <a href="<?php echo e(route('dashboard')); ?>" class="bg-[#04506E] text-white px-4 py-2 rounded">Accueil</a>
                <a href="<?php echo e(route('clients.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Clients</a>
                <a href="<?php echo e(route('commandes.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Commandes</a>
                <a href="<?php echo e(route('produits.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Produits</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-[#04506E] text-white px-4 py-2 rounded">Déconnexion</button>
                </form>
            </nav>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Clients</div>
                <div class="text-3xl font-bold"><?php echo e($totalClients); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Commandes</div>
                <div class="text-3xl font-bold"><?php echo e($totalCommandes); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Produits</div>
                <div class="text-3xl font-bold"><?php echo e($totalProduits); ?></div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Quantité vendue</div>
                <div class="text-3xl font-bold"><?php echo e($totalQteVendue); ?></div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-3">Chiffre d'affaires</h2>
                <p class="text-3xl font-bold text-[#04506E]"><?php echo e(number_format($chiffreAffaires, 2, ',', ' ')); ?> FCFA</p>
            </div>
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-3">Panier moyen</h2>
                <p class="text-3xl font-bold text-[#0D79DF]"><?php echo e(number_format($panierMoyen, 2, ',', ' ')); ?> FCFA</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Produit le plus vendu</h2>
                <?php if($produitPlusVendu): ?>
                    <p class="text-lg font-bold"><?php echo e($produitPlusVendu->designProd); ?></p>
                    <p class="text-slate-600">Quantité vendue : <?php echo e($produitPlusVendu->total_qte); ?></p>
                <?php else: ?>
                    <p class="text-slate-500">Aucune donnée disponible.</p>
                <?php endif; ?>
            </div>

            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Client le plus actif</h2>
                <?php if($clientLePlusActif): ?>
                    <p class="text-lg font-bold"><?php echo e($clientLePlusActif->prenomCli); ?> <?php echo e($clientLePlusActif->nomCli); ?></p>
                    <p class="text-slate-600">Nombre de commandes : <?php echo e($clientLePlusActif->commandes_count); ?></p>
                <?php else: ?>
                    <p class="text-slate-500">Aucune donnée disponible.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Stock faible</h2>
                <?php if($stockFaible->isNotEmpty()): ?>
                    <ul class="space-y-2">
                        <?php $__currentLoopData = $stockFaible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex justify-between border-b pb-2">
                                <span><?php echo e($produit->designProd); ?></span>
                                <span class="font-semibold text-amber-600"><?php echo e($produit->qteStock); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-slate-500">Aucun produit en stock faible.</p>
                <?php endif; ?>
            </div>

            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Commandes récentes</h2>
                <?php if($commandesRecentes->isNotEmpty()): ?>
                    <ul class="space-y-2">
                        <?php $__currentLoopData = $commandesRecentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="border-b pb-2">
                                <div class="font-semibold">Commande #<?php echo e($commande->idCmd); ?></div>
                                <div class="text-sm text-slate-600"><?php echo e($commande->client?->prenomCli); ?> <?php echo e($commande->client?->nomCli); ?> • <?php echo e($commande->dateCmd->format('d/m/Y')); ?></div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-slate-500">Aucune commande récente.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Groupe_9-Alban-Djingar-Mbaiarem-Gatin\TP2 Exam\gestion-commandes\resources\views\dashboard.blade.php ENDPATH**/ ?>