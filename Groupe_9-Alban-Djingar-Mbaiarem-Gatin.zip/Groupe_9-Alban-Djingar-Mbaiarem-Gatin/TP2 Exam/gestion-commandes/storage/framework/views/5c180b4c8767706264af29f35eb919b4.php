<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un client</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-100 text-slate-800">
<div class="mx-auto max-w-2xl px-4 py-10">
    <div class="mb-6 flex items-center justify-between gap-4">
        <h1 class="text-3xl font-bold">Ajouter un client</h1>
        <a href="<?php echo e(route('clients.index')); ?>" class="whitespace-nowrap rounded-lg bg-slate-800 px-4 py-2 text-white">Retour</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="mb-5 rounded-lg border border-red-300 bg-red-100 px-4 py-3 text-red-800">
            <ul class="list-inside list-disc">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('clients.store')); ?>" class="space-y-5 rounded-xl bg-white p-6 shadow">
        <?php echo csrf_field(); ?>

        <div>
            <label for="nomCli" class="mb-1 block font-medium">Nom</label>
            <input id="nomCli" name="nomCli" value="<?php echo e(old('nomCli')); ?>" maxlength="120" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="prenomCli" class="mb-1 block font-medium">Prénom</label>
            <input id="prenomCli" name="prenomCli" value="<?php echo e(old('prenomCli')); ?>" maxlength="120" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="email" class="mb-1 block font-medium">Adresse e-mail</label>
            <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" maxlength="255" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="idRegion" class="mb-1 block font-medium">Région</label>
            <select id="idRegion" name="idRegion" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
                <option value="">Choisir une région</option>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->idRegion); ?>" <?php if(old('idRegion') == $region->idRegion): echo 'selected'; endif; ?>>
                        <?php echo e($region->nomRegion); ?> — <?php echo e($region->departement?->nomDep); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="photo" class="mb-1 block font-medium">Lien de la photo (facultatif)</label>
            <input id="photo" name="photo" type="url" value="<?php echo e(old('photo')); ?>" maxlength="255" class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <button type="submit" class="w-full rounded-lg bg-emerald-600 px-5 py-3 font-semibold text-white hover:bg-emerald-700">
            Enregistrer le client
        </button>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Groupe_9-Alban-Djingar-Mbaiarem-Gatin\TP2 Exam\gestion-commandes\resources\views\clients\create.blade.php ENDPATH**/ ?>