<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits de commande</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold">Commande #<?php echo e($commande->idCmd); ?></h1>
            <p class="text-slate-600">Client : <?php echo e($commande->client?->prenomCli); ?> <?php echo e($commande->client?->nomCli); ?></p>
        </div>
        <a href="<?php echo e(route('commandes.index')); ?>" class="bg-slate-800 text-white px-4 py-2 rounded">Retour</a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-emerald-100 border border-emerald-400 text-emerald-700 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow p-6">
            <h2 class="text-xl font-semibold mb-4">Ajouter un produit</h2>
            <form method="POST" action="<?php echo e(route('commandes.produits.store', $commande)); ?>" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="block mb-2 font-medium">Produit</label>

                    <?php if($produits->isEmpty()): ?>
                        <p class="text-slate-500">Aucun produit disponible pour le moment.</p>
                    <?php else: ?>
                        <?php
                            $firstAvailableProduitId = $produits->first(fn ($produit) => $produit->qteStock > 0)?->idProd;
                        ?>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="block cursor-pointer <?php echo e($produit->qteStock <= 0 ? 'opacity-60 cursor-not-allowed' : ''); ?>">
                                    <input type="radio" name="idProd" value="<?php echo e($produit->idProd); ?>" class="sr-only" <?php echo e($produit->qteStock <= 0 ? 'disabled' : ''); ?> <?php echo e($firstAvailableProduitId === $produit->idProd ? 'required' : ''); ?>>
                                    <div class="flex items-center gap-3 rounded-lg border border-slate-200 p-2 transition hover:border-blue-300 hover:bg-blue-50">
                                        <img src="<?php echo e($produit->photoProd ?: 'https://placehold.co/80x80?text=Produit'); ?>" alt="<?php echo e($produit->designProd); ?>" class="h-14 w-14 object-cover rounded">
                                        <div class="text-sm min-w-0">
                                            <div class="font-medium truncate"><?php echo e($produit->designProd); ?></div>
                                            <div class="text-slate-500">
                                                <?php if($produit->qteStock > 0): ?>
                                                    Stock : <?php echo e($produit->qteStock); ?>

                                                <?php else: ?>
                                                    Rupture de stock
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="block mb-1 font-medium">Quantité</label>
                    <input type="number" name="qteCmd" min="1" value="1" class="w-full border rounded px-3 py-2">
                </div>

                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Ajouter à la commande</button>
            </form>
        </div>

        <div class="bg-white rounded-xl shadow p-6">
            <h2 class="text-xl font-semibold mb-4">Produits déjà associés</h2>
            <?php if($commande->produits->isNotEmpty()): ?>
                <table class="min-w-full text-left">
                    <thead class="bg-slate-800 text-white">
                    <tr>
                        <th class="px-3 py-2">Produit</th>
                        <th class="px-3 py-2">Qté</th>
                        <th class="px-3 py-2">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $commande->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="px-3 py-2">
                                <div class="flex items-center gap-3">
                                    <img src="<?php echo e($produit->photoProd ?: 'https://placehold.co/60x60?text=Produit'); ?>" alt="<?php echo e($produit->designProd); ?>" class="h-10 w-10 object-cover rounded">
                                    <span><?php echo e($produit->designProd); ?></span>
                                </div>
                            </td>
                            <td class="px-3 py-2"><?php echo e($produit->pivot->qteCmd); ?></td>
                            <td class="px-3 py-2">
                                <form method="POST" action="<?php echo e(route('commandes.produits.destroy', [$commande, $produit])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded text-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-slate-500">Aucun produit dans cette commande.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Groupe_9-Alban-Djingar-Mbaiarem-Gatin\TP2 Exam\gestion-commandes\resources\views/commandes/produits.blade.php ENDPATH**/ ?>