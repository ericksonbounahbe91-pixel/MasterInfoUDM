<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-7xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Liste des commandes</h1>
        <nav class="flex gap-3 flex-wrap items-center">
            <a href="<?php echo e(route('dashboard')); ?>" class="bg-slate-800 text-white px-4 py-2 rounded">Accueil</a>
            <a href="<?php echo e(route('clients.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Clients</a>
            <a href="<?php echo e(route('produits.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Produits</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-block">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </nav>
    </div>

    <div class="space-y-4">
        <?php $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="flex justify-between items-center mb-3">
                    <div>
                        <h2 class="text-xl font-semibold">Commande #<?php echo e($commande->idCmd); ?></h2>
                        <p class="text-sm text-slate-500">Client : <?php echo e($commande->client?->prenomCli); ?> <?php echo e($commande->client?->nomCli); ?></p>
                    </div>
                    <div>
                        <a href="<?php echo e(route('commandes.produits', $commande)); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">Gérer les produits</a>
                    </div>
                </div>

                <p class="mb-3"><span class="font-medium">Date :</span> <?php echo e($commande->dateCmd->format('d/m/Y')); ?></p>

                <?php if($commande->produits->isNotEmpty()): ?>
                    <div class="overflow-hidden rounded-lg border">
                        <table class="min-w-full text-left">
                            <thead class="bg-slate-800 text-white">
                            <tr>
                                <th class="px-4 py-3">Produit</th>
                                <th class="px-4 py-3">Quantité</th>
                                <th class="px-4 py-3">Prix unitaire</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $commande->produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b">
                                    <td class="px-4 py-3"><?php echo e($produit->designProd); ?></td>
                                    <td class="px-4 py-3"><?php echo e($produit->pivot->qteCmd); ?></td>
                                    <td class="px-4 py-3"><?php echo e(number_format($produit->prixUProd, 2, ',', ' ')); ?> FCFA</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-slate-500">Aucun produit associé.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Groupe_9-Alban-Djingar-Mbaiarem-Gatin\TP2 Exam\gestion-commandes\resources\views/commandes/index.blade.php ENDPATH**/ ?>