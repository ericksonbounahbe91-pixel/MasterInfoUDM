<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Liste des clients</h1>
        <nav class="flex gap-3 flex-wrap items-center">
            <a href="<?php echo e(route('dashboard')); ?>" class="bg-slate-800 text-white px-4 py-2 rounded">Accueil</a>
            <a href="<?php echo e(route('commandes.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Commandes</a>
            <a href="<?php echo e(route('produits.index')); ?>" class="bg-white px-4 py-2 rounded shadow">Produits</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-block">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </nav>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-5 rounded-lg border border-emerald-300 bg-emerald-100 px-4 py-3 text-emerald-800">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="mb-6 flex flex-col gap-3 rounded-xl bg-white p-4 shadow sm:flex-row sm:items-center sm:justify-between">
        <form method="GET" action="<?php echo e(route('clients.index')); ?>" class="flex flex-1 gap-2">
            <input
                type="search"
                name="search"
                value="<?php echo e($search); ?>"
                placeholder="Rechercher par nom, prénom ou e-mail"
                class="min-w-0 flex-1 rounded-lg border border-slate-300 px-4 py-2"
                aria-label="Rechercher un client"
            >
            <button type="submit" class="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700">
                Rechercher
            </button>
            <?php if($search !== ''): ?>
                <a href="<?php echo e(route('clients.index')); ?>" class="rounded-lg bg-slate-200 px-4 py-2 text-slate-700 hover:bg-slate-300">
                    Effacer
                </a>
            <?php endif; ?>
        </form>
        <a href="<?php echo e(route('clients.create')); ?>" class="whitespace-nowrap rounded-lg bg-emerald-600 px-5 py-2 text-center font-medium text-white hover:bg-emerald-700">
            + Ajouter un client
        </a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-hidden">
        <table class="min-w-full text-left">
            <thead class="bg-slate-800 text-white">
            <tr>
                <th class="px-4 py-3">Nom</th>
                <th class="px-4 py-3">Prénom</th>
                <th class="px-4 py-3">Email</th>
                <th class="px-4 py-3">Région</th>
                <th class="px-4 py-3">Département</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td class="px-4 py-3"><?php echo e($client->nomCli); ?></td>
                    <td class="px-4 py-3"><?php echo e($client->prenomCli); ?></td>
                    <td class="px-4 py-3"><?php echo e($client->email); ?></td>
                    <td class="px-4 py-3"><?php echo e($client->region?->nomRegion ?? 'N/A'); ?></td>
                    <td class="px-4 py-3"><?php echo e($client->region?->departement?->nomDep ?? 'N/A'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($clients->isEmpty()): ?>
                <tr>
                    <td colspan="5" class="px-4 py-8 text-center text-slate-500">
                        <?php echo e($search !== '' ? 'Aucun client ne correspond à cette recherche.' : 'Aucun client enregistré.'); ?>

                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Groupe_9-Alban-Djingar-Mbaiarem-Gatin\TP2 Exam\gestion-commandes\resources\views/clients/index.blade.php ENDPATH**/ ?>