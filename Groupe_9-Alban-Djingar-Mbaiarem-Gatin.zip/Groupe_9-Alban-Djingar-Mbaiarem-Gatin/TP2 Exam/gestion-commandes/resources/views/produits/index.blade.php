<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Liste des produits</h1>
        <nav class="flex gap-3 flex-wrap items-center">
            <a href="{{ route('dashboard') }}" class="bg-slate-800 text-white px-4 py-2 rounded">Accueil</a>
            <a href="{{ route('clients.index') }}" class="bg-white px-4 py-2 rounded shadow">Clients</a>
            <a href="{{ route('commandes.index') }}" class="bg-white px-4 py-2 rounded shadow">Commandes</a>
            <form method="POST" action="{{ route('logout') }}" class="inline-block">
                @csrf
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </nav>
    </div>

    @if(session('success'))
        <div class="bg-emerald-100 border border-emerald-400 text-emerald-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    <div class="bg-white rounded-xl shadow overflow-hidden">
        <table class="min-w-full text-left">
            <thead class="bg-slate-800 text-white">
            <tr>
                <th class="px-4 py-3">Image</th>
                <th class="px-4 py-3">Produit</th>
                <th class="px-4 py-3">Stock</th>
                <th class="px-4 py-3">Prix unitaire</th>
                <th class="px-4 py-3">Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach($produits as $produit)
                <tr class="border-b align-middle">
                    <td class="px-4 py-3">
                        <img src="{{ $produit->photoProd ?: 'https://placehold.co/80x80?text=Produit' }}" alt="{{ $produit->designProd }}" class="h-16 w-16 object-cover rounded shadow-sm">
                    </td>
                    <td class="px-4 py-3 font-medium">{{ $produit->designProd }}</td>
                    <td class="px-4 py-3">{{ $produit->qteStock }}</td>
                    <td class="px-4 py-3">{{ number_format($produit->prixUProd, 2, ',', ' ') }} FCFA</td>
                    <td class="px-4 py-3">
                        <a href="{{ route('produits.edit', $produit) }}" class="bg-amber-500 text-white px-3 py-1 rounded">Modifier</a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
