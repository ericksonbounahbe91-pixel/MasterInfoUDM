<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un produit</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Modifier le produit</h1>
        <div class="flex items-center gap-3">
            <a href="{{ route('produits.index') }}" class="bg-slate-800 text-white px-4 py-2 rounded">Retour</a>
            <form method="POST" action="{{ route('logout') }}" class="inline-block">
                @csrf
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow p-6">
        <form method="POST" action="{{ route('produits.update', $produit) }}" class="space-y-4">
            @csrf
            @method('PUT')

            <div>
                <label class="block mb-1 font-medium">Désignation</label>
                <input type="text" name="designProd" value="{{ old('designProd', $produit->designProd) }}" class="w-full border rounded px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 font-medium">Stock</label>
                <input type="number" name="qteStock" value="{{ old('qteStock', $produit->qteStock) }}" min="0" class="w-full border rounded px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 font-medium">Prix unitaire</label>
                <input type="number" step="0.01" name="prixUProd" value="{{ old('prixUProd', $produit->prixUProd) }}" min="0" class="w-full border rounded px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 font-medium">Photo</label>
                <input type="text" name="photoProd" value="{{ old('photoProd', $produit->photoProd) }}" class="w-full border rounded px-3 py-2">
            </div>

            <button type="submit" class="bg-emerald-600 text-white px-4 py-2 rounded">Enregistrer les modifications</button>
        </form>
    </div>
</div>
</body>
</html>
