<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Gestion des commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0D79DF] text-[#04506E]">
    <div class="max-w-7xl mx-auto py-10 px-4">
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold">Tableau de bord</h1>
                <p class="text-[#04506E]">Statistiques de la ligne de commande</p>
            </div>
            <nav class="flex gap-3 flex-wrap items-center">
                <a href="{{ route('dashboard') }}" class="bg-[#04506E] text-white px-4 py-2 rounded">Accueil</a>
                <a href="{{ route('clients.index') }}" class="bg-white px-4 py-2 rounded shadow">Clients</a>
                <a href="{{ route('commandes.index') }}" class="bg-white px-4 py-2 rounded shadow">Commandes</a>
                <a href="{{ route('produits.index') }}" class="bg-white px-4 py-2 rounded shadow">Produits</a>
                <form method="POST" action="{{ route('logout') }}" class="inline-block">
                    @csrf
                    <button type="submit" class="bg-[#04506E] text-white px-4 py-2 rounded">Déconnexion</button>
                </form>
            </nav>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Clients</div>
                <div class="text-3xl font-bold">{{ $totalClients }}</div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Commandes</div>
                <div class="text-3xl font-bold">{{ $totalCommandes }}</div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Produits</div>
                <div class="text-3xl font-bold">{{ $totalProduits }}</div>
            </div>
            <div class="bg-white rounded-xl shadow p-5">
                <div class="text-sm text-slate-500">Quantité vendue</div>
                <div class="text-3xl font-bold">{{ $totalQteVendue }}</div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-3">Chiffre d'affaires</h2>
                <p class="text-3xl font-bold text-[#04506E]">{{ number_format($chiffreAffaires, 2, ',', ' ') }} FCFA</p>
            </div>
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-3">Panier moyen</h2>
                <p class="text-3xl font-bold text-[#0D79DF]">{{ number_format($panierMoyen, 2, ',', ' ') }} FCFA</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Produit le plus vendu</h2>
                @if($produitPlusVendu)
                    <p class="text-lg font-bold">{{ $produitPlusVendu->designProd }}</p>
                    <p class="text-slate-600">Quantité vendue : {{ $produitPlusVendu->total_qte }}</p>
                @else
                    <p class="text-slate-500">Aucune donnée disponible.</p>
                @endif
            </div>

            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Client le plus actif</h2>
                @if($clientLePlusActif)
                    <p class="text-lg font-bold">{{ $clientLePlusActif->prenomCli }} {{ $clientLePlusActif->nomCli }}</p>
                    <p class="text-slate-600">Nombre de commandes : {{ $clientLePlusActif->commandes_count }}</p>
                @else
                    <p class="text-slate-500">Aucune donnée disponible.</p>
                @endif
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Stock faible</h2>
                @if($stockFaible->isNotEmpty())
                    <ul class="space-y-2">
                        @foreach($stockFaible as $produit)
                            <li class="flex justify-between border-b pb-2">
                                <span>{{ $produit->designProd }}</span>
                                <span class="font-semibold text-amber-600">{{ $produit->qteStock }}</span>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <p class="text-slate-500">Aucun produit en stock faible.</p>
                @endif
            </div>

            <div class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold mb-4">Commandes récentes</h2>
                @if($commandesRecentes->isNotEmpty())
                    <ul class="space-y-2">
                        @foreach($commandesRecentes as $commande)
                            <li class="border-b pb-2">
                                <div class="font-semibold">Commande #{{ $commande->idCmd }}</div>
                                <div class="text-sm text-slate-600">{{ $commande->client?->prenomCli }} {{ $commande->client?->nomCli }} • {{ $commande->dateCmd->format('d/m/Y') }}</div>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <p class="text-slate-500">Aucune commande récente.</p>
                @endif
            </div>
        </div>
    </div>
</body>
</html>
