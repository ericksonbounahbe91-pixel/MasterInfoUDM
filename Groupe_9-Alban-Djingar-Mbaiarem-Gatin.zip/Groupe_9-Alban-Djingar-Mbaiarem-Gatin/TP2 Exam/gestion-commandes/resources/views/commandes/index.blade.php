<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-7xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Liste des commandes</h1>
        <nav class="flex gap-3 flex-wrap items-center">
            <a href="{{ route('dashboard') }}" class="bg-slate-800 text-white px-4 py-2 rounded">Accueil</a>
            <a href="{{ route('clients.index') }}" class="bg-white px-4 py-2 rounded shadow">Clients</a>
            <a href="{{ route('produits.index') }}" class="bg-white px-4 py-2 rounded shadow">Produits</a>
            <form method="POST" action="{{ route('logout') }}" class="inline-block">
                @csrf
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </nav>
    </div>

    <div class="space-y-4">
        @foreach($commandes as $commande)
            <div class="bg-white rounded-xl shadow p-5">
                <div class="flex justify-between items-center mb-3">
                    <div>
                        <h2 class="text-xl font-semibold">Commande #{{ $commande->idCmd }}</h2>
                        <p class="text-sm text-slate-500">Client : {{ $commande->client?->prenomCli }} {{ $commande->client?->nomCli }}</p>
                    </div>
                    <div>
                        <a href="{{ route('commandes.produits', $commande) }}" class="bg-blue-600 text-white px-4 py-2 rounded">Gérer les produits</a>
                    </div>
                </div>

                <p class="mb-3"><span class="font-medium">Date :</span> {{ $commande->dateCmd->format('d/m/Y') }}</p>

                @if($commande->produits->isNotEmpty())
                    <div class="overflow-hidden rounded-lg border">
                        <table class="min-w-full text-left">
                            <thead class="bg-slate-800 text-white">
                            <tr>
                                <th class="px-4 py-3">Produit</th>
                                <th class="px-4 py-3">Quantité</th>
                                <th class="px-4 py-3">Prix unitaire</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($commande->produits as $produit)
                                <tr class="border-b">
                                    <td class="px-4 py-3">{{ $produit->designProd }}</td>
                                    <td class="px-4 py-3">{{ $produit->pivot->qteCmd }}</td>
                                    <td class="px-4 py-3">{{ number_format($produit->prixUProd, 2, ',', ' ') }} FCFA</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <p class="text-slate-500">Aucun produit associé.</p>
                @endif
            </div>
        @endforeach
    </div>
</div>
</body>
</html>
