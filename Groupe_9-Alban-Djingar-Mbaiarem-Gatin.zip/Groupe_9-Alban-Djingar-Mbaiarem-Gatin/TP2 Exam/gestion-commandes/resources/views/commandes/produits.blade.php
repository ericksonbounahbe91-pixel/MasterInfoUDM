<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits de commande</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold">Commande #{{ $commande->idCmd }}</h1>
            <p class="text-slate-600">Client : {{ $commande->client?->prenomCli }} {{ $commande->client?->nomCli }}</p>
        </div>
        <a href="{{ route('commandes.index') }}" class="bg-slate-800 text-white px-4 py-2 rounded">Retour</a>
    </div>

    @if(session('success'))
        <div class="bg-emerald-100 border border-emerald-400 text-emerald-700 px-4 py-3 rounded mb-6">
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow p-6">
            <h2 class="text-xl font-semibold mb-4">Ajouter un produit</h2>
            <form method="POST" action="{{ route('commandes.produits.store', $commande) }}" class="space-y-4">
                @csrf
                <div>
                    <label class="block mb-2 font-medium">Produit</label>

                    @if($produits->isEmpty())
                        <p class="text-slate-500">Aucun produit disponible pour le moment.</p>
                    @else
                        @php
                            $firstAvailableProduitId = $produits->first(fn ($produit) => $produit->qteStock > 0)?->idProd;
                        @endphp
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            @foreach($produits as $produit)
                                <label class="block cursor-pointer {{ $produit->qteStock <= 0 ? 'opacity-60 cursor-not-allowed' : '' }}">
                                    <input type="radio" name="idProd" value="{{ $produit->idProd }}" class="sr-only" {{ $produit->qteStock <= 0 ? 'disabled' : '' }} {{ $firstAvailableProduitId === $produit->idProd ? 'required' : '' }}>
                                    <div class="flex items-center gap-3 rounded-lg border border-slate-200 p-2 transition hover:border-blue-300 hover:bg-blue-50">
                                        <img src="{{ $produit->photoProd ?: 'https://placehold.co/80x80?text=Produit' }}" alt="{{ $produit->designProd }}" class="h-14 w-14 object-cover rounded">
                                        <div class="text-sm min-w-0">
                                            <div class="font-medium truncate">{{ $produit->designProd }}</div>
                                            <div class="text-slate-500">
                                                @if($produit->qteStock > 0)
                                                    Stock : {{ $produit->qteStock }}
                                                @else
                                                    Rupture de stock
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </label>
                            @endforeach
                        </div>
                    @endif
                </div>

                <div>
                    <label class="block mb-1 font-medium">Quantité</label>
                    <input type="number" name="qteCmd" min="1" value="1" class="w-full border rounded px-3 py-2">
                </div>

                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Ajouter à la commande</button>
            </form>
        </div>

        <div class="bg-white rounded-xl shadow p-6">
            <h2 class="text-xl font-semibold mb-4">Produits déjà associés</h2>
            @if($commande->produits->isNotEmpty())
                <table class="min-w-full text-left">
                    <thead class="bg-slate-800 text-white">
                    <tr>
                        <th class="px-3 py-2">Produit</th>
                        <th class="px-3 py-2">Qté</th>
                        <th class="px-3 py-2">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($commande->produits as $produit)
                        <tr class="border-b">
                            <td class="px-3 py-2">
                                <div class="flex items-center gap-3">
                                    <img src="{{ $produit->photoProd ?: 'https://placehold.co/60x60?text=Produit' }}" alt="{{ $produit->designProd }}" class="h-10 w-10 object-cover rounded">
                                    <span>{{ $produit->designProd }}</span>
                                </div>
                            </td>
                            <td class="px-3 py-2">{{ $produit->pivot->qteCmd }}</td>
                            <td class="px-3 py-2">
                                <form method="POST" action="{{ route('commandes.produits.destroy', [$commande, $produit]) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded text-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            @else
                <p class="text-slate-500">Aucun produit dans cette commande.</p>
            @endif
        </div>
    </div>
</div>
</body>
</html>
