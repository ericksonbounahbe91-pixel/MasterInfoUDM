<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-800">
<div class="max-w-6xl mx-auto py-10 px-4">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-bold">Liste des clients</h1>
        <nav class="flex gap-3 flex-wrap items-center">
            <a href="{{ route('dashboard') }}" class="bg-slate-800 text-white px-4 py-2 rounded">Accueil</a>
            <a href="{{ route('commandes.index') }}" class="bg-white px-4 py-2 rounded shadow">Commandes</a>
            <a href="{{ route('produits.index') }}" class="bg-white px-4 py-2 rounded shadow">Produits</a>
            <form method="POST" action="{{ route('logout') }}" class="inline-block">
                @csrf
                <button type="submit" class="bg-rose-600 text-white px-4 py-2 rounded">Déconnexion</button>
            </form>
        </nav>
    </div>

    @if(session('success'))
        <div class="mb-5 rounded-lg border border-emerald-300 bg-emerald-100 px-4 py-3 text-emerald-800">
            {{ session('success') }}
        </div>
    @endif

    <div class="mb-6 flex flex-col gap-3 rounded-xl bg-white p-4 shadow sm:flex-row sm:items-center sm:justify-between">
        <form method="GET" action="{{ route('clients.index') }}" class="flex flex-1 gap-2">
            <input
                type="search"
                name="search"
                value="{{ $search }}"
                placeholder="Rechercher par nom, prénom ou e-mail"
                class="min-w-0 flex-1 rounded-lg border border-slate-300 px-4 py-2"
                aria-label="Rechercher un client"
            >
            <button type="submit" class="rounded-lg bg-blue-600 px-5 py-2 font-medium text-white hover:bg-blue-700">
                Rechercher
            </button>
            @if($search !== '')
                <a href="{{ route('clients.index') }}" class="rounded-lg bg-slate-200 px-4 py-2 text-slate-700 hover:bg-slate-300">
                    Effacer
                </a>
            @endif
        </form>
        <a href="{{ route('clients.create') }}" class="whitespace-nowrap rounded-lg bg-emerald-600 px-5 py-2 text-center font-medium text-white hover:bg-emerald-700">
            + Ajouter un client
        </a>
    </div>

    <div class="bg-white rounded-xl shadow overflow-hidden">
        <table class="min-w-full text-left">
            <thead class="bg-slate-800 text-white">
            <tr>
                <th class="px-4 py-3">Nom</th>
                <th class="px-4 py-3">Prénom</th>
                <th class="px-4 py-3">Email</th>
                <th class="px-4 py-3">Région</th>
                <th class="px-4 py-3">Département</th>
            </tr>
            </thead>
            <tbody>
            @foreach($clients as $client)
                <tr class="border-b">
                    <td class="px-4 py-3">{{ $client->nomCli }}</td>
                    <td class="px-4 py-3">{{ $client->prenomCli }}</td>
                    <td class="px-4 py-3">{{ $client->email }}</td>
                    <td class="px-4 py-3">{{ $client->region?->nomRegion ?? 'N/A' }}</td>
                    <td class="px-4 py-3">{{ $client->region?->departement?->nomDep ?? 'N/A' }}</td>
                </tr>
            @endforeach
            @if($clients->isEmpty())
                <tr>
                    <td colspan="5" class="px-4 py-8 text-center text-slate-500">
                        {{ $search !== '' ? 'Aucun client ne correspond à cette recherche.' : 'Aucun client enregistré.' }}
                    </td>
                </tr>
            @endif
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
