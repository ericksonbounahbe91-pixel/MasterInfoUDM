<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un client</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-100 text-slate-800">
<div class="mx-auto max-w-2xl px-4 py-10">
    <div class="mb-6 flex items-center justify-between gap-4">
        <h1 class="text-3xl font-bold">Ajouter un client</h1>
        <a href="{{ route('clients.index') }}" class="whitespace-nowrap rounded-lg bg-slate-800 px-4 py-2 text-white">Retour</a>
    </div>

    @if($errors->any())
        <div class="mb-5 rounded-lg border border-red-300 bg-red-100 px-4 py-3 text-red-800">
            <ul class="list-inside list-disc">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('clients.store') }}" class="space-y-5 rounded-xl bg-white p-6 shadow">
        @csrf

        <div>
            <label for="nomCli" class="mb-1 block font-medium">Nom</label>
            <input id="nomCli" name="nomCli" value="{{ old('nomCli') }}" maxlength="120" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="prenomCli" class="mb-1 block font-medium">Prénom</label>
            <input id="prenomCli" name="prenomCli" value="{{ old('prenomCli') }}" maxlength="120" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="email" class="mb-1 block font-medium">Adresse e-mail</label>
            <input id="email" name="email" type="email" value="{{ old('email') }}" maxlength="255" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <div>
            <label for="idRegion" class="mb-1 block font-medium">Région</label>
            <select id="idRegion" name="idRegion" required class="w-full rounded-lg border border-slate-300 px-4 py-2">
                <option value="">Choisir une région</option>
                @foreach($regions as $region)
                    <option value="{{ $region->idRegion }}" @selected(old('idRegion') == $region->idRegion)>
                        {{ $region->nomRegion }} — {{ $region->departement?->nomDep }}
                    </option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="photo" class="mb-1 block font-medium">Lien de la photo (facultatif)</label>
            <input id="photo" name="photo" type="url" value="{{ old('photo') }}" maxlength="255" class="w-full rounded-lg border border-slate-300 px-4 py-2">
        </div>

        <button type="submit" class="w-full rounded-lg bg-emerald-600 px-5 py-3 font-semibold text-white hover:bg-emerald-700">
            Enregistrer le client
        </button>
    </form>
</div>
</body>
</html>
