<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Gestion des commandes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0D79DF] text-[#04506E] min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-[#04506E] px-8 py-6 text-white">
                <h1 class="text-3xl font-bold">Connexion</h1>
            </div>

            <div class="p-8">
                @if($errors->any())
                    <div class="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        {{ $errors->first() }}
                    </div>
                @endif

                <form method="POST" action="{{ route('login.submit') }}" class="space-y-5">
                    @csrf

                    <div>
                        <label for="login" class="mb-2 block text-sm font-medium text-[#04506E]">Utilisateur</label>
                        <input id="login" name="login" type="text" value="{{ old('login') }}" placeholder="" class="w-full rounded-lg border border-slate-300 px-4 py-3 focus:border-[#0D79DF] focus:outline-none" required>
                    </div>

                    <div>
                        <label for="password" class="mb-2 block text-sm font-medium text-[#04506E]">Mot de passe</label>
                        <input id="password" name="password" type="password" placeholder="••••••••••" class="w-full rounded-lg border border-slate-300 px-4 py-3 focus:border-[#0D79DF] focus:outline-none" required>
                    </div>

                    <button type="submit" class="w-full rounded-lg bg-[#04506E] px-4 py-3 text-white font-semibold transition hover:bg-[#0D79DF]">
                        Se connecter
                    </button>
                </form>

            </div>
        </div>
    </div>
</body>
</html>
