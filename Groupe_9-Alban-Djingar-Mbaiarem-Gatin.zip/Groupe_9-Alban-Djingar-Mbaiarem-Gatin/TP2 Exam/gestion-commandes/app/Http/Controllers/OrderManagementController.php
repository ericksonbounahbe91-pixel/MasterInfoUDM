<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Commande;
use App\Models\Produit;
use App\Models\Region;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class OrderManagementController extends Controller
{
    private const LOGIN_USERNAME = 'MasTMound2';

    private const LOGIN_PASSWORD = 'MoundMasT2@2026';

    private function hasRequiredTables(): bool
    {
        return Schema::hasTable('clients')
            && Schema::hasTable('commandes')
            && Schema::hasTable('produits')
            && Schema::hasTable('ligne_commandes');
    }

    public function showLogin(): View
    {
        if (session('is_logged_in')) {
            return redirect()->route('dashboard');
        }

        return view('login');
    }

    public function login(Request $request): \Illuminate\Http\RedirectResponse
    {
        $credentials = $request->validate([
            'login' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $login = trim((string) $credentials['login']);
        $password = trim((string) $credentials['password']);

        if (
            $login === self::LOGIN_USERNAME
            && $password === self::LOGIN_PASSWORD
        ) {
            session(['is_logged_in' => true, 'user_name' => self::LOGIN_USERNAME]);

            return redirect()->route('dashboard');
        }

        return back()->withErrors([
            'login' => 'Identifiants invalides. Veuillez vérifier votre utilisateur et votre mot de passe.',
        ])->withInput();
    }

    public function logout(): \Illuminate\Http\RedirectResponse
    {
        session()->forget(['is_logged_in', 'user_name']);
        session()->invalidate();
        session()->regenerateToken();

        return redirect()->route('login');
    }

    public function dashboard(): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return view('login');
        }

        if (! $this->hasRequiredTables()) {
            return view('dashboard', [
                'totalClients' => 0,
                'totalCommandes' => 0,
                'totalProduits' => 0,
                'totalQteVendue' => 0,
                'chiffreAffaires' => 0,
                'produitPlusVendu' => null,
                'stockFaible' => collect(),
                'clientLePlusActif' => null,
                'panierMoyen' => 0,
                'commandesRecentes' => collect(),
            ]);
        }

        $totalClients = Client::count();
        $totalCommandes = Commande::count();
        $totalProduits = Produit::count();
        $totalQteVendue = DB::table('ligne_commandes')->sum('qteCmd');

        $chiffreAffaires = DB::table('ligne_commandes as lc')
            ->join('produits as p', 'p.idProd', '=', 'lc.idProd')
            ->selectRaw('SUM(lc.qteCmd * p.prixUProd) as total')
            ->value('total') ?? 0;

        $produitPlusVendu = DB::table('ligne_commandes as lc')
            ->join('produits as p', 'p.idProd', '=', 'lc.idProd')
            ->select('p.designProd', DB::raw('SUM(lc.qteCmd) as total_qte'))
            ->groupBy('p.idProd', 'p.designProd')
            ->orderByDesc('total_qte')
            ->first();

        $stockFaible = Produit::where('qteStock', '<=', 10)
            ->orderBy('qteStock', 'asc')
            ->get();

        $clientLePlusActif = Client::withCount('commandes')
            ->orderByDesc('commandes_count')
            ->first();

        $panierMoyen = DB::table('commandes as c')
            ->leftJoin('ligne_commandes as lc', 'lc.idCmd', '=', 'c.idCmd')
            ->leftJoin('produits as p', 'p.idProd', '=', 'lc.idProd')
            ->selectRaw('AVG(lc.qteCmd * p.prixUProd) as moyen')
            ->value('moyen') ?? 0;

        $commandesRecentes = Commande::with('client')->orderByDesc('dateCmd')->limit(5)->get();

        return view('dashboard', compact(
            'totalClients',
            'totalCommandes',
            'totalProduits',
            'totalQteVendue',
            'chiffreAffaires',
            'produitPlusVendu',
            'stockFaible',
            'clientLePlusActif',
            'panierMoyen',
            'commandesRecentes'
        ));
    }

    public function clients(Request $request): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $search = trim((string) $request->query('search', ''));
        $clients = collect();

        if (Schema::hasTable('clients')) {
            $clients = Client::with('region.departement')
                ->when($search !== '', function ($query) use ($search) {
                    $query->where(function ($query) use ($search) {
                        $query->where('nomCli', 'like', '%' . $search . '%')
                            ->orWhere('prenomCli', 'like', '%' . $search . '%')
                            ->orWhere('email', 'like', '%' . $search . '%');
                    });
                })
                ->orderBy('nomCli')
                ->get();
        }

        return view('clients.index', compact('clients', 'search'));
    }

    public function createClient(): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $regions = Region::with('departement')->orderBy('nomRegion')->get();

        return view('clients.create', compact('regions'));
    }

    public function storeClient(Request $request): \Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $validated = $request->validate([
            'nomCli' => ['required', 'string', 'max:120'],
            'prenomCli' => ['required', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:255', 'unique:clients,email'],
            'idRegion' => ['required', 'exists:regions,idRegion'],
            'photo' => ['nullable', 'url', 'max:255'],
        ], [
            'nomCli.required' => 'Le nom du client est obligatoire.',
            'prenomCli.required' => 'Le prénom du client est obligatoire.',
            'email.required' => 'L’adresse e-mail est obligatoire.',
            'email.email' => 'Veuillez saisir une adresse e-mail valide.',
            'email.unique' => 'Cette adresse e-mail est déjà utilisée.',
            'idRegion.required' => 'Veuillez choisir une région.',
            'idRegion.exists' => 'La région sélectionnée est invalide.',
            'photo.url' => 'Le lien de la photo doit être une URL valide.',
        ]);

        Client::create($validated);

        return redirect()->route('clients.index')->with('success', 'Le client a été ajouté avec succès.');
    }

    public function produits(): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $produits = Schema::hasTable('produits')
            ? Produit::orderBy('designProd')->get()
            : collect();

        return view('produits.index', compact('produits'));
    }

    public function commandes(): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $commandes = Schema::hasTable('commandes')
            ? Commande::with(['client.region.departement', 'produits'])->orderByDesc('dateCmd')->get()
            : collect();

        return view('commandes.index', compact('commandes'));
    }

    public function showCommandeProduits(Commande $commande): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $commande->load(['client', 'produits']);
        $produits = Produit::orderBy('designProd')->get();

        return view('commandes.produits', compact('commande', 'produits'));
    }

    public function storeProduitCommande(Request $request, Commande $commande): \Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }
        $validated = $request->validate([
            'idProd' => ['required', 'exists:produits,idProd'],
            'qteCmd' => ['required', 'integer', 'min:1'],
        ], [
            'idProd.required' => 'Le produit est obligatoire.',
            'idProd.exists' => 'Ce produit n’existe pas.',
            'qteCmd.required' => 'La quantité est obligatoire.',
            'qteCmd.integer' => 'La quantité doit être un nombre entier.',
            'qteCmd.min' => 'La quantité doit être supérieure à 0.',
        ]);

        $produit = Produit::findOrFail($validated['idProd']);
        $nouvelleQuantite = $validated['qteCmd'];

        if ($commande->produits()->where('produits.idProd', $produit->idProd)->exists()) {
            $quantiteActuelle = (int) $commande->produits()->where('produits.idProd', $produit->idProd)->first()->pivot->qteCmd;
            $nouvelleQuantite += $quantiteActuelle;
        }

        if ($nouvelleQuantite > $produit->qteStock) {
            return back()->withErrors([
                'qteCmd' => 'Stock insuffisant pour ce produit. Quantité disponible : ' . $produit->qteStock,
            ])->withInput();
        }

        if ($commande->produits()->where('produits.idProd', $produit->idProd)->exists()) {
            $commande->produits()->updateExistingPivot($produit->idProd, ['qteCmd' => $nouvelleQuantite]);
        } else {
            $commande->produits()->attach($produit->idProd, ['qteCmd' => $validated['qteCmd']]);
        }

        return redirect()->route('commandes.produits', $commande)->with('success', 'Produit ajouté à la commande avec succès.');
    }

    public function editProduit(Produit $produit): View|\Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        return view('produits.edit', compact('produit'));
    }

    public function updateProduit(Request $request, Produit $produit): \Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $validated = $request->validate([
            'designProd' => ['required', 'string', 'max:180'],
            'qteStock' => ['required', 'integer', 'min:0'],
            'prixUProd' => ['required', 'numeric', 'min:0'],
            'photoProd' => ['nullable', 'string', 'max:255'],
        ], [
            'designProd.required' => 'Le nom du produit est obligatoire.',
            'qteStock.required' => 'Le stock est obligatoire.',
            'qteStock.integer' => 'Le stock doit être un entier.',
            'prixUProd.required' => 'Le prix unitaire est obligatoire.',
            'prixUProd.numeric' => 'Le prix unitaire doit être numérique.',
        ]);

        $produit->update($validated);

        return redirect()->route('produits.index')->with('success', 'Produit modifié avec succès.');
    }

    public function destroyProduitCommande(Commande $commande, Produit $produit): \Illuminate\Http\RedirectResponse
    {
        if (! session('is_logged_in')) {
            return redirect()->route('login');
        }

        $commande->produits()->detach($produit->idProd);

        return redirect()->route('commandes.produits', $commande)->with('success', 'Produit supprimé de la commande.');
    }
}
