<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Client extends Model
{
    protected $primaryKey = 'idCli';

    protected $fillable = ['nomCli', 'prenomCli', 'email', 'photo', 'idRegion'];

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class, 'idRegion', 'idRegion');
    }

    public function commandes(): HasMany
    {
        return $this->hasMany(Commande::class, 'idCli', 'idCli');
    }
}
