<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Commande extends Model
{
    protected $primaryKey = 'idCmd';

    protected $fillable = ['dateCmd', 'idCli'];

    protected $casts = ['dateCmd' => 'date'];

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'idCli', 'idCli');
    }

    public function produits(): BelongsToMany
    {
        return $this->belongsToMany(Produit::class, 'ligne_commandes', 'idCmd', 'idProd', 'idCmd', 'idProd')
            ->withPivot('qteCmd')
            ->withTimestamps();
    }
}
