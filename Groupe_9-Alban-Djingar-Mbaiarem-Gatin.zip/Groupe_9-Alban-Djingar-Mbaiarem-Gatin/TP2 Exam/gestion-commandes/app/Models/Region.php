<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Region extends Model
{
    protected $primaryKey = 'idRegion';

    protected $fillable = ['nomRegion', 'idDep'];

    public function departement(): BelongsTo
    {
        return $this->belongsTo(Departement::class, 'idDep', 'idDep');
    }

    public function clients(): HasMany
    {
        return $this->hasMany(Client::class, 'idRegion', 'idRegion');
    }
}
