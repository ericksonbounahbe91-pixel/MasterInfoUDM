<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Produit extends Model
{
    protected $primaryKey = 'idProd';

    protected $fillable = ['designProd', 'qteStock', 'prixUProd', 'photoProd'];

    protected $casts = [
        'qteStock' => 'integer',
        'prixUProd' => 'decimal:2',
    ];

    public function commandes(): BelongsToMany
    {
        return $this->belongsToMany(Commande::class, 'ligne_commandes', 'idProd', 'idCmd', 'idProd', 'idCmd')
            ->withPivot('qteCmd')
            ->withTimestamps();
    }
}
