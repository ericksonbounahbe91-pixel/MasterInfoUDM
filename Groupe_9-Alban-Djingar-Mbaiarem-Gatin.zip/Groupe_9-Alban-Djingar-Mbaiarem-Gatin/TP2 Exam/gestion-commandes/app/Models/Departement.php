<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Departement extends Model
{
    protected $primaryKey = 'idDep';

    protected $fillable = ['nomDep'];

    public function regions(): HasMany
    {
        return $this->hasMany(Region::class, 'idDep', 'idDep');
    }
}
