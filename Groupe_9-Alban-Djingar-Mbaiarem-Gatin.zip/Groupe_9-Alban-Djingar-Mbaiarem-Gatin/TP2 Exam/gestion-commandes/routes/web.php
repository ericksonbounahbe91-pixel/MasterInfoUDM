<?php

use App\Http\Controllers\OrderManagementController;
use Illuminate\Support\Facades\Route;

Route::get('/login', [OrderManagementController::class, 'showLogin'])->name('login');
Route::post('/login', [OrderManagementController::class, 'login'])->name('login.submit');
Route::post('/logout', [OrderManagementController::class, 'logout'])->name('logout');

Route::get('/', [OrderManagementController::class, 'dashboard'])->name('dashboard');
Route::get('/clients/create', [OrderManagementController::class, 'createClient'])->name('clients.create');
Route::post('/clients', [OrderManagementController::class, 'storeClient'])->name('clients.store');
Route::get('/clients', [OrderManagementController::class, 'clients'])->name('clients.index');
Route::get('/commandes', [OrderManagementController::class, 'commandes'])->name('commandes.index');
Route::get('/commandes/{commande}/produits', [OrderManagementController::class, 'showCommandeProduits'])->name('commandes.produits');
Route::post('/commandes/{commande}/produits', [OrderManagementController::class, 'storeProduitCommande'])->name('commandes.produits.store');
Route::delete('/commandes/{commande}/produits/{produit}', [OrderManagementController::class, 'destroyProduitCommande'])->name('commandes.produits.destroy');
Route::get('/produits', [OrderManagementController::class, 'produits'])->name('produits.index');
Route::get('/produits/{produit}/edit', [OrderManagementController::class, 'editProduit'])->name('produits.edit');
Route::put('/produits/{produit}', [OrderManagementController::class, 'updateProduit'])->name('produits.update');
