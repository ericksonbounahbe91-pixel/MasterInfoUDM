package com.example.apkcommande

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
