<?php require 'includes/header.php'; ?>
<h1>Gestion d'une ligne de commande</h1>
<div class="card"><ul>
 <li><a href="produits.php">Liste / modification des produits</a></li>
 <li><a href="commandes.php">Liste des commandes (saisie et suppression de lignes)</a></li>
 <li><a href="clients.php">Liste des clients</a></li>
 <li><a href="dashboard.php">Tableau de bord statistique</a></li>
</ul></div>
<?php require 'includes/footer.php'; ?>
