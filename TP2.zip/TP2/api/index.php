<?php
// API JSON consommée par l'application Flutter.  Usage : api/index.php?r=<ressource>[&id=..]
require_once __DIR__ . '/../includes/db.php';
header('Content-Type: application/json; charset=utf-8');

function out($data, int $code = 200): never { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $msg, int $code = 400): never { out(['error' => $msg], $code); }
function body(): array { $j = json_decode(file_get_contents('php://input'), true); return is_array($j) ? $j : []; }
function int_or_null($v, int $min = 0): ?int { $o = filter_var($v, FILTER_VALIDATE_INT); return ($o === false || $o < $min) ? null : $o; }

$pdo = db();
$m = $_SERVER['REQUEST_METHOD'];
$r = $_GET['r'] ?? '';
$id = int_or_null($_GET['id'] ?? null, 1);

try {
    switch ($r) {
    // ---------------------------------------------------------------- produits
    case 'produits':
        if ($m === 'GET') out($pdo->query('SELECT idProd, designProd, qteStock, prixUProd FROM produit ORDER BY designProd')->fetchAll());
        if ($m === 'POST' || $m === 'PUT') {
            $b = body();
            $design = trim((string)($b['designProd'] ?? ''));
            $stock = int_or_null($b['qteStock'] ?? null);
            $prix = filter_var($b['prixUProd'] ?? null, FILTER_VALIDATE_FLOAT);
            if ($design === '' || $stock === null || $prix === false || $prix < 0) fail('Données produit invalides.');
            if ($m === 'POST') {
                $pdo->prepare('INSERT INTO produit(designProd,qteStock,prixUProd) VALUES (?,?,?)')->execute([$design, $stock, $prix]);
                out(['idProd' => (int)$pdo->lastInsertId()], 201);
            }
            if (!$id) fail('id requis.');
            $st = $pdo->prepare('UPDATE produit SET designProd=?, qteStock=?, prixUProd=? WHERE idProd=?');
            $st->execute([$design, $stock, $prix, $id]);
            out(['ok' => true]);
        }
        if ($m === 'DELETE') {
            if (!$id) fail('id requis.');
            $s = $pdo->prepare('SELECT COUNT(*) FROM ligneCommande WHERE idProd=?'); $s->execute([$id]);
            if ($s->fetchColumn() > 0) fail('Suppression impossible : produit présent dans des commandes.', 409);
            $pdo->prepare('DELETE FROM produit WHERE idProd=?')->execute([$id]);
            out(['ok' => true]);
        }
        break;

    // ---------------------------------------------------------------- clients / régions
    case 'clients':
        if ($m !== 'GET') break;
        out($pdo->query('SELECT cl.idCli, cl.nomCli, cl.prenomCli, cl.email, r.nomRegion, d.nomDep
                         FROM client cl JOIN region r ON r.idRegion=cl.idRegion JOIN departement d ON d.idDep=r.idDep
                         ORDER BY cl.nomCli, cl.prenomCli')->fetchAll());
    case 'regions':
        if ($m !== 'GET') break;
        out($pdo->query('SELECT r.idRegion, r.nomRegion, d.nomDep FROM region r JOIN departement d ON d.idDep=r.idDep ORDER BY d.nomDep, r.nomRegion')->fetchAll());

    // ---------------------------------------------------------------- commandes
    case 'commandes':
        if ($m === 'GET') {
            out($pdo->query('SELECT c.idCmd, c.dateCmd, CONCAT(cl.prenomCli," ",cl.nomCli) AS client,
                                    COUNT(lc.idProd) AS nbLignes, COALESCE(SUM(lc.qteCmd*p.prixUProd),0) AS total
                             FROM commande c JOIN client cl ON cl.idCli=c.idCli
                             LEFT JOIN ligneCommande lc ON lc.idCmd=c.idCmd LEFT JOIN produit p ON p.idProd=lc.idProd
                             GROUP BY c.idCmd, c.dateCmd, client ORDER BY c.dateCmd DESC, c.idCmd DESC')->fetchAll());
        }
        if ($m === 'POST') {            // {dateCmd, idCli}  ou  {dateCmd, client:{nomCli,prenomCli,email,idRegion}}
            $b = body();
            $date = (string)($b['dateCmd'] ?? '');
            $d = DateTime::createFromFormat('Y-m-d', $date);
            if (!$d || $d->format('Y-m-d') !== $date) fail('Date invalide (AAAA-MM-JJ).');
            $pdo->beginTransaction();
            try {
                if (!empty($b['client']) && is_array($b['client'])) {
                    $c = $b['client'];
                    $nom = trim((string)($c['nomCli'] ?? '')); $prenom = trim((string)($c['prenomCli'] ?? ''));
                    $email = trim((string)($c['email'] ?? '')); $reg = int_or_null($c['idRegion'] ?? null, 1);
                    if ($nom === '' || $prenom === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$reg) fail('Informations du nouveau client invalides.');
                    $s = $pdo->prepare('SELECT 1 FROM client WHERE email=?'); $s->execute([$email]);
                    if ($s->fetchColumn()) fail('Un client avec cet email existe déjà.', 409);
                    $pdo->prepare('INSERT INTO client(nomCli,prenomCli,email,idRegion) VALUES (?,?,?,?)')->execute([$nom, $prenom, $email, $reg]);
                    $idCli = (int)$pdo->lastInsertId();
                } else {
                    $idCli = int_or_null($b['idCli'] ?? null, 1);
                    $s = $pdo->prepare('SELECT 1 FROM client WHERE idCli=?'); $s->execute([$idCli]);
                    if (!$idCli || !$s->fetchColumn()) fail('Client inconnu.');
                }
                $pdo->prepare('INSERT INTO commande(dateCmd,idCli) VALUES (?,?)')->execute([$date, $idCli]);
                $idCmd = (int)$pdo->lastInsertId();
                $pdo->commit();
                out(['idCmd' => $idCmd, 'idCli' => $idCli], 201);
            } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        }
        if ($m === 'DELETE') {          // supprime la commande + restitue le stock
            if (!$id) fail('id requis.');
            $pdo->beginTransaction();
            try {
                $s = $pdo->prepare('SELECT idProd, qteCmd FROM ligneCommande WHERE idCmd=? FOR UPDATE'); $s->execute([$id]);
                $up = $pdo->prepare('UPDATE produit SET qteStock = qteStock + ? WHERE idProd=?');
                foreach ($s->fetchAll() as $l) $up->execute([$l['qteCmd'], $l['idProd']]);
                $pdo->prepare('DELETE FROM ligneCommande WHERE idCmd=?')->execute([$id]);
                $n = $pdo->prepare('DELETE FROM commande WHERE idCmd=?'); $n->execute([$id]);
                if (!$n->rowCount()) fail('Commande introuvable.', 404);
                $pdo->commit(); out(['ok' => true]);
            } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        }
        break;

    case 'commande':                    // détail d'une commande + lignes
        if ($m !== 'GET' || !$id) break;
        $s = $pdo->prepare('SELECT c.idCmd, c.dateCmd, CONCAT(cl.prenomCli," ",cl.nomCli) AS client FROM commande c JOIN client cl ON cl.idCli=c.idCli WHERE c.idCmd=?');
        $s->execute([$id]); $c = $s->fetch();
        if (!$c) fail('Commande introuvable.', 404);
        $s = $pdo->prepare('SELECT lc.idProd, p.designProd, lc.qteCmd, p.prixUProd, lc.qteCmd*p.prixUProd AS montant
                            FROM ligneCommande lc JOIN produit p ON p.idProd=lc.idProd WHERE lc.idCmd=? ORDER BY p.designProd');
        $s->execute([$id]); $c['lignes'] = $s->fetchAll();
        $c['total'] = array_sum(array_column($c['lignes'], 'montant'));
        out($c);

    // ---------------------------------------------------------------- lignes de commande
    case 'lignes':
        $b = body();
        $idCmd = int_or_null($b['idCmd'] ?? $_GET['idCmd'] ?? null, 1);
        $idProd = int_or_null($b['idProd'] ?? $_GET['idProd'] ?? null, 1);
        if (!$idCmd || !$idProd) fail('idCmd et idProd requis.');
        $pdo->beginTransaction();
        try {
            if ($m === 'POST') {
                $qte = int_or_null($b['qteCmd'] ?? null, 1);
                if (!$qte) fail('Quantité invalide.');
                $s = $pdo->prepare('SELECT 1 FROM commande WHERE idCmd=?'); $s->execute([$idCmd]);
                if (!$s->fetchColumn()) fail('Commande introuvable.', 404);
                $s = $pdo->prepare('SELECT qteStock FROM produit WHERE idProd=? FOR UPDATE'); $s->execute([$idProd]);
                $stock = $s->fetchColumn();
                if ($stock === false) fail('Produit inconnu.', 404);
                $s = $pdo->prepare('SELECT 1 FROM ligneCommande WHERE idCmd=? AND idProd=?'); $s->execute([$idCmd, $idProd]);
                if ($s->fetchColumn()) fail('Ce produit est déjà dans la commande.', 409);
                if ($qte > $stock) fail("Stock insuffisant ($stock disponible).", 409);
                $pdo->prepare('INSERT INTO ligneCommande(idCmd,idProd,qteCmd) VALUES (?,?,?)')->execute([$idCmd, $idProd, $qte]);
                $pdo->prepare('UPDATE produit SET qteStock=qteStock-? WHERE idProd=?')->execute([$qte, $idProd]);
                $pdo->commit(); out(['ok' => true], 201);
            }
            if ($m === 'DELETE') {
                $s = $pdo->prepare('SELECT qteCmd FROM ligneCommande WHERE idCmd=? AND idProd=? FOR UPDATE'); $s->execute([$idCmd, $idProd]);
                $q = $s->fetchColumn();
                if ($q === false) fail('Ligne introuvable.', 404);
                $pdo->prepare('DELETE FROM ligneCommande WHERE idCmd=? AND idProd=?')->execute([$idCmd, $idProd]);
                $pdo->prepare('UPDATE produit SET qteStock=qteStock+? WHERE idProd=?')->execute([$q, $idProd]);
                $pdo->commit(); out(['ok' => true]);
            }
            $pdo->rollBack();
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        break;

    // ---------------------------------------------------------------- statistiques
    case 'stats':
        if ($m !== 'GET') break;
        $k = $pdo->query('SELECT COUNT(DISTINCT idCmd) nbCmd, COALESCE(SUM(montant),0) ca, COALESCE(SUM(qteCmd),0) qte FROM v_ligne_detail')->fetch();
        out([
            'nbCmd' => (int)$k['nbCmd'], 'ca' => (float)$k['ca'], 'qte' => (int)$k['qte'],
            'panierMoyen' => $k['nbCmd'] ? (float)$k['ca'] / $k['nbCmd'] : 0,
            'parMois' => $pdo->query("SELECT DATE_FORMAT(dateCmd,'%Y-%m') AS label, SUM(montant) AS valeur FROM v_ligne_detail GROUP BY label ORDER BY label")->fetchAll(),
            'topProduits' => $pdo->query('SELECT designProd AS label, SUM(montant) AS valeur FROM v_ligne_detail GROUP BY idProd, designProd ORDER BY valeur DESC LIMIT 5')->fetchAll(),
            'topClients' => $pdo->query('SELECT CONCAT(cl.prenomCli," ",cl.nomCli) AS label, SUM(v.montant) AS valeur FROM v_ligne_detail v JOIN client cl ON cl.idCli=v.idCli GROUP BY cl.idCli, label ORDER BY valeur DESC LIMIT 5')->fetchAll(),
            'parDepartement' => $pdo->query('SELECT d.nomDep AS label, SUM(v.montant) AS valeur FROM v_ligne_detail v JOIN client cl ON cl.idCli=v.idCli JOIN region r ON r.idRegion=cl.idRegion JOIN departement d ON d.idDep=r.idDep GROUP BY d.idDep, d.nomDep ORDER BY valeur DESC')->fetchAll(),
            'stockFaible' => $pdo->query('SELECT designProd, qteStock FROM produit WHERE qteStock < 10 ORDER BY qteStock')->fetchAll(),
        ]);
    }
    fail('Route ou méthode inconnue.', 404);
} catch (Throwable $e) {
    error_log($e->getMessage());
    fail('Erreur serveur.', 500);
}
