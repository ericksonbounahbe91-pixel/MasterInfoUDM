import 'package:flutter_test/flutter_test.dart';
import 'package:tp_commande/utils.dart';

void main() {
  test('fmtMoney formate les montants avec séparateur de milliers', () {
    expect(fmtMoney(516000), '516 000 F');
    expect(fmtMoney(950), '950 F');
    expect(fmtMoney(1234567.4), '1 234 567 F');
  });
  test('fmtDate', () {
    expect(fmtDate(DateTime(2026, 3, 5)), '2026-03-05');
  });
}
