import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});
  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  late Future<List<ClientItem>> _future = Api.clients();
  void _reload() => setState(() => _future = Api.clients());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clients')),
      body: AsyncView<List<ClientItem>>(
      future: _future,
      onRetry: _reload,
      builder: (clients) {
        if (clients.isEmpty) return const Center(child: Text('Aucun client.'));
        return RefreshIndicator(
          onRefresh: () async {
            _reload();
            await _future;
          },
          child: ListView.separated(
            itemCount: clients.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final c = clients[i];
              return ListTile(
                leading: CircleAvatar(child: Text(c.prenomCli.isEmpty ? '?' : c.prenomCli[0].toUpperCase())),
                title: Text(c.nomComplet),
                subtitle: Text('${c.email}\n${c.nomRegion} (${c.nomDep})'),
                isThreeLine: true,
              );
            },
          ),
        );
      },
    ),
    );
  }
}
