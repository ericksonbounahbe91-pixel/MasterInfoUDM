import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';

class ProduitsScreen extends StatefulWidget {
  const ProduitsScreen({super.key});
  @override
  State<ProduitsScreen> createState() => _ProduitsScreenState();
}

class _ProduitsScreenState extends State<ProduitsScreen> {
  late Future<List<Produit>> _future = Api.produits();

  void _reload() => setState(() => _future = Api.produits());

  Future<void> _add() async {
    final r = await _showForm();
    if (r == null) return;
    final ok = await runAction(context, () => Api.addProduit(r.design, r.stock, r.prix), success: 'Produit ajouté.');
    if (ok) _reload();
  }

  Future<void> _edit(Produit p) async {
    final r = await _showForm(produit: p);
    if (r == null) return;
    final ok = await runAction(context, () => Api.updateProduit(p.idProd, r.design, r.stock, r.prix), success: 'Produit modifié.');
    if (ok) _reload();
  }

  Future<void> _delete(Produit p) async {
    if (!await confirmDialog(context, 'Supprimer « ${p.designProd} » ?')) return;
    if (!mounted) return;
    final ok = await runAction(context, () => Api.deleteProduit(p.idProd), success: 'Produit supprimé.');
    if (ok) _reload();
  }

  Future<_ProduitData?> _showForm({Produit? produit}) {
    final design = TextEditingController(text: produit?.designProd ?? '');
    final stock = TextEditingController(text: produit?.qteStock.toString() ?? '0');
    final prix = TextEditingController(text: produit == null ? '' : produit.prixUProd.toStringAsFixed(0));
    final formKey = GlobalKey<FormState>();
    return showDialog<_ProduitData>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(produit == null ? 'Nouveau produit' : 'Modifier le produit'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextFormField(
                controller: design,
                decoration: const InputDecoration(labelText: 'Désignation'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Obligatoire' : null,
              ),
              TextFormField(
                controller: stock,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Stock'),
                validator: (v) => (int.tryParse(v ?? '') ?? -1) < 0 ? 'Entier ≥ 0' : null,
              ),
              TextFormField(
                controller: prix,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Prix unitaire (F)'),
                validator: (v) => (double.tryParse((v ?? '').replaceAll(',', '.')) ?? -1) < 0 ? 'Nombre ≥ 0' : null,
              ),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              if (!formKey.currentState!.validate()) return;
              Navigator.pop(
                ctx,
                _ProduitData(design.text.trim(), int.parse(stock.text), double.parse(prix.text.replaceAll(',', '.'))),
              );
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Produits')),
      body: AsyncView<List<Produit>>(
        future: _future,
        onRetry: _reload,
        builder: (produits) {
          if (produits.isEmpty) return const Center(child: Text('Aucun produit.'));
          return RefreshIndicator(
            onRefresh: () async {
              _reload();
              await _future;
            },
            child: ListView.separated(
              padding: const EdgeInsets.only(bottom: 88),
              itemCount: produits.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final p = produits[i];
                return ListTile(
                  title: Text(p.designProd),
                  subtitle: Text('Stock : ${p.qteStock}  •  ${fmtMoney(p.prixUProd)}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) => v == 'edit' ? _edit(p) : _delete(p),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Modifier')),
                      PopupMenuItem(value: 'del', child: Text('Supprimer')),
                    ],
                  ),
                  onTap: () => _edit(p),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Produit'),
      ),
    );
  }
}

class _ProduitData {
  final String design;
  final int stock;
  final double prix;
  _ProduitData(this.design, this.stock, this.prix);
}
