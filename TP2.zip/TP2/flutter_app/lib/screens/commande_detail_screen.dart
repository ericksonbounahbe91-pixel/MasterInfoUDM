import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';

/// Produits d'une commande : ajout (stock contrôlé) et suppression de lignes (stock restitué).
class CommandeDetailScreen extends StatefulWidget {
  final int idCmd;
  const CommandeDetailScreen({super.key, required this.idCmd});
  @override
  State<CommandeDetailScreen> createState() => _CommandeDetailScreenState();
}

class _DetailData {
  final CommandeDetail commande;
  final List<Produit> produits;
  _DetailData(this.commande, this.produits);
}

class _CommandeDetailScreenState extends State<CommandeDetailScreen> {
  late Future<_DetailData> _future = _load();
  final _qte = TextEditingController(text: '1');
  int? _idProd;

  Future<_DetailData> _load() async {
    final c = await Api.commande(widget.idCmd);
    final p = await Api.produits();
    return _DetailData(c, p);
  }

  void _reload() => setState(() => _future = _load());

  @override
  void dispose() {
    _qte.dispose();
    super.dispose();
  }

  Future<void> _addLigne() async {
    final q = int.tryParse(_qte.text);
    if (_idProd == null || q == null || q < 1) {
      snack(context, 'Choisissez un produit et une quantité ≥ 1.', error: true);
      return;
    }
    final ok = await runAction(context, () => Api.addLigne(widget.idCmd, _idProd!, q), success: 'Produit ajouté.');
    if (ok) {
      _qte.text = '1';
      _idProd = null;
      _reload();
    }
  }

  Future<void> _deleteLigne(LigneCommande l) async {
    if (!await confirmDialog(context, 'Supprimer « ${l.designProd} » de la commande ?')) return;
    if (!mounted) return;
    final ok = await runAction(context, () => Api.deleteLigne(widget.idCmd, l.idProd), success: 'Ligne supprimée, stock restitué.');
    if (ok) _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Commande n°${widget.idCmd}')),
      body: AsyncView<_DetailData>(
        future: _future,
        onRetry: _reload,
        builder: (d) {
          final c = d.commande;
          // Produits encore en stock et pas déjà dans la commande
          final deja = c.lignes.map((l) => l.idProd).toSet();
          final dispo = d.produits.where((p) => p.qteStock > 0 && !deja.contains(p.idProd)).toList();
          if (_idProd != null && !dispo.any((p) => p.idProd == _idProd)) _idProd = null;

          return ListView(padding: const EdgeInsets.all(16), children: [
            Text(c.client, style: Theme.of(context).textTheme.titleLarge),
            Text('Date : ${c.dateCmd}'),
            const SizedBox(height: 12),
            if (c.lignes.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Text('Aucun produit dans cette commande.'))
            else
              Card(
                child: Column(children: [
                  for (final l in c.lignes)
                    ListTile(
                      title: Text(l.designProd),
                      subtitle: Text('${l.qteCmd} × ${fmtMoney(l.prixUProd)}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text(fmtMoney(l.montant), style: const TextStyle(fontWeight: FontWeight.bold)),
                        IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _deleteLigne(l)),
                      ]),
                    ),
                  const Divider(height: 1),
                  ListTile(
                    title: const Text('Total', style: TextStyle(fontWeight: FontWeight.bold)),
                    trailing: Text(fmtMoney(c.total), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ]),
              ),
            const SizedBox(height: 16),
            Text('Ajouter un produit', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (dispo.isEmpty)
              const Text('Aucun autre produit disponible en stock.')
            else ...[
              DropdownButtonFormField<int>(
                value: _idProd,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Produit', border: OutlineInputBorder()),
                items: dispo
                    .map((p) => DropdownMenuItem(value: p.idProd, child: Text('${p.designProd} (stock : ${p.qteStock})')))
                    .toList(),
                onChanged: (v) => setState(() => _idProd = v),
              ),
              const SizedBox(height: 12),
              Row(children: [
                SizedBox(
                  width: 110,
                  child: TextField(
                    controller: _qte,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Quantité', border: OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(onPressed: _addLigne, icon: const Icon(Icons.add_shopping_cart), label: const Text('Ajouter')),
                ),
              ]),
            ],
          ]);
        },
      ),
    );
  }
}
