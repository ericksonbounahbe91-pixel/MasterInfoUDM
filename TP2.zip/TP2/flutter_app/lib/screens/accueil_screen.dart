import 'package:flutter/material.dart';

import '../api.dart';
import '../utils.dart';
import 'clients_screen.dart';
import 'commandes_screen.dart';
import 'dashboard_screen.dart';
import 'produits_screen.dart';

/// Fenêtre d'accueil : menu vers les 4 autres fenêtres + réglage de l'URL de l'API.
class AccueilScreen extends StatefulWidget {
  const AccueilScreen({super.key});
  @override
  State<AccueilScreen> createState() => _AccueilScreenState();
}

class _AccueilScreenState extends State<AccueilScreen> {
  void _open(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  Future<void> _editUrl() async {
    final c = TextEditingController(text: Api.baseUrl);
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('URL de l\'API'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: c,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          const Text(
            'Émulateur : http://10.0.2.2:8000/api/index.php\n'
            'XAMPP : http://10.0.2.2/tp_commandes/api/index.php\n'
            'Téléphone : http://IP_DU_PC:8000/api/index.php',
            style: TextStyle(fontSize: 12),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(ctx, Api.defaultBaseUrl), child: const Text('Par défaut')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Enregistrer')),
        ],
      ),
    );
    c.dispose();
    if (url == null || url.trim().isEmpty) return;
    await Api.setBaseUrl(url);
    if (!mounted) return;
    setState(() {});
    snack(context, 'URL enregistrée.');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestion des commandes'),
        actions: [
          IconButton(icon: const Icon(Icons.settings), tooltip: 'URL de l\'API', onPressed: _editUrl),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: GridView.count(
            crossAxisCount: 2,
            padding: const EdgeInsets.all(16),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              _MenuCard(icon: Icons.inventory_2, label: 'Produits', onTap: () => _open(const ProduitsScreen())),
              _MenuCard(icon: Icons.receipt_long, label: 'Commandes', onTap: () => _open(const CommandesScreen())),
              _MenuCard(icon: Icons.people, label: 'Clients', onTap: () => _open(const ClientsScreen())),
              _MenuCard(icon: Icons.bar_chart, label: 'Tableau de bord', onTap: () => _open(const DashboardScreen())),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text('API : ${Api.baseUrl}', style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
        ),
      ]),
    );
  }
}

class _MenuCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _MenuCard({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: cs.primaryContainer,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 48, color: cs.onPrimaryContainer),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: cs.onPrimaryContainer)),
        ]),
      ),
    );
  }
}
