import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<Stats> _future = Api.stats();
  void _reload() => setState(() => _future = Api.stats());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tableau de bord')),
      body: AsyncView<Stats>(
      future: _future,
      onRetry: _reload,
      builder: (s) => RefreshIndicator(
        onRefresh: () async {
          _reload();
          await _future;
        },
        child: ListView(padding: const EdgeInsets.all(12), children: [
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 2.2,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: [
              _Kpi('Commandes', '${s.nbCmd}'),
              _Kpi('Chiffre d\'affaires', fmtMoney(s.ca)),
              _Kpi('Articles vendus', '${s.qte}'),
              _Kpi('Panier moyen', fmtMoney(s.panierMoyen)),
            ],
          ),
          _BarCard('CA par mois', s.parMois),
          _BarCard('Top 5 produits (CA)', s.topProduits),
          _BarCard('CA par département', s.parDepartement),
          _BarCard('Top 5 clients', s.topClients),
          if (s.stockFaible.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('⚠ Stock faible (< 10)', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  for (final p in s.stockFaible) Text('${p.designProd} : ${p.qteStock}'),
                ]),
              ),
            ),
        ]),
      ),
    ),
    );
  }
}

class _Kpi extends StatelessWidget {
  final String label, value;
  const _Kpi(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 2),
          FittedBox(child: Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
        ]),
      ),
    );
  }
}

/// Diagramme à barres horizontales sans dépendance externe.
class _BarCard extends StatelessWidget {
  final String title;
  final List<ChartPoint> points;
  const _BarCard(this.title, this.points);

  @override
  Widget build(BuildContext context) {
    final maxV = points.fold<double>(0, (m, p) => p.valeur > m ? p.valeur : m);
    final color = Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (points.isEmpty) const Text('Pas de données.'),
          for (final p in points)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Flexible(child: Text(p.label, overflow: TextOverflow.ellipsis)),
                  Text(fmtMoney(p.valeur), style: const TextStyle(fontSize: 12)),
                ]),
                const SizedBox(height: 2),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: maxV == 0 ? 0 : p.valeur / maxV,
                    minHeight: 10,
                    color: color,
                  ),
                ),
              ]),
            ),
        ]),
      ),
    );
  }
}
