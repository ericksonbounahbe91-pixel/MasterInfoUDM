import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';
import 'commande_detail_screen.dart';
import 'commande_form_screen.dart';

class CommandesScreen extends StatefulWidget {
  const CommandesScreen({super.key});
  @override
  State<CommandesScreen> createState() => _CommandesScreenState();
}

class _CommandesScreenState extends State<CommandesScreen> {
  late Future<List<CommandeResume>> _future = Api.commandes();
  void _reload() => setState(() => _future = Api.commandes());

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) _reload(); // le détail peut avoir modifié la commande
  }

  Future<void> _delete(CommandeResume c) async {
    if (!await confirmDialog(context, 'Supprimer la commande n°${c.idCmd} ? Le stock sera restitué.')) return;
    if (!mounted) return;
    final ok = await runAction(context, () => Api.deleteCommande(c.idCmd), success: 'Commande supprimée, stock restitué.');
    if (ok) _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Commandes')),
      body: AsyncView<List<CommandeResume>>(
        future: _future,
        onRetry: _reload,
        builder: (cmds) {
          if (cmds.isEmpty) return const Center(child: Text('Aucune commande.'));
          return RefreshIndicator(
            onRefresh: () async {
              _reload();
              await _future;
            },
            child: ListView.separated(
              padding: const EdgeInsets.only(bottom: 88),
              itemCount: cmds.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final c = cmds[i];
                return ListTile(
                  title: Text('Commande n°${c.idCmd} — ${c.client}'),
                  subtitle: Text('${c.dateCmd}  •  ${c.nbLignes} ligne(s)  •  ${fmtMoney(c.total)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    tooltip: 'Supprimer',
                    onPressed: () => _delete(c),
                  ),
                  onTap: () => _open(CommandeDetailScreen(idCmd: c.idCmd)),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(const CommandeFormScreen()),
        icon: const Icon(Icons.add),
        label: const Text('Commande'),
      ),
    );
  }
}
