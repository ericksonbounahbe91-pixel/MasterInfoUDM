import 'package:flutter/material.dart';

import '../api.dart';
import '../models.dart';
import '../utils.dart';
import 'commande_detail_screen.dart';

/// Nouvelle commande : client existant OU saisie d'un nouveau client.
class CommandeFormScreen extends StatefulWidget {
  const CommandeFormScreen({super.key});
  @override
  State<CommandeFormScreen> createState() => _CommandeFormScreenState();
}

class _FormData {
  final List<ClientItem> clients;
  final List<Region> regions;
  _FormData(this.clients, this.regions);
}

class _CommandeFormScreenState extends State<CommandeFormScreen> {
  late Future<_FormData> _future = _load();
  final _formKey = GlobalKey<FormState>();
  final _nom = TextEditingController();
  final _prenom = TextEditingController();
  final _email = TextEditingController();

  DateTime _date = DateTime.now();
  bool _nouveau = false;
  int? _idCli;
  int? _idRegion;
  bool _saving = false;

  Future<_FormData> _load() async {
    final c = await Api.clients();
    final r = await Api.regions();
    return _FormData(c, r);
  }

  void _retry() => setState(() => _future = _load());

  @override
  void dispose() {
    _nom.dispose();
    _prenom.dispose();
    _email.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _submit(_FormData data) async {
    if (_nouveau) {
      if (!_formKey.currentState!.validate()) return;
    } else if (_idCli == null) {
      snack(context, 'Choisissez un client.', error: true);
      return;
    }
    setState(() => _saving = true);
    int? idCmd;
    final ok = await runAction(context, () async {
      idCmd = await Api.addCommande(
        date: fmtDate(_date),
        idCli: _nouveau ? null : _idCli,
        nouveauClient: _nouveau
            ? {
                'nomCli': _nom.text.trim(),
                'prenomCli': _prenom.text.trim(),
                'email': _email.text.trim(),
                'idRegion': _idRegion,
              }
            : null,
      );
    }, success: 'Commande créée : ajoutez ses produits.');
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok && idCmd != null) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => CommandeDetailScreen(idCmd: idCmd!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nouvelle commande')),
      body: AsyncView<_FormData>(
        future: _future,
        onRetry: _retry,
        builder: (data) {
          _idCli ??= data.clients.isNotEmpty ? data.clients.first.idCli : null;
          _idRegion ??= data.regions.isNotEmpty ? data.regions.first.idRegion : null;
          return Form(
            key: _formKey,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event),
                title: Text('Date : ${fmtDate(_date)}'),
                trailing: TextButton(onPressed: _pickDate, child: const Text('Changer')),
              ),
              const SizedBox(height: 8),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('Client existant'), icon: Icon(Icons.person)),
                  ButtonSegment(value: true, label: Text('Nouveau client'), icon: Icon(Icons.person_add)),
                ],
                selected: {_nouveau},
                onSelectionChanged: (s) => setState(() => _nouveau = s.first),
              ),
              const SizedBox(height: 16),
              if (!_nouveau)
                DropdownButtonFormField<int>(
                  value: _idCli,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Client', border: OutlineInputBorder()),
                  items: data.clients
                      .map((c) => DropdownMenuItem(value: c.idCli, child: Text('${c.nomComplet} — ${c.email}', overflow: TextOverflow.ellipsis)))
                      .toList(),
                  onChanged: (v) => setState(() => _idCli = v),
                )
              else ...[
                TextFormField(
                  controller: _nom,
                  decoration: const InputDecoration(labelText: 'Nom', border: OutlineInputBorder()),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Obligatoire' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _prenom,
                  decoration: const InputDecoration(labelText: 'Prénom', border: OutlineInputBorder()),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Obligatoire' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
                  validator: (v) =>
                      RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch((v ?? '').trim()) ? null : 'Email invalide',
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  value: _idRegion,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Région', border: OutlineInputBorder()),
                  items: data.regions
                      .map((r) => DropdownMenuItem(value: r.idRegion, child: Text('${r.nomDep} / ${r.nomRegion}')))
                      .toList(),
                  onChanged: (v) => setState(() => _idRegion = v),
                  validator: (v) => v == null ? 'Obligatoire' : null,
                ),
              ],
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _saving ? null : () => _submit(data),
                icon: _saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.check),
                label: const Text('Créer la commande'),
              ),
            ]),
          );
        },
      ),
    );
  }
}
