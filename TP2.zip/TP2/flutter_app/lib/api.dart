import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// Client de l'API PHP (dossier api/ du projet web).
class Api {
  /// 10.0.2.2 = « localhost de l'ordinateur » vu depuis l'émulateur Android.
  /// Sur un vrai téléphone : remplacer par l'IP du PC (réglable dans l'appli via l'icône ⚙).
  static const defaultBaseUrl = 'http://10.0.2.2:8000/api/index.php';
  static String baseUrl = defaultBaseUrl;

  static Future<void> loadBaseUrl() async {
    try {
      final p = await SharedPreferences.getInstance();
      baseUrl = p.getString('baseUrl') ?? defaultBaseUrl;
    } catch (_) {
      baseUrl = defaultBaseUrl;
    }
  }

  static Future<void> setBaseUrl(String url) async {
    baseUrl = url.trim();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('baseUrl', baseUrl);
    } catch (_) {}
  }

  static Future<dynamic> _send(String method, String route,
      {Map<String, String> query = const {}, Object? body}) async {
    final base = Uri.parse(baseUrl);
    final uri = base.replace(queryParameters: {...base.queryParameters, 'r': route, ...query});
    final req = http.Request(method, uri)..headers['Accept'] = 'application/json';
    if (body != null) {
      req.headers['Content-Type'] = 'application/json';
      req.body = jsonEncode(body);
    }
    try {
      final streamed = await req.send().timeout(const Duration(seconds: 10));
      final res = await http.Response.fromStream(streamed);
      final text = utf8.decode(res.bodyBytes);
      dynamic data;
      try {
        data = jsonDecode(text);
      } catch (_) {
        throw ApiException('Réponse invalide du serveur (code ${res.statusCode}).');
      }
      if (res.statusCode >= 400) {
        throw ApiException(data is Map && data['error'] != null ? '${data['error']}' : 'Erreur ${res.statusCode}');
      }
      return data;
    } on SocketException {
      throw ApiException('Serveur injoignable. Vérifiez l\'URL de l\'API (icône ⚙) et que le serveur est démarré.');
    } on TimeoutException {
      throw ApiException('Le serveur ne répond pas (délai dépassé).');
    } on http.ClientException {
      throw ApiException('Connexion impossible. Vérifiez l\'URL de l\'API et le réseau.');
    }
  }

  static List<Map<String, dynamic>> _list(dynamic d) =>
      (d as List).map((e) => e as Map<String, dynamic>).toList();

  // ---- produits
  static Future<List<Produit>> produits() async =>
      _list(await _send('GET', 'produits')).map(Produit.fromJson).toList();

  static Future<void> addProduit(String design, int stock, double prix) async => _send('POST', 'produits',
      body: {'designProd': design, 'qteStock': stock, 'prixUProd': prix});

  static Future<void> updateProduit(int id, String design, int stock, double prix) async =>
      _send('PUT', 'produits', query: {'id': '$id'}, body: {'designProd': design, 'qteStock': stock, 'prixUProd': prix});

  static Future<void> deleteProduit(int id) async => _send('DELETE', 'produits', query: {'id': '$id'});

  // ---- clients / régions
  static Future<List<ClientItem>> clients() async =>
      _list(await _send('GET', 'clients')).map(ClientItem.fromJson).toList();

  static Future<List<Region>> regions() async =>
      _list(await _send('GET', 'regions')).map(Region.fromJson).toList();

  // ---- commandes
  static Future<List<CommandeResume>> commandes() async =>
      _list(await _send('GET', 'commandes')).map(CommandeResume.fromJson).toList();

  static Future<CommandeDetail> commande(int id) async =>
      CommandeDetail.fromJson(await _send('GET', 'commande', query: {'id': '$id'}) as Map<String, dynamic>);

  /// Client existant (idCli) OU nouveau client (map nomCli/prenomCli/email/idRegion).
  static Future<int> addCommande({required String date, int? idCli, Map<String, dynamic>? nouveauClient}) async {
    final r = await _send('POST', 'commandes', body: {
      'dateCmd': date,
      if (nouveauClient != null) 'client': nouveauClient else 'idCli': idCli,
    });
    return (r as Map<String, dynamic>)['idCmd'] as int;
  }

  static Future<void> deleteCommande(int id) async => _send('DELETE', 'commandes', query: {'id': '$id'});

  // ---- lignes
  static Future<void> addLigne(int idCmd, int idProd, int qte) async =>
      _send('POST', 'lignes', body: {'idCmd': idCmd, 'idProd': idProd, 'qteCmd': qte});

  static Future<void> deleteLigne(int idCmd, int idProd) async =>
      _send('DELETE', 'lignes', query: {'idCmd': '$idCmd', 'idProd': '$idProd'});

  // ---- stats
  static Future<Stats> stats() async => Stats.fromJson(await _send('GET', 'stats') as Map<String, dynamic>);
}
