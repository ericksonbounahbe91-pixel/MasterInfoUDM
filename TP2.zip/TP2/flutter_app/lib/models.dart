// Modèles : l'API renvoie les DECIMAL MySQL sous forme de chaînes ("15000.00"),
// d'où les conversions tolérantes ci-dessous.
double _d(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;
int _i(dynamic v) => v is int ? v : (v is num ? v.toInt() : int.tryParse('$v') ?? 0);

class Produit {
  final int idProd;
  final String designProd;
  final int qteStock;
  final double prixUProd;
  Produit({required this.idProd, required this.designProd, required this.qteStock, required this.prixUProd});
  factory Produit.fromJson(Map<String, dynamic> j) => Produit(
        idProd: _i(j['idProd']),
        designProd: '${j['designProd']}',
        qteStock: _i(j['qteStock']),
        prixUProd: _d(j['prixUProd']),
      );
}

class ClientItem {
  final int idCli;
  final String nomCli, prenomCli, email, nomRegion, nomDep;
  ClientItem({required this.idCli, required this.nomCli, required this.prenomCli, required this.email, required this.nomRegion, required this.nomDep});
  factory ClientItem.fromJson(Map<String, dynamic> j) => ClientItem(
        idCli: _i(j['idCli']),
        nomCli: '${j['nomCli']}',
        prenomCli: '${j['prenomCli']}',
        email: '${j['email']}',
        nomRegion: '${j['nomRegion']}',
        nomDep: '${j['nomDep']}',
      );
  String get nomComplet => '$prenomCli $nomCli';
}

class Region {
  final int idRegion;
  final String nomRegion, nomDep;
  Region({required this.idRegion, required this.nomRegion, required this.nomDep});
  factory Region.fromJson(Map<String, dynamic> j) =>
      Region(idRegion: _i(j['idRegion']), nomRegion: '${j['nomRegion']}', nomDep: '${j['nomDep']}');
}

class CommandeResume {
  final int idCmd, nbLignes;
  final String dateCmd, client;
  final double total;
  CommandeResume({required this.idCmd, required this.dateCmd, required this.client, required this.nbLignes, required this.total});
  factory CommandeResume.fromJson(Map<String, dynamic> j) => CommandeResume(
        idCmd: _i(j['idCmd']),
        dateCmd: '${j['dateCmd']}',
        client: '${j['client']}',
        nbLignes: _i(j['nbLignes']),
        total: _d(j['total']),
      );
}

class LigneCommande {
  final int idProd, qteCmd;
  final String designProd;
  final double prixUProd, montant;
  LigneCommande({required this.idProd, required this.designProd, required this.qteCmd, required this.prixUProd, required this.montant});
  factory LigneCommande.fromJson(Map<String, dynamic> j) => LigneCommande(
        idProd: _i(j['idProd']),
        designProd: '${j['designProd']}',
        qteCmd: _i(j['qteCmd']),
        prixUProd: _d(j['prixUProd']),
        montant: _d(j['montant']),
      );
}

class CommandeDetail {
  final int idCmd;
  final String dateCmd, client;
  final double total;
  final List<LigneCommande> lignes;
  CommandeDetail({required this.idCmd, required this.dateCmd, required this.client, required this.total, required this.lignes});
  factory CommandeDetail.fromJson(Map<String, dynamic> j) => CommandeDetail(
        idCmd: _i(j['idCmd']),
        dateCmd: '${j['dateCmd']}',
        client: '${j['client']}',
        total: _d(j['total']),
        lignes: (j['lignes'] as List).map((e) => LigneCommande.fromJson(e as Map<String, dynamic>)).toList(),
      );
}

class ChartPoint {
  final String label;
  final double valeur;
  ChartPoint(this.label, this.valeur);
  factory ChartPoint.fromJson(Map<String, dynamic> j) => ChartPoint('${j['label']}', _d(j['valeur']));
}

class Stats {
  final int nbCmd, qte;
  final double ca, panierMoyen;
  final List<ChartPoint> parMois, topProduits, topClients, parDepartement;
  final List<Produit> stockFaible;
  Stats({
    required this.nbCmd,
    required this.qte,
    required this.ca,
    required this.panierMoyen,
    required this.parMois,
    required this.topProduits,
    required this.topClients,
    required this.parDepartement,
    required this.stockFaible,
  });
  static List<ChartPoint> _pts(dynamic l) =>
      (l as List).map((e) => ChartPoint.fromJson(e as Map<String, dynamic>)).toList();
  factory Stats.fromJson(Map<String, dynamic> j) => Stats(
        nbCmd: _i(j['nbCmd']),
        qte: _i(j['qte']),
        ca: _d(j['ca']),
        panierMoyen: _d(j['panierMoyen']),
        parMois: _pts(j['parMois']),
        topProduits: _pts(j['topProduits']),
        topClients: _pts(j['topClients']),
        parDepartement: _pts(j['parDepartement']),
        stockFaible: (j['stockFaible'] as List).map((e) {
          final m = e as Map<String, dynamic>;
          return Produit(idProd: 0, designProd: '${m['designProd']}', qteStock: _i(m['qteStock']), prixUProd: 0);
        }).toList(),
      );
}
