import 'package:flutter/material.dart';

import 'api.dart';
import 'screens/accueil_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.loadBaseUrl(); // URL de l'API mémorisée (ou valeur par défaut)
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestion des commandes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1F3A5F)),
      ),
      home: const AccueilScreen(),
    );
  }
}
