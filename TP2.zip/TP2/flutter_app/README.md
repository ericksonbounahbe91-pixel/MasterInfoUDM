# TP Commandes – application Flutter (Android)

Client mobile du projet « Gestion d'une ligne de commande ». L'application **ne se connecte pas directement à MySQL** : elle appelle l'**API JSON PHP** (dossier `../api/`) qui, elle, utilise la base avec l'utilisateur `MasTMound2`. C'est l'architecture à adopter : on n'expose jamais les identifiants de la base dans une appli mobile.

```
Flutter (Android)  ──HTTP/JSON──►  api/index.php (PHP + PDO)  ──►  MySQL gestion_commande
```

## Fonctionnalités
- **Produits** : liste, ajout, modification, suppression (refusée si le produit figure dans une commande).
- **Commandes** : liste avec total, création avec **client existant ou nouveau client** (nom, prénom, email, région), suppression (stock restitué).
- **Détail d'une commande** : ajout de produits (stock contrôlé), suppression d'une ligne (stock restitué), total.
- **Clients** : liste avec région et département.
- **Tableau de bord** : commandes, CA, articles vendus, panier moyen, CA par mois, top produits, CA par département, top clients, alertes de stock faible.
- Tirer vers le bas pour actualiser ; messages d'erreur clairs (serveur injoignable, stock insuffisant, doublon…) ; URL de l'API modifiable dans l'appli (icône ⚙).

## 1. Démarrer le serveur (API)
Depuis le dossier du projet web (`tp_commandes/`, qui contient `api/` et `sql/`) :

```bash
mysql -u root -p --default-character-set=utf8mb4 < sql/schema.sql   # une seule fois
php -S 0.0.0.0:8000                                                  # écoute sur toutes les interfaces
```
> `0.0.0.0` est indispensable : avec `localhost`, l'émulateur et le téléphone ne peuvent pas joindre le serveur.
> Avec XAMPP/WAMP, l'URL devient `http://10.0.2.2/tp_commandes/api/index.php` (émulateur).

Test rapide dans un navigateur : `http://localhost:8000/api/index.php?r=produits` doit afficher du JSON.

## 2. Ouvrir le projet dans Android Studio
Prérequis : Flutter SDK (≥ 3.19, Dart ≥ 3.3) et plugins **Flutter** + **Dart** installés dans Android Studio.

1. Dézipper, puis **File ▸ Open** et choisir le dossier `flutter_app`.
2. Ouvrir le **Terminal** d'Android Studio (dans `flutter_app`) et générer la partie Android, une seule fois :
   ```bash
   flutter create --platforms=android --project-name tp_commande .
   flutter pub get
   ```
   (Cela crée le dossier `android/` avec Gradle ; `lib/` et `pubspec.yaml` du projet sont conservés. Gardez une copie si vous modifiez déjà le code.)
3. **Autoriser Internet et le HTTP** dans `android/app/src/main/AndroidManifest.xml` :
   ```xml
   <manifest xmlns:android="http://schemas.android.com/apk/res/android">
       <uses-permission android:name="android.permission.INTERNET"/>   <!-- AJOUTER -->
       <application
           android:usesCleartextTraffic="true"                        <!-- AJOUTER -->
           android:label="tp_commandes"
           ...>
   ```
   Sans `usesCleartextTraffic`, Android 9+ bloque les URL en `http://` (la connexion échoue).
4. Choisir un émulateur (Device Manager) ou un téléphone, puis **Run ▶** (ou `flutter run`).

## 3. Configurer l'URL de l'API
| Cas | URL |
|---|---|
| Émulateur Android (défaut) | `http://10.0.2.2:8000/api/index.php` |
| Téléphone réel (même Wi-Fi que le PC) | `http://IP_DU_PC:8000/api/index.php` (ex. `http://192.168.1.20:8000/...`) |

Sur un téléphone : autoriser le port 8000 dans le pare-feu du PC, puis dans l'appli toucher **⚙** et saisir l'URL (elle est mémorisée).

## Structure
```
lib/main.dart                  point d'entrée (thème, URL de l'API)
lib/api.dart                   client HTTP de l'API (erreurs, délais d'attente)
lib/models.dart                modèles (conversion des DECIMAL MySQL reçus en texte)
lib/utils.dart                 formats, messages, confirmation, AsyncView (chargement/erreur)
lib/screens/                   accueil, produits, commandes, commande_form, commande_detail, clients, dashboard
test/widget_test.dart          tests des fonctions de formatage
```

## API utilisée (`api/index.php?r=…`)
| Route | Méthodes |
|---|---|
| `produits` (`&id=`) | GET, POST, PUT, DELETE |
| `clients`, `regions`, `stats` | GET |
| `commandes` (`&id=` pour DELETE) | GET, POST (client existant ou nouveau), DELETE |
| `commande&id=` | GET (détail + lignes + total) |
| `lignes` | POST `{idCmd,idProd,qteCmd}`, DELETE `&idCmd=&idProd=` |

Erreurs : JSON `{"error": "..."}` avec code HTTP 400/404/409/500.

## Dépannage
- *« Serveur injoignable »* : serveur arrêté, mauvaise URL, ou serveur lancé avec `localhost` au lieu de `0.0.0.0`.
- *Écran blanc / erreur réseau uniquement en release* : permission `INTERNET` absente du manifeste principal.
- *Accents corrompus* : réimporter `schema.sql` avec `--default-character-set=utf8mb4`.
- Pas d'authentification utilisateur dans cette version (hors énoncé) : n'exposez pas l'API sur Internet telle quelle.
