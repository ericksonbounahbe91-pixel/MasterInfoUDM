<?php require 'includes/header.php';
$idCmd = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'idCmd', FILTER_VALIDATE_INT);
$st = db()->prepare('SELECT c.*, CONCAT(cl.prenomCli," ",cl.nomCli) AS client FROM commande c JOIN client cl ON cl.idCli=c.idCli WHERE idCmd=?');
$st->execute([$idCmd]);
$cmd = $st->fetch();
if (!$cmd) { http_response_code(404); exit('Commande introuvable'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $pdo = db();
    try {
        if (($_POST['action'] ?? '') === 'ajouter') {                       // ---- Q1
            $idProd = filter_input(INPUT_POST, 'idProd', FILTER_VALIDATE_INT);
            $qte    = filter_input(INPUT_POST, 'qteCmd', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if (!$idProd || !$qte) throw new RuntimeException('Produit ou quantité invalide.');

            $pdo->beginTransaction();
            // verrou sur le produit pour éviter une survente concurrente
            $s = $pdo->prepare('SELECT qteStock FROM produit WHERE idProd=? FOR UPDATE');
            $s->execute([$idProd]);
            $stock = $s->fetchColumn();
            if ($stock === false) throw new RuntimeException('Produit inconnu.');

            $s = $pdo->prepare('SELECT qteCmd FROM ligneCommande WHERE idCmd=? AND idProd=?');
            $s->execute([$idCmd, $idProd]);
            if ($s->fetchColumn() !== false) throw new RuntimeException('Ce produit est déjà dans la commande (supprimez la ligne pour la ressaisir).');
            if ($qte > $stock) throw new RuntimeException("Stock insuffisant ($stock disponible).");

            $pdo->prepare('INSERT INTO ligneCommande(idCmd,idProd,qteCmd) VALUES (?,?,?)')->execute([$idCmd,$idProd,$qte]);
            $pdo->prepare('UPDATE produit SET qteStock = qteStock - ? WHERE idProd=?')->execute([$qte,$idProd]);
            $pdo->commit();
            flash('Produit ajouté à la commande.');
        } elseif (($_POST['action'] ?? '') === 'supprimer') {               // ---- Q4
            $idProd = filter_input(INPUT_POST, 'idProd', FILTER_VALIDATE_INT);
            $pdo->beginTransaction();
            $s = $pdo->prepare('SELECT qteCmd FROM ligneCommande WHERE idCmd=? AND idProd=? FOR UPDATE');
            $s->execute([$idCmd, $idProd]);
            $q = $s->fetchColumn();
            if ($q === false) throw new RuntimeException('Ligne introuvable.');
            $pdo->prepare('DELETE FROM ligneCommande WHERE idCmd=? AND idProd=?')->execute([$idCmd,$idProd]);
            $pdo->prepare('UPDATE produit SET qteStock = qteStock + ? WHERE idProd=?')->execute([$q,$idProd]); // restitution du stock
            $pdo->commit();
            flash('Ligne supprimée, stock restitué.');
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash($e instanceof RuntimeException ? $e->getMessage() : 'Erreur technique.', 'err');
    }
    header('Location: commande_detail.php?id=' . $idCmd); exit;           // Post/Redirect/Get
}

$st = db()->prepare('SELECT lc.idProd, p.designProd, lc.qteCmd, p.prixUProd, lc.qteCmd*p.prixUProd AS montant
                     FROM ligneCommande lc JOIN produit p ON p.idProd=lc.idProd WHERE lc.idCmd=? ORDER BY p.designProd');
$st->execute([$idCmd]);
$lignes = $st->fetchAll();
$produits = db()->query('SELECT idProd, designProd, qteStock FROM produit WHERE qteStock>0 ORDER BY designProd')->fetchAll();
$total = array_sum(array_column($lignes, 'montant'));
?>
<h1>Commande n°<?= $cmd['idCmd'] ?> — <?= h($cmd['client']) ?> (<?= h($cmd['dateCmd']) ?>)</h1>

<table><tr><th>Produit</th><th>Qté</th><th>PU</th><th>Montant</th><th></th></tr>
<?php foreach ($lignes as $l): ?>
<tr><td><?= h($l['designProd']) ?></td><td><?= $l['qteCmd'] ?></td>
<td><?= number_format($l['prixUProd'],0,',',' ') ?></td><td><?= number_format($l['montant'],0,',',' ') ?> F</td>
<td><form method="post" onsubmit="return confirm('Supprimer cette ligne ?')">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="action" value="supprimer">
  <input type="hidden" name="idCmd" value="<?= $idCmd ?>">
  <input type="hidden" name="idProd" value="<?= $l['idProd'] ?>">
  <button class="danger">Supprimer</button></form></td></tr>
<?php endforeach; ?>
<tr><th colspan="3">Total</th><th colspan="2"><?= number_format($total,0,',',' ') ?> F</th></tr></table>

<h2>Ajouter un produit</h2>
<form method="post" class="card">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="action" value="ajouter">
  <input type="hidden" name="idCmd" value="<?= $idCmd ?>">
  <label>Produit <select name="idProd" required>
    <?php foreach ($produits as $p): ?>
      <option value="<?= $p['idProd'] ?>"><?= h($p['designProd']) ?> (stock : <?= $p['qteStock'] ?>)</option>
    <?php endforeach; ?></select></label>
  <label>Quantité <input type="number" name="qteCmd" min="1" value="1" required></label>
  <button>Ajouter</button>
</form>
<p><a href="commandes.php">← Retour aux commandes</a></p>
<?php require 'includes/footer.php'; ?>
