<?php require 'includes/header.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $design = trim($_POST['designProd'] ?? '');
    $stock  = filter_var($_POST['qteStock'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    $prix   = filter_var($_POST['prixUProd'] ?? '', FILTER_VALIDATE_FLOAT);
    try {
        if ($design === '' || $stock === false || $prix === false || $prix < 0) throw new RuntimeException('Données invalides.');
        $photo = upload_image('photoProd');
        db()->prepare('INSERT INTO produit(designProd,qteStock,prixUProd,photoProd) VALUES (?,?,?,?)')
            ->execute([$design, $stock, $prix, $photo]);
        flash('Produit ajouté.');
        header('Location: produits.php'); exit;
    } catch (RuntimeException $e) { flash($e->getMessage(), 'err'); }
}
?>
<h1>Nouveau produit</h1>
<form method="post" enctype="multipart/form-data" class="card">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <label>Désignation<br><input name="designProd" required maxlength="120" value="<?= h($_POST['designProd'] ?? '') ?>"></label><br>
  <label>Stock initial<br><input type="number" name="qteStock" min="0" required value="<?= h($_POST['qteStock'] ?? '0') ?>"></label><br>
  <label>Prix unitaire<br><input type="number" step="0.01" min="0" name="prixUProd" required value="<?= h($_POST['prixUProd'] ?? '') ?>"></label><br>
  <label>Photo (optionnel)<br><input type="file" name="photoProd" accept="image/jpeg,image/png,image/webp"></label><br>
  <button>Enregistrer</button> <a href="produits.php">Annuler</a>
</form>
<?php require 'includes/footer.php'; ?>
