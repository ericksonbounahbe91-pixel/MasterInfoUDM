-- Analyse de performance : à exécuter sur une base volumineuse (ex. 100 000 commandes)
USE gestion_commande;

-- 1) Lire le plan d'exécution de la requête la plus lourde du tableau de bord
EXPLAIN SELECT DATE_FORMAT(dateCmd,'%Y-%m') mois, SUM(montant) FROM v_ligne_detail GROUP BY mois;
-- À vérifier : type=ref/range (pas ALL) sur commande/ligneCommande/produit, pas de "Using filesort" sur grosses tables.

-- 2) Index déjà créés dans schema.sql (justification)
--  idx_cmd_date  : filtre/regroupement par période
--  idx_cmd_cli   : jointure commande -> client (top clients)
--  idx_lc_prod   : jointure ligneCommande -> produit (top produits) ; la PK (idCmd,idProd) couvre idCmd
-- 3) Si le dashboard devient lent : table d'agrégats rafraîchie la nuit
CREATE TABLE IF NOT EXISTS stat_mensuelle (
  mois CHAR(7) PRIMARY KEY, nbCmd INT, ca DECIMAL(14,2)
);
-- REPLACE INTO stat_mensuelle SELECT DATE_FORMAT(dateCmd,'%Y-%m'), COUNT(DISTINCT idCmd), SUM(montant) FROM v_ligne_detail GROUP BY 1;
