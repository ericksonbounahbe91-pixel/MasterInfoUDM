SET NAMES utf8mb4;
-- ============================================================
-- TP Gestion d'une ligne de commande : schéma + utilisateur + jeu d'essai
-- ============================================================
CREATE DATABASE IF NOT EXISTS gestion_commande CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_commande;

CREATE TABLE departement (
  idDep  INT AUTO_INCREMENT PRIMARY KEY,
  nomDep VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE region (
  idRegion  INT AUTO_INCREMENT PRIMARY KEY,
  nomRegion VARCHAR(80) NOT NULL,
  idDep     INT NOT NULL,
  CONSTRAINT fk_region_dep FOREIGN KEY (idDep) REFERENCES departement(idDep)
) ENGINE=InnoDB;

CREATE TABLE client (
  idCli     INT AUTO_INCREMENT PRIMARY KEY,
  nomCli    VARCHAR(60) NOT NULL,
  prenomCli VARCHAR(60) NOT NULL,
  email     VARCHAR(120) NOT NULL UNIQUE,
  photo     VARCHAR(255) DEFAULT NULL,
  idRegion  INT NOT NULL,
  CONSTRAINT fk_client_region FOREIGN KEY (idRegion) REFERENCES region(idRegion)
) ENGINE=InnoDB;

CREATE TABLE produit (
  idProd    INT AUTO_INCREMENT PRIMARY KEY,
  designProd VARCHAR(120) NOT NULL,
  qteStock  INT NOT NULL DEFAULT 0 CHECK (qteStock >= 0),
  prixUProd DECIMAL(10,2) NOT NULL CHECK (prixUProd >= 0),
  photoProd VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE commande (
  idCmd   INT AUTO_INCREMENT PRIMARY KEY,
  dateCmd DATE NOT NULL,
  idCli   INT NOT NULL,
  CONSTRAINT fk_cmd_client FOREIGN KEY (idCli) REFERENCES client(idCli),
  INDEX idx_cmd_date (dateCmd),          -- statistiques par période
  INDEX idx_cmd_cli  (idCli)
) ENGINE=InnoDB;

CREATE TABLE ligneCommande (
  idCmd  INT NOT NULL,
  idProd INT NOT NULL,
  qteCmd INT NOT NULL CHECK (qteCmd > 0),
  PRIMARY KEY (idCmd, idProd),           -- un produit une seule fois par commande
  CONSTRAINT fk_lc_cmd  FOREIGN KEY (idCmd)  REFERENCES commande(idCmd) ON DELETE CASCADE,
  CONSTRAINT fk_lc_prod FOREIGN KEY (idProd) REFERENCES produit(idProd),
  INDEX idx_lc_prod (idProd)             -- jointures / top produits
) ENGINE=InnoDB;

-- Utilisateur imposé par l'énoncé (droits minimaux : pas de DROP/ALTER)
CREATE USER IF NOT EXISTS 'MasTMound2'@'localhost' IDENTIFIED BY 'MoundMasT2@2026';
GRANT SELECT, INSERT, UPDATE, DELETE ON gestion_commande.* TO 'MasTMound2'@'localhost';
FLUSH PRIVILEGES;

-- Jeu d'essai
INSERT INTO departement(nomDep) VALUES ('Dakar'),('Thiès'),('Saint-Louis');
INSERT INTO region(nomRegion,idDep) VALUES ('Plateau',1),('Pikine',1),('Mbour',2),('Tivaouane',2),('Richard-Toll',3);
INSERT INTO client(nomCli,prenomCli,email,idRegion) VALUES
 ('Diop','Awa','awa@mail.com',1),('Ndiaye','Moussa','moussa@mail.com',2),
 ('Fall','Fatou','fatou@mail.com',3),('Sow','Ibrahima','ibra@mail.com',5);
INSERT INTO produit(designProd,qteStock,prixUProd) VALUES
 ('Clavier',50,8000),('Souris',80,4500),('Écran 24"',20,95000),('Casque',35,15000),('Webcam',25,22000);
INSERT INTO commande(dateCmd,idCli) VALUES
 ('2026-08-05',1),('2026-08-19',2),('2026-09-02',1),('2026-09-15',3),('2026-10-01',4);
INSERT INTO ligneCommande VALUES
 (1,1,2),(1,2,3),(2,3,1),(2,4,2),(3,2,5),(3,5,1),(4,1,1),(4,3,2),(5,4,4),(5,5,2);

-- Vue pour le tableau de bord : montant par ligne
CREATE OR REPLACE VIEW v_ligne_detail AS
SELECT lc.idCmd, c.dateCmd, c.idCli, lc.idProd, p.designProd, lc.qteCmd,
       p.prixUProd, lc.qteCmd * p.prixUProd AS montant
FROM ligneCommande lc
JOIN commande c ON c.idCmd = lc.idCmd
JOIN produit  p ON p.idProd = lc.idProd;
