<?php require 'includes/header.php';
$pdo = db();
$clients = $pdo->query('SELECT idCli, nomCli, prenomCli, email FROM client ORDER BY nomCli, prenomCli')->fetchAll();
$regions = $pdo->query('SELECT r.idRegion, r.nomRegion, d.nomDep FROM region r JOIN departement d ON d.idDep=r.idDep ORDER BY d.nomDep, r.nomRegion')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $date = $_POST['dateCmd'] ?? '';
        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) throw new RuntimeException('Date invalide.');

        $pdo->beginTransaction();
        if (($_POST['typeClient'] ?? 'existant') === 'nouveau') {
            $nom    = trim($_POST['nomCli'] ?? '');
            $prenom = trim($_POST['prenomCli'] ?? '');
            $email  = trim($_POST['email'] ?? '');
            $region = filter_input(INPUT_POST, 'idRegion', FILTER_VALIDATE_INT);
            if ($nom === '' || $prenom === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$region)
                throw new RuntimeException('Informations du nouveau client incomplètes ou invalides.');
            $s = $pdo->prepare('SELECT idCli FROM client WHERE email=?'); $s->execute([$email]);
            if ($s->fetchColumn() !== false) throw new RuntimeException('Un client avec cet email existe déjà : choisissez « Client existant ».');
            $photo = upload_image('photo');
            $pdo->prepare('INSERT INTO client(nomCli,prenomCli,email,photo,idRegion) VALUES (?,?,?,?,?)')
                ->execute([$nom, $prenom, $email, $photo, $region]);
            $idCli = (int)$pdo->lastInsertId();
        } else {
            $idCli = filter_input(INPUT_POST, 'idCli', FILTER_VALIDATE_INT);
            $s = $pdo->prepare('SELECT 1 FROM client WHERE idCli=?'); $s->execute([$idCli]);
            if (!$idCli || !$s->fetchColumn()) throw new RuntimeException('Client inconnu.');
        }
        $pdo->prepare('INSERT INTO commande(dateCmd,idCli) VALUES (?,?)')->execute([$date, $idCli]);
        $idCmd = (int)$pdo->lastInsertId();
        $pdo->commit();
        flash('Commande créée : ajoutez maintenant ses produits.');
        header('Location: commande_detail.php?id=' . $idCmd); exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash($e instanceof RuntimeException ? $e->getMessage() : 'Erreur technique.', 'err');
    }
}
$nouveau = ($_POST['typeClient'] ?? '') === 'nouveau';
?>
<h1>Nouvelle commande</h1>
<form method="post" enctype="multipart/form-data" class="card">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <label>Date <input type="date" name="dateCmd" required value="<?= h($_POST['dateCmd'] ?? date('Y-m-d')) ?>"></label>
  <h3>Client</h3>
  <label><input type="radio" name="typeClient" value="existant" <?= $nouveau ? '' : 'checked' ?>> Client existant</label>
  <label><input type="radio" name="typeClient" value="nouveau" <?= $nouveau ? 'checked' : '' ?>> Nouveau client</label>

  <div id="existant">
    <select name="idCli"><?php foreach ($clients as $c): ?>
      <option value="<?= $c['idCli'] ?>"><?= h($c['nomCli'] . ' ' . $c['prenomCli'] . ' — ' . $c['email']) ?></option>
    <?php endforeach; ?></select>
  </div>
  <div id="nouveau">
    <label>Nom<br><input name="nomCli" maxlength="60" value="<?= h($_POST['nomCli'] ?? '') ?>"></label><br>
    <label>Prénom<br><input name="prenomCli" maxlength="60" value="<?= h($_POST['prenomCli'] ?? '') ?>"></label><br>
    <label>Email<br><input type="email" name="email" maxlength="120" value="<?= h($_POST['email'] ?? '') ?>"></label><br>
    <label>Région<br><select name="idRegion"><?php foreach ($regions as $r): ?>
      <option value="<?= $r['idRegion'] ?>"><?= h($r['nomDep'] . ' / ' . $r['nomRegion']) ?></option><?php endforeach; ?></select></label><br>
    <label>Photo (optionnel)<br><input type="file" name="photo" accept="image/jpeg,image/png,image/webp"></label>
  </div>
  <p><button>Créer la commande</button> <a href="commandes.php">Annuler</a></p>
</form>
<script>
const toggle = () => {
  const n = document.querySelector('[name=typeClient]:checked').value === 'nouveau';
  document.getElementById('nouveau').style.display  = n ? '' : 'none';
  document.getElementById('existant').style.display = n ? 'none' : '';
  // champs du nouveau client requis uniquement s'il est choisi
  document.querySelectorAll('#nouveau input:not([type=file])').forEach(i => i.required = n);
};
document.querySelectorAll('[name=typeClient]').forEach(r => r.addEventListener('change', toggle));
toggle();
</script>
<?php require 'includes/footer.php'; ?>
