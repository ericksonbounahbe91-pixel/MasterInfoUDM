<?php require 'includes/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'supprimer') {   // suppression d'un produit du catalogue
    csrf_check();
    $id = filter_input(INPUT_POST, 'idProd', FILTER_VALIDATE_INT);
    $s = $pdo->prepare('SELECT COUNT(*) FROM ligneCommande WHERE idProd=?');
    $s->execute([$id]);
    if ($s->fetchColumn() > 0) {
        flash('Suppression impossible : ce produit figure dans des commandes (historique à conserver).', 'err');
    } else {
        $s = $pdo->prepare('SELECT photoProd FROM produit WHERE idProd=?'); $s->execute([$id]);
        $photo = $s->fetchColumn();
        $pdo->prepare('DELETE FROM produit WHERE idProd=?')->execute([$id]);
        if ($photo) @unlink(__DIR__ . '/uploads/' . basename($photo));
        flash('Produit supprimé.');
    }
    header('Location: produits.php'); exit;
}
$produits = $pdo->query('SELECT idProd, designProd, qteStock, prixUProd, photoProd FROM produit ORDER BY designProd')->fetchAll();
?>
<h1>Liste des produits</h1>
<p><a class="btn" href="produit_ajouter.php">+ Ajouter un produit</a></p>
<table><tr><th>#</th><th>Photo</th><th>Désignation</th><th>Stock</th><th>Prix unitaire</th><th>Actions</th></tr>
<?php foreach ($produits as $p): ?>
<tr><td><?= $p['idProd'] ?></td>
<td><?= $p['photoProd'] ? '<img src="uploads/' . h($p['photoProd']) . '" alt="" width="40">' : '' ?></td>
<td><?= h($p['designProd']) ?></td><td><?= $p['qteStock'] ?></td>
<td><?= number_format($p['prixUProd'], 0, ',', ' ') ?> F</td>
<td style="white-space:nowrap"><a class="btn" href="produit_modifier.php?id=<?= $p['idProd'] ?>">Modifier</a>
 <form method="post" style="display:inline" onsubmit="return confirm('Supprimer définitivement ce produit ?')">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="supprimer">
  <input type="hidden" name="idProd" value="<?= $p['idProd'] ?>"><button class="danger">Supprimer</button></form></td></tr>
<?php endforeach; ?></table>
<?php require 'includes/footer.php'; ?>
