<?php require_once __DIR__ . '/db.php'; ?>
<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Gestion des commandes</title>
<style>
 body{font-family:system-ui,sans-serif;margin:0;background:#f5f6f8;color:#222}
 nav{background:#1f3a5f;padding:12px 20px}
 nav a{color:#fff;margin-right:18px;text-decoration:none;font-weight:600}
 main{max-width:1000px;margin:20px auto;padding:0 16px}
 table{border-collapse:collapse;width:100%;background:#fff}
 th,td{padding:8px 10px;border-bottom:1px solid #ddd;text-align:left}
 th{background:#e9edf3}
 .card{background:#fff;padding:16px;border-radius:8px;margin-bottom:18px}
 .ok{background:#d9f2dd;padding:10px;border-radius:6px}.err{background:#f8d7da;padding:10px;border-radius:6px}
 input,select,button{padding:7px;margin:3px 0}
 button,.btn{font:inherit;font-size:.9em;background:#1f3a5f;color:#fff;border:0;border-radius:5px;padding:7px 12px;cursor:pointer;text-decoration:none}
 .danger{background:#b3261e}
 .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}
 .kpi b{display:block;font-size:1.6em}
</style></head><body>
<nav><a href="index.php">Accueil</a><a href="produits.php">Produits</a><a href="commandes.php">Commandes</a>
<a href="clients.php">Clients</a><a href="dashboard.php">Tableau de bord</a></nav>
<main>
<?php if (!empty($_SESSION['flash'])): [$m,$t] = $_SESSION['flash']; unset($_SESSION['flash']); ?>
  <p class="<?= $t === 'ok' ? 'ok' : 'err' ?>"><?= h($m) ?></p>
<?php endif; ?>
