<?php require 'includes/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'supprimer') {   // suppression d'une commande entière
    csrf_check();
    $id = filter_input(INPUT_POST, 'idCmd', FILTER_VALIDATE_INT);
    try {
        $pdo->beginTransaction();
        $s = $pdo->prepare('SELECT idProd, qteCmd FROM ligneCommande WHERE idCmd=? FOR UPDATE');
        $s->execute([$id]);
        $up = $pdo->prepare('UPDATE produit SET qteStock = qteStock + ? WHERE idProd=?');
        foreach ($s->fetchAll() as $l) $up->execute([$l['qteCmd'], $l['idProd']]);          // restitution du stock
        $pdo->prepare('DELETE FROM ligneCommande WHERE idCmd=?')->execute([$id]);
        $pdo->prepare('DELETE FROM commande WHERE idCmd=?')->execute([$id]);
        $pdo->commit();
        flash('Commande supprimée, stock restitué.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('Erreur lors de la suppression.', 'err');
    }
    header('Location: commandes.php'); exit;
}
$rows = $pdo->query(
 'SELECT c.idCmd, c.dateCmd, CONCAT(cl.prenomCli," ",cl.nomCli) AS client,
         COUNT(lc.idProd) AS nbLignes, COALESCE(SUM(lc.qteCmd*p.prixUProd),0) AS total
  FROM commande c
  JOIN client cl ON cl.idCli = c.idCli
  LEFT JOIN ligneCommande lc ON lc.idCmd = c.idCmd
  LEFT JOIN produit p ON p.idProd = lc.idProd
  GROUP BY c.idCmd, c.dateCmd, client
  ORDER BY c.dateCmd DESC, c.idCmd DESC')->fetchAll();
?>
<h1>Liste des commandes</h1>
<p><a class="btn" href="commande_ajouter.php">+ Nouvelle commande</a></p>
<table><tr><th>N°</th><th>Date</th><th>Client</th><th>Lignes</th><th>Total</th><th>Actions</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= $r['idCmd'] ?></td><td><?= h($r['dateCmd']) ?></td><td><?= h($r['client']) ?></td>
<td><?= $r['nbLignes'] ?></td><td><?= number_format($r['total'], 0, ',', ' ') ?> F</td>
<td style="white-space:nowrap"><a class="btn" href="commande_detail.php?id=<?= $r['idCmd'] ?>">Produits</a>
 <form method="post" style="display:inline" onsubmit="return confirm('Supprimer toute la commande ? Le stock sera restitué.')">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="supprimer">
  <input type="hidden" name="idCmd" value="<?= $r['idCmd'] ?>"><button class="danger">Supprimer</button></form></td></tr>
<?php endforeach; ?></table>
<?php require 'includes/footer.php'; ?>
