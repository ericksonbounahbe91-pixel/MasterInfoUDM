<?php require 'includes/header.php';
$pdo = db();
$kpi = $pdo->query('SELECT COUNT(DISTINCT idCmd) nbCmd, COALESCE(SUM(montant),0) ca, COALESCE(SUM(qteCmd),0) qte FROM v_ligne_detail')->fetch();
$panier = $kpi['nbCmd'] ? $kpi['ca'] / $kpi['nbCmd'] : 0;

$parMois = $pdo->query("SELECT DATE_FORMAT(dateCmd,'%Y-%m') mois, SUM(montant) ca FROM v_ligne_detail GROUP BY mois ORDER BY mois")->fetchAll();
$topProd = $pdo->query('SELECT designProd, SUM(qteCmd) qte, SUM(montant) ca FROM v_ligne_detail GROUP BY idProd, designProd ORDER BY ca DESC LIMIT 5')->fetchAll();
$topCli  = $pdo->query('SELECT CONCAT(cl.prenomCli," ",cl.nomCli) client, SUM(v.montant) ca
                        FROM v_ligne_detail v JOIN client cl ON cl.idCli=v.idCli GROUP BY cl.idCli, client ORDER BY ca DESC LIMIT 5')->fetchAll();
$parDep  = $pdo->query('SELECT d.nomDep, SUM(v.montant) ca
                        FROM v_ligne_detail v JOIN client cl ON cl.idCli=v.idCli
                        JOIN region r ON r.idRegion=cl.idRegion JOIN departement d ON d.idDep=r.idDep
                        GROUP BY d.idDep, d.nomDep ORDER BY ca DESC')->fetchAll();
$alertes = $pdo->query('SELECT designProd, qteStock FROM produit WHERE qteStock < 10 ORDER BY qteStock')->fetchAll();
?>
<h1>Tableau de bord</h1>
<div class="kpis">
  <div class="card kpi">Commandes<b><?= $kpi['nbCmd'] ?></b></div>
  <div class="card kpi">Chiffre d'affaires<b><?= number_format($kpi['ca'],0,',',' ') ?> F</b></div>
  <div class="card kpi">Articles vendus<b><?= $kpi['qte'] ?></b></div>
  <div class="card kpi">Panier moyen<b><?= number_format($panier,0,',',' ') ?> F</b></div>
</div>
<div class="card"><h3>CA par mois</h3><canvas id="mois" height="90"></canvas></div>
<div class="card"><h3>Top 5 produits (CA)</h3><canvas id="prod" height="90"></canvas></div>
<div class="card"><h3>CA par département</h3><canvas id="dep" height="90"></canvas></div>
<div class="card"><h3>Top 5 clients</h3>
 <table><tr><th>Client</th><th>CA</th></tr>
 <?php foreach ($topCli as $c): ?><tr><td><?= h($c['client']) ?></td><td><?= number_format($c['ca'],0,',',' ') ?> F</td></tr><?php endforeach; ?></table></div>
<?php if ($alertes): ?><div class="card"><h3>⚠ Stock faible (&lt; 10)</h3><ul>
 <?php foreach ($alertes as $a): ?><li><?= h($a['designProd']) ?> : <?= $a['qteStock'] ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<script src="assets/chart.umd.js"></script>
<script>
const mk=(id,type,labels,data)=>new Chart(document.getElementById(id),{type,data:{labels,datasets:[{data,backgroundColor:'#1f3a5f',borderColor:'#1f3a5f'}]},options:{plugins:{legend:{display:false}}}});
mk('mois','line',<?= json_encode(array_column($parMois,'mois')) ?>,<?= json_encode(array_map('floatval',array_column($parMois,'ca'))) ?>);
mk('prod','bar', <?= json_encode(array_column($topProd,'designProd')) ?>,<?= json_encode(array_map('floatval',array_column($topProd,'ca'))) ?>);
mk('dep', 'bar', <?= json_encode(array_column($parDep,'nomDep')) ?>,<?= json_encode(array_map('floatval',array_column($parDep,'ca'))) ?>);
</script>
<?php require 'includes/footer.php'; ?>
