<?php require 'includes/header.php';
$rows = db()->query(
 'SELECT cl.idCli, cl.nomCli, cl.prenomCli, cl.email, r.nomRegion, d.nomDep
  FROM client cl
  JOIN region r ON r.idRegion = cl.idRegion
  JOIN departement d ON d.idDep = r.idDep
  ORDER BY cl.nomCli, cl.prenomCli')->fetchAll();
?>
<h1>Liste des clients</h1>
<table><tr><th>#</th><th>Nom</th><th>Prénom</th><th>Email</th><th>Région</th><th>Département</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= $r['idCli'] ?></td><td><?= h($r['nomCli']) ?></td><td><?= h($r['prenomCli']) ?></td>
<td><?= h($r['email']) ?></td><td><?= h($r['nomRegion']) ?></td><td><?= h($r['nomDep']) ?></td></tr>
<?php endforeach; ?></table>
<?php require 'includes/footer.php'; ?>
