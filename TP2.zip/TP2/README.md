# TP – Gestion d'une ligne de commande

Application web **PHP 8 / PDO / MySQL (MariaDB)** de gestion des produits, clients, commandes et lignes de commande, avec tableau de bord statistique.

## Fonctionnalités
| Réf. énoncé | Fonctionnalité | Page |
|---|---|---|
| Q1 | Enregistrer les produits d'une commande (contrôle du stock, transaction) | `commande_detail.php` |
| Q2 | Listes des produits, commandes, clients | `produits.php`, `commandes.php`, `clients.php` |
| Q3 | Modifier un produit | `produit_modifier.php` |
| Q4 | Supprimer un produit d'une commande (stock restitué) | `commande_detail.php` |
| Ajout | Ajouter / supprimer un produit du catalogue | `produit_ajouter.php`, `produits.php` |
| Ajout | Ajouter / supprimer une commande, avec création d'un nouveau client si besoin | `commande_ajouter.php`, `commandes.php` |
| Q5 | Tableau de bord + analyse de performance | `dashboard.php`, `sql/analyse_performance.sql` |

## Installation
**Prérequis** : PHP ≥ 8.1 (extensions `pdo_mysql`, `fileinfo`), MySQL 8 ou MariaDB 10.5+.

```bash
# 1. Créer la base, les tables, l'utilisateur MasTMound2 et le jeu d'essai
mysql -u root -p --default-character-set=utf8mb4 < sql/schema.sql

# 2. Lancer le serveur de développement
php -S localhost:8000

# 3. Ouvrir http://localhost:8000
```

- Identifiants de la base (énoncé) : `MasTMound2` / `MoundMasT2@2026`, modifiables dans `includes/db.php`.
- Nom de base utilisé : `gestion_commande` (non imposé par l'énoncé).
- Le dossier `uploads/` doit être accessible en écriture (photos produits et clients).
- Avec XAMPP/WAMP : copier le dossier dans `htdocs`/`www` et importer `sql/schema.sql` via phpMyAdmin.

## Application mobile Flutter
Une version Android (Flutter) est fournie dans `flutter_app/` ; elle utilise l'**API JSON** `api/index.php` de ce projet. Voir [`flutter_app/README.md`](flutter_app/README.md). Lancer le serveur avec `php -S 0.0.0.0:8000` pour qu'elle soit joignable.

## Structure
```
index.php  produits.php  produit_ajouter.php  produit_modifier.php
commandes.php  commande_ajouter.php  commande_detail.php
clients.php  dashboard.php
api/        index.php (API JSON pour l'application mobile)
flutter_app/  application Flutter (Android)
includes/   db.php (PDO, CSRF, upload)  header.php  footer.php
sql/        schema.sql  analyse_performance.sql
assets/     chart.umd.js (Chart.js 4.4.1, en local : fonctionne hors ligne)
uploads/    images envoyées
docs/captures/   captures d'écran de ce README
CORRECTION.md    barème indicatif et justification des choix
```

---

## Captures d'écran

### 1. Produits (Q2) : liste, ajout, suppression
Liste des produits avec les boutons **Modifier** et **Supprimer**, et le bouton **+ Ajouter un produit**.
![Liste des produits](docs/captures/01-produits.png)

Formulaire d'ajout d'un produit :
![Ajout d'un produit](docs/captures/02-produit-ajouter.png)

Le produit apparaît dans la liste après l'ajout :
![Produit ajouté](docs/captures/03-produit-ajoute.png)

### 2. Modification d'un produit (Q3)
![Modification d'un produit](docs/captures/04-produit-modifier.png)

### 3. Règle d'intégrité : un produit déjà commandé ne peut pas être supprimé
La suppression est refusée pour conserver l'historique des ventes :
![Suppression refusée](docs/captures/05-suppression-refusee.png)

Un produit jamais commandé se supprime normalement :
![Produit supprimé](docs/captures/06-produit-supprime.png)

### 4. Commandes (Q2)
![Liste des commandes](docs/captures/07-commandes.png)

### 5. Nouvelle commande avec un **nouveau client**
On choisit « Nouveau client » et on saisit nom, prénom, email, région et photo facultative. Le client et la commande sont créés dans une seule transaction. Pour un client existant, on le choisit simplement dans la liste.
![Nouvelle commande, nouveau client](docs/captures/08-commande-nouveau-client.png)

### 6. Produits d'une commande (Q1 et Q4)
Ajout de produits (stock contrôlé et décrémenté) :
![Détail d'une commande](docs/captures/09-commande-detail.png)

Suppression d'une ligne (stock restitué) :
![Ligne supprimée](docs/captures/10-ligne-supprimee.png)

La liste des commandes affiche la nouvelle commande avec son total :
![Commandes après ajout](docs/captures/11-commandes-apres.png)

### 7. Clients (Q2)
Le nouveau client créé via la commande apparaît dans la liste :
![Liste des clients](docs/captures/12-clients.png)

### 8. Tableau de bord (Q5)
Indicateurs clés (commandes, chiffre d'affaires, articles vendus, panier moyen), CA par mois, top 5 produits, CA par département, top 5 clients et alertes de stock faible :
![Tableau de bord](docs/captures/13-dashboard.png)

### 9. Suppression d'une commande
La commande et ses lignes sont supprimées, le stock est restitué :
![Commande supprimée](docs/captures/14-commande-supprimee.png)

---

## Sécurité et bonnes pratiques
- Requêtes préparées PDO (pas d'injection SQL) ; échappement HTML en sortie (XSS) ; jeton CSRF sur chaque formulaire.
- Opérations sensibles dans des **transactions** (`FOR UPDATE` pour éviter la survente).
- Utilisateur SQL aux droits minimaux (SELECT/INSERT/UPDATE/DELETE).
- Upload d'images contrôlé (type MIME réel, 2 Mo max, nom aléatoire) et exécution PHP interdite dans `uploads/`.

## Limites connues
Pas d'authentification applicative ni de pagination. Le prix est stocké dans `Produit` (modèle imposé), donc le CA historique varie si un prix change ; en production, on ajouterait le prix unitaire dans `ligneCommande`.

Détails de conception et justification du tableau de bord : voir [`CORRECTION.md`](CORRECTION.md).
