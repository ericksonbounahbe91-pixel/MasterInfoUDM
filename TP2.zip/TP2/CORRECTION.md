# Correction – TP Gestion d'une ligne de commande (PHP / PDO / MySQL)

## Mise en place
1. `mysql -u root -p --default-character-set=utf8mb4 < sql/schema.sql` (tables, clés étrangères, utilisateur `MasTMound2`, jeu d'essai, vue).
2. Copier le dossier dans `htdocs`/`www`, ouvrir `index.php`. (Ou : `php -S localhost:8000`.)
3. Le nom de base `gestion_commande` est un choix (l'énoncé ne le donne pas) : à adapter dans `includes/db.php`.

## Barème indicatif et fichiers
| Q | Fichier | Points clés attendus |
|---|---------|----------------------|
| 1 | `commande_detail.php` (formulaire « Ajouter un produit ») | choix de produit + quantité, requête préparée, refus des doublons (PK composite), contrôle du stock, **transaction** INSERT ligne + UPDATE stock |
| 2 | `produits.php`, `commandes.php`, `clients.php` | jointures (région/département, total par commande), échappement `h()` |
| 3 | `produit_modifier.php` | pré-remplissage, validation serveur, UPDATE préparé, redirection après POST |
| 4 | `commande_detail.php` (action `supprimer`) | DELETE sur la clé composite `(idCmd,idProd)`, **restitution du stock** dans la même transaction, confirmation |
| ++ | `produit_ajouter.php`, `produits.php` | ajout (avec photo optionnelle validée par type MIME) ; suppression **refusée** si le produit figure dans une commande (intégrité de l'historique) |
| ++ | `commande_ajouter.php`, `commandes.php` | choix client existant **ou** saisie d'un nouveau client (nom, prénom, email unique, région, photo) créé dans la **même transaction** que la commande ; suppression d'une commande = restitution du stock + suppression des lignes, en transaction |
| 5 | `dashboard.php`, `sql/analyse_performance.sql` | voir ci-dessous |

## Choix de conception (à justifier à l'oral/écrit)
- **PDO + requêtes préparées** : protège contre l'injection SQL ; `ATTR_EMULATE_PREPARES=false`.
- **Droits minimaux** : l'utilisateur n'a que SELECT/INSERT/UPDATE/DELETE, pas de DROP/ALTER.
- **Transactions + `SELECT … FOR UPDATE`** : l'ajout/suppression d'une ligne et la mise à jour du stock sont atomiques ; pas de survente si deux utilisateurs commandent en même temps.
- **Jeton CSRF** sur tous les POST ; **échappement XSS** (`htmlspecialchars`) en sortie.
- **Post/Redirect/Get** : évite la double soumission au rafraîchissement.
- **Suppression d'un produit « dans une commande »** = suppression de la *ligne* de commande, pas du produit du catalogue (qui casserait l'historique).

## Q5 – Tableau de bord
**Indicateurs retenus et pourquoi**
- KPI : nombre de commandes, chiffre d'affaires, articles vendus, panier moyen → vue synthétique pour décider.
- CA par mois (courbe) → tendance / saisonnalité.
- Top 5 produits (barres) → principe de Pareto, quoi réapprovisionner ou promouvoir.
- Top 5 clients → fidélisation.
- CA par département (jointure client→région→département) → exploite le modèle géographique.
- Alerte stock < 10 → lien direct avec la ligne de commande (le stock baisse à chaque vente).

Les montants sont calculés une seule fois dans la vue `v_ligne_detail` (`qteCmd × prixUProd`) : une seule source de vérité, requêtes du dashboard simples. Le prix étant dans `Produit`, le CA historique change si le prix change ; en production on ajouterait `prixUnitaire` dans `ligneCommande` (limite du modèle imposé, à mentionner).

**Analyse de performance**
- Index : `commande(dateCmd)` (période), `commande(idCli)`, `ligneCommande(idProd)` ; la PK `(idCmd,idProd)` sert déjà aux jointures par commande.
- `EXPLAIN` : vérifier l'absence de `type=ALL` sur les grosses tables.
- Agrégation SQL côté serveur (pas de boucles PHP sur des milliers de lignes) ; `LIMIT 5` pour les tops.
- Au-delà de quelques centaines de milliers de lignes : table d'agrégats `stat_mensuelle` rafraîchie la nuit, ou cache de quelques minutes.
- Mesure : comparer temps avant/après index (`SET profiling`/`EXPLAIN ANALYZE`) sur un jeu de test généré.

## Limites / pistes d'amélioration
Pas d'authentification applicative ni pagination. Les images sont stockées dans `uploads/` (dossier à rendre accessible en écriture au serveur web).
