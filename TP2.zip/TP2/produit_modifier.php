<?php require 'includes/header.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'idProd', FILTER_VALIDATE_INT);
$st = db()->prepare('SELECT * FROM produit WHERE idProd = ?');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) { http_response_code(404); exit('Produit introuvable'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $design = trim($_POST['designProd'] ?? '');
    $stock  = filter_var($_POST['qteStock'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    $prix   = filter_var($_POST['prixUProd'] ?? '', FILTER_VALIDATE_FLOAT);
    if ($design === '' || $stock === false || $prix === false || $prix < 0) {
        flash('Données invalides.', 'err');
    } else {
        db()->prepare('UPDATE produit SET designProd=?, qteStock=?, prixUProd=? WHERE idProd=?')
            ->execute([$design, $stock, $prix, $id]);
        flash('Produit modifié.');
        header('Location: produits.php'); exit;
    }
}
?>
<h1>Modifier le produit #<?= $p['idProd'] ?></h1>
<form method="post" class="card">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="idProd" value="<?= $p['idProd'] ?>">
  <label>Désignation<br><input name="designProd" required maxlength="120" value="<?= h($p['designProd']) ?>"></label><br>
  <label>Stock<br><input type="number" name="qteStock" min="0" required value="<?= $p['qteStock'] ?>"></label><br>
  <label>Prix unitaire<br><input type="number" step="0.01" min="0" name="prixUProd" required value="<?= $p['prixUProd'] ?>"></label><br>
  <button>Enregistrer</button> <a href="produits.php">Annuler</a>
</form>
<?php require 'includes/footer.php'; ?>
