package Appliste;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EtudiantDAO {
	public boolean ajouter(Etudiant e) {
        String sql = "INSERT INTO etudiant (matricule, nom, prenom, age, filiere) VALUES (?, ?, ?, ?, ?)";
        try (Connection cn = ConnectiondataB.getConnexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, e.getMatricule());
            ps.setString(2, e.getNom());
            ps.setString(3, e.getPrenom());
            ps.setInt(4, e.getAge());
            ps.setString(5, e.getFiliere());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;

}
    }


public boolean modifier(Etudiant e) {
    String sql = "UPDATE etudiant SET nom = ?, prenom = ?, age = ?, filiere = ? WHERE matricule = ?";
    try (Connection cn = ConnectiondataB.getConnexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setString(1, e.getNom());
        ps.setString(2, e.getPrenom());
        ps.setInt(3, e.getAge());
        ps.setString(4, e.getFiliere());
        ps.setString(5, e.getMatricule());
        return ps.executeUpdate() > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

public boolean supprimer(String matricule) {
    String sql = "DELETE FROM etudiant WHERE matricule = ?";
    try (Connection cn = ConnectiondataB.getConnexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setString(1, matricule);
        return ps.executeUpdate() > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

public Etudiant rechercherParMatricule(String matricule) {
    String sql = "SELECT * FROM etudiant WHERE matricule = ?";
    try (Connection cn = ConnectiondataB.getConnexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setString(1, matricule);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new Etudiant(
                        rs.getString("matricule"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getInt("age"),
                        rs.getString("filiere"));
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return null;
}

public List<Etudiant> rechercherParNom(String nom) {
    List<Etudiant> resultat = new ArrayList<>();
    String sql = "SELECT * FROM etudiant WHERE nom LIKE ?";
    try (Connection cn = ConnectiondataB.getConnexion();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setString(1, "%" + nom + "%");
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                resultat.add(new Etudiant(
                        rs.getString("matricule"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getInt("age"),
                        rs.getString("filiere")));
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return resultat;
}

public List<Etudiant> listerTous() {
    List<Etudiant> resultat = new ArrayList<>();
    String sql = "SELECT * FROM etudiant ORDER BY matricule";
    try (Connection cn = ConnectiondataB.getConnexion();
         PreparedStatement ps = cn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            resultat.add(new Etudiant(
                    rs.getString("matricule"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("age"),
                    rs.getString("filiere")));
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return resultat;
}
}


