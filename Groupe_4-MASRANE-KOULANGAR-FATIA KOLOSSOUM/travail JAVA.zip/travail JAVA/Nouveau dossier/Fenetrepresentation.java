package Appliste;
import javax.swing.*;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class Fenetrepresentation extends JFrame  {
    private JTextField champMatricule, champNom, champPrenom, champAge, champFiliere, champRecherche;
    private JTable table;
    private DefaultTableModel modele;
    private final EtudiantDAO dao = new EtudiantDAO();
 
    public Fenetrepresentation() {
        super("liste");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
 
        add(construireFormulaire(), BorderLayout.NORTH);
        add(construireTable(), BorderLayout.CENTER);
 
        actualiserTable();
    }
 
    private JPanel construireFormulaire() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Informations de l'etudiant"));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
 
        champMatricule = new JTextField(15);
        champNom = new JTextField(15);
        champPrenom = new JTextField(15);
        champAge = new JTextField(15);
        champFiliere = new JTextField(15);
        champRecherche = new JTextField(15);
 
        String[] labels = {"Matricule :", "Nom :", "Prenom :", "Age :", "Filiere :"};
        JTextField[] champs = {champMatricule, champNom, champPrenom, champAge, champFiliere};
 
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0; c.gridy = i;
            panel.add(new JLabel(labels[i]), c);
            c.gridx = 1;
            panel.add(champs[i], c);
        }
 
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnModifier = new JButton("Modifier");
        JButton btnSupprimer = new JButton("Supprimer");
        JButton btnReinitialiser = new JButton("Reinitialiser");
        JButton btnRechercher = new JButton("Rechercher");
 
        btnAjouter.setBackground(new Color(46, 139, 87));
        btnAjouter.setForeground(Color.WHITE);
        btnAjouter.setOpaque(true);
        btnAjouter.setBorderPainted(false);
        
        btnModifier.setBackground(new Color(255, 165, 0));
        btnModifier.setForeground(Color.WHITE);
        btnModifier.setOpaque(true);
        btnModifier.setBorderPainted(false);
        
        btnSupprimer.setBackground(new Color(220, 20, 60));
        btnSupprimer.setForeground(Color.WHITE);
        btnSupprimer.setOpaque(true);
        btnSupprimer.setBorderPainted(false);
        
        btnRechercher.setBackground(new Color(30, 144, 255));
        btnRechercher.setForeground(Color.WHITE);
        btnRechercher.setOpaque(true);
        btnRechercher.setBorderPainted(false);
        
        btnReinitialiser.setBackground(new Color(128, 128, 128));
        btnReinitialiser.setForeground(Color.WHITE);
        btnReinitialiser.setOpaque(true);
        btnReinitialiser.setBorderPainted(false);
        
        JPanel panelBoutons = new JPanel(new GridLayout(5, 1, 5, 5));
        panelBoutons.add(btnAjouter);
        panelBoutons.add(btnModifier);
        panelBoutons.add(btnSupprimer);
        panelBoutons.add(btnRechercher);
        panelBoutons.add(btnReinitialiser);
 
        c.gridx = 2; c.gridy = 0; c.gridheight = 5;
        panel.add(panelBoutons, c);
        c.gridheight = 1;
 
        c.gridx = 0; c.gridy = 5;
        panel.add(new JLabel("Recherche (nom ou matricule):"), c);
        c.gridx = 1;
        panel.add(champRecherche, c);
 
        btnAjouter.addActionListener(this::actionAjouter);
        btnModifier.addActionListener(this::actionModifier);
        btnSupprimer.addActionListener(this::actionSupprimer);
        btnRechercher.addActionListener(this::actionRechercher);
        btnReinitialiser.addActionListener(this::actionReinitialiser);
 
        return panel;
    }
 
    private JScrollPane construireTable() {
        String[] colonnes = {"Matricule", "Nom", "Prenom", "Age", "Filiere"};
        modele = new DefaultTableModel(colonnes, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        table = new JTable(modele);
        table.getSelectionModel().addListSelectionListener(e -> remplirFormulaireDepuisTable());
        return new JScrollPane(table);
    }
 
    private void remplirFormulaireDepuisTable() {
        int ligne = table.getSelectedRow();
        if (ligne >= 0) {
            champMatricule.setText(modele.getValueAt(ligne, 0).toString());
            champNom.setText(modele.getValueAt(ligne, 1).toString());
            champPrenom.setText(modele.getValueAt(ligne, 2).toString());
            champAge.setText(modele.getValueAt(ligne, 3).toString());
            champFiliere.setText(modele.getValueAt(ligne, 4).toString());
        }
    }
 
    private void actionAjouter(ActionEvent e) {
        if (!champsValides()) return;
        Etudiant etu = lireFormulaire();
        if (dao.ajouter(etu)) {
            JOptionPane.showMessageDialog(this, "Etudiant ajoute avec succes.");
            actualiserTable();
            actionReinitialiser(null);
        } else {
            JOptionPane.showMessageDialog(this, "Erreur lors de l'ajout (matricule deja existant ?).",
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    private void actionModifier(ActionEvent e) {
        if (!champsValides()) return;
        Etudiant etu = lireFormulaire();
        if (dao.modifier(etu)) {
            JOptionPane.showMessageDialog(this, "Etudiant modifie avec succes.");
            actualiserTable();
            actionReinitialiser(null);
        } else {
            JOptionPane.showMessageDialog(this, "Aucun etudiant modifie (matricule introuvable).",
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    private void actionSupprimer(ActionEvent e) {
        String matricule = champMatricule.getText().trim();
        if (matricule.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez selectionner un etudiant.",
                    "Attention", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int reponse = JOptionPane.showConfirmDialog(this,
                "Voulez-vous vraiment supprimer cet etudiant ?",
                "Confirmation", JOptionPane.YES_NO_OPTION);
        if (reponse == JOptionPane.YES_OPTION) {
            if (dao.supprimer(matricule)) {
                JOptionPane.showMessageDialog(this, "Etudiant supprime.");
                actualiserTable();
                actionReinitialiser(null);
            } else {
                JOptionPane.showMessageDialog(this, "Erreur lors de la suppression.",
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
 
    private void actionRechercher(ActionEvent e) {
        String texte = champRecherche.getText().trim();
        modele.setRowCount(0);
        if (texte.isEmpty()) {
            actualiserTable();
            return;
        }
        List<Etudiant> resultats = new ArrayList<>();
        if (resultats.isEmpty()) {
            Etudiant parMatricule = dao.rechercherParMatricule(texte);
            if (parMatricule != null && !resultats.contains(parMatricule));
            resultats.add(parMatricule);
        }
        for (Etudiant etu : resultats) {
            ajouterLigne(etu);
        }
    }
 
    private void actionReinitialiser(ActionEvent e) {
        champMatricule.setText("");
        champNom.setText("");
        champPrenom.setText("");
        champAge.setText("");
        champFiliere.setText("");
        champRecherche.setText("");
        table.clearSelection();
    }
 
    private void actualiserTable() {
        modele.setRowCount(0);
        for (Etudiant etu : dao.listerTous()) {
            ajouterLigne(etu);
        }
    }
 
    private void ajouterLigne(Etudiant etu) {
        modele.addRow(new Object[]{
                etu.getMatricule(), etu.getNom(), etu.getPrenom(), etu.getAge(), etu.getFiliere()
        });
    }
 
    private Etudiant lireFormulaire() {
        return new Etudiant(
                champMatricule.getText().trim(),
                champNom.getText().trim(),
                champPrenom.getText().trim(),
                Integer.parseInt(champAge.getText().trim()),
                champFiliere.getText().trim()
        );
    }
 
    private boolean champsValides() {
        if (champMatricule.getText().trim().isEmpty()
                || champNom.getText().trim().isEmpty()
                || champPrenom.getText().trim().isEmpty()
                || champAge.getText().trim().isEmpty()
                || champFiliere.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.",
                    "Champs incomplets", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            Integer.parseInt(champAge.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "L'age doit etre un nombre entier.",
                    "Erreur de saisie", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}


