package Appliste;
import javax.swing.SwingUtilities;
public class Pointentre {

	    public static void main(String[] args) {
	        SwingUtilities.invokeLater(() -> {
	        	Fenetrepresentation fenetre = new Fenetrepresentation();
	            fenetre.setVisible(true);
	            });
	    }
}
	        
	    



