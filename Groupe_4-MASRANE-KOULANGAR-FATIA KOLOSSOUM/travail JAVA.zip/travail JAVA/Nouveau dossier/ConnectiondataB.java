package Appliste;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectiondataB {
    private static final String URL = "jdbc:mysql://localhost:3306/listedesetudiants";
    private static final String UTILISATEUR = "root";
    private static final String MOT_DE_PASSE = "";

    public static Connection getConnexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, UTILISATEUR, MOT_DE_PASSE);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Pilote JDBC MySQL introuvable.", e);
        }
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
