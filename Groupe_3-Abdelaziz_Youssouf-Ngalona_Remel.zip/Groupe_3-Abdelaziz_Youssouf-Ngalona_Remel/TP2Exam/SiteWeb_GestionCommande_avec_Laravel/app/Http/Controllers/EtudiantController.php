<?php

namespace App\Http\Controllers;

use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class EtudiantController extends Controller
{
    // Accueil
    public function accueil()
    {
        $total = Etudiant::count();
        $etudiants = Etudiant::latest()->get();

        return view('etudiants', compact('total', 'etudiants'));
    }
    // Liste et recherche par nom
    public function index(Request $request)
    {
        $recherche = $request->input('search');

        $etudiants = Etudiant::when($recherche, function ($query, $recherche) {
            $query->where('nom', 'like', '%' . $recherche . '%');
        })
        ->orderBy('id', 'desc')
        ->get();

        return view('etudiants.index', compact('etudiants', 'recherche'));
    }

    // Formulaire d'ajout
    public function create()
    {
        return view('etudiants.create');
    }

    // Enregistrer
    public function store(Request $request)
    {
        $donnees = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:etudiants,email',
        ]);

        Etudiant::create($donnees);

        return redirect()->route('etudiants.index')
            ->with('success', 'Étudiant ajouté avec succès !');
    }

    // Formulaire de modification
    public function edit(Etudiant $etudiant)
    {
        return view('etudiants.edit', compact('etudiant'));
    }

    // Enregistrer les modifications
    public function update(Request $request, Etudiant $etudiant)
    {
        $donnees = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('etudiants', 'email')->ignore($etudiant->id),
            ],
        ]);

        $etudiant->update($donnees);

        return redirect()->route('etudiants.index')
            ->with('success', 'Étudiant modifié avec succès !');
    }

    // Supprimer
    public function destroy(Etudiant $etudiant)
    {
        $etudiant->delete();

        return redirect()->route('etudiants.index')
            ->with('success', 'Étudiant supprimé avec succès !');
    }
}