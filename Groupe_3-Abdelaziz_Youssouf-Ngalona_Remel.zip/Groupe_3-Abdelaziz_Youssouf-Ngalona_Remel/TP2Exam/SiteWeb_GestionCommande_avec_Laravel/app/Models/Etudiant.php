<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Etudiant extends Model
{
    protected $fillable = [
        'user_id',
        'nom',
        'prenom',
        'email',
        'matricule',
        'date_naissance',
        'telephone',
        'faculte',
        'filiere',
        'niveau',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
