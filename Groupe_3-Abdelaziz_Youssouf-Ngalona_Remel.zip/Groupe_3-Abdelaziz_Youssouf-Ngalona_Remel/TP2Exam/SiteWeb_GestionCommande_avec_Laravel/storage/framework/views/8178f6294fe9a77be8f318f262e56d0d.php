


<?php $__env->startSection('content'); ?>
<section class="formations-section">
    <div class="formations-entete">
        <span class="surtitre">UNIVERSITÉ DE MOUNDOU</span>
        <h1>Nos formations</h1>
        <p>
            Découvrez nos quatre facultés et les domaines de formation
            de notre université.
        </p>
    </div>

    <div class="facultes-grille">

        <article class="faculte-carte">
            <div class="faculte-image image-entreprise">
                <span>01</span>
                <div class="faculte-icone">📊</div>
            </div>
            <div class="faculte-contenu">
                <span class="faculte-label">ÉCONOMIE ET GESTION</span>
                <h2>Faculté des Sciences et Techniques d’Entreprise</h2>
                <p>
                    Découvrez les formations et les domaines liés
                    à l’entreprise, à la gestion et à l’économie.
                </p>
            </div>
        </article>

        <article class="faculte-carte">
            <div class="faculte-image image-droit">
                <span>02</span>
                <div class="faculte-icone">⚖️</div>
            </div>
            <div class="faculte-contenu">
                <span class="faculte-label">DROIT ET SOCIÉTÉ</span>
                <h2>Faculté de Droit et Sciences Sociales</h2>
                <p>
                    Explorez les domaines du droit, des institutions
                    et des sciences sociales.
                </p>
            </div>
        </article>

        <article class="faculte-carte">
            <div class="faculte-image image-lettres">
                <span>03</span>
                <div class="faculte-icone">📚</div>
            </div>
            <div class="faculte-contenu">
                <span class="faculte-label">LETTRES ET HUMANITÉS</span>
                <h2>Faculté des Lettres, Arts et Sciences Humaines</h2>
                <p>
                    Découvrez les domaines des lettres, des arts
                    et des sciences humaines.
                </p>
            </div>
        </article>

        <article class="faculte-carte">
            <div class="faculte-image image-sciences">
                <span>04</span>
                <div class="faculte-icone">🔬</div>
            </div>
            <div class="faculte-contenu">
                <span class="faculte-label">SCIENCES ET TECHNOLOGIES</span>
                <h2>Faculté des Sciences Exactes et Appliquées</h2>
                <p>
                    Découvrez les domaines des sciences exactes
                    et de leurs applications.
                </p>
            </div>
        </article>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\CCIT\mon-projet\resources\views/formations.blade.php ENDPATH**/ ?>