
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion étudiant - Université de Moundou</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .carte {
            width: 100%;
            max-width: 440px;
            padding: 30px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 20px #00000010;
        }

        h1, h2 {
            text-align: center;
            color: #1246a0;
        }

        label {
            display: block;
            margin: 16px 0 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 22px;
            border: none;
            border-radius: 7px;
            background: #1246a0;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .erreur { color: #b91c1c; }
        .succes { color: #15803d; }
        .bas { text-align: center; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="carte">
        <h1>Université de Moundou</h1>
        <h2>Connexion étudiant</h2>

        <?php if(session('success')): ?>
            <p class="succes"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="erreur">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($erreur); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('connexion.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label for="email">Adresse e-mail</label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                autocomplete="email"
                required
            >

            <label for="password">Mot de passe</label>
            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Se connecter</button>
        </form>

        <div class="bas">
            Pas encore de compte ?
            <a href="<?php echo e(route('inscription')); ?>">Créer un compte</a>
            <p><a href="<?php echo e(route('accueil')); ?>">Retour à l'accueil</a></p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\CCIT\mon-projet\resources\views/auth/connexion.blade.php ENDPATH**/ ?>