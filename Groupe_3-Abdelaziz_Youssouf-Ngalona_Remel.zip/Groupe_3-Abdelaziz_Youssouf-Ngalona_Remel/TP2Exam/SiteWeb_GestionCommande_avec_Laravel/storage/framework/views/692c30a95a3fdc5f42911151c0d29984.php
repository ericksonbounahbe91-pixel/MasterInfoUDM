
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription étudiant - Université de Moundou</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        .conteneur {
            max-width: 750px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 5px 20px #00000010;
        }

        h1, h2 { color: #1246a0; }

        h1 { text-align: center; }

        .grille {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        label {
            display: block;
            margin: 12px 0 7px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            font-size: 15px;
        }

        button {
            width: 100%;
            padding: 14px;
            margin-top: 24px;
            border: none;
            border-radius: 7px;
            background: #1246a0;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .erreur { color: #b91c1c; }

        .connexion {
            text-align: center;
            margin-top: 20px;
        }

        @media (max-width: 600px) {
            .grille { grid-template-columns: 1fr; }
            .conteneur { padding: 20px; }
        }
    </style>
</head>

<body>
<div class="conteneur">
    <h1>Université de Moundou</h1>
    <h2>Inscription de l'étudiant</h2>

    <p>Remplissez vos informations pour créer votre compte étudiant.</p>

    <?php if($errors->any()): ?>
        <div class="erreur">
            <p>Veuillez corriger les erreurs suivantes :</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($erreur); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('inscription.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="grille">
            <div>
                <label for="nom">Nom</label>
                <input id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required>
            </div>

            <div>
                <label for="prenom">Prénom</label>
                <input id="prenom" name="prenom" value="<?php echo e(old('prenom')); ?>" required>
            </div>

            <div>
                <label for="matricule">Matricule étudiant</label>
                <input id="matricule" name="matricule" value="<?php echo e(old('matricule')); ?>" required>
            </div>

            <div>
                <label for="date_naissance">Date de naissance</label>
                <input type="date" id="date_naissance" name="date_naissance"
                       value="<?php echo e(old('date_naissance')); ?>" required>
            </div>

            <div>
                <label for="telephone">Téléphone</label>
                <input type="tel" id="telephone" name="telephone"
                       value="<?php echo e(old('telephone')); ?>" required>
            </div>

            <div>
                <label for="faculte">Faculté</label>
                <input id="faculte" name="faculte"
                       value="<?php echo e(old('faculte')); ?>" required>
            </div>

            <div>
                <label for="filiere">Filière</label>
                <input id="filiere" name="filiere"
                       value="<?php echo e(old('filiere')); ?>" required>
            </div>

            <div>
                <label for="niveau">Niveau d'études</label>
                <select id="niveau" name="niveau" required>
                    <option value="">Choisir le niveau</option>
                    <?php $__currentLoopData = ['Licence 1', 'Licence 2', 'Licence 3', 'Master 1', 'Master 2', 'Doctorat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $niveau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($niveau); ?>"
                            <?php if(old('niveau') === $niveau): echo 'selected'; endif; ?>>
                            <?php echo e($niveau); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="email">Adresse e-mail</label>
                <input type="email" id="email" name="email"
                       value="<?php echo e(old('email')); ?>" required>
            </div>

            <div>
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password"
                       minlength="8" autocomplete="new-password" required>
            </div>

            <div>
                <label for="password_confirmation">Confirmer le mot de passe</label>
                <input type="password" id="password_confirmation"
                       name="password_confirmation"
                       minlength="8" autocomplete="new-password" required>
            </div>
        </div>

        <button type="submit">Créer mon compte</button>
    </form>

    <div class="connexion">
        Vous avez déjà un compte ?
        <a href="<?php echo e(route('connexion')); ?>">Se connecter</a>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\CCIT\mon-projet\resources\views/auth/inscription.blade.php ENDPATH**/ ?>