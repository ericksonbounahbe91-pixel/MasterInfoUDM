

<?php $__env->startSection('title', 'Liste des étudiants'); ?>

<?php $__env->startSection('content'); ?>
<section class="carte">
    <h2>Liste des étudiants</h2>

    <form action="<?php echo e(route('etudiants.index')); ?>"
          method="GET" class="recherche">

        <div class="champ">
            <label for="search">Rechercher par nom</label>
            <input type="text" id="search" name="search"
                   value="<?php echo e($recherche); ?>"
                   placeholder="Saisir le nom recherché...">
        </div>

        <button type="submit">Rechercher</button>

        <a class="bouton secondaire"
           href="<?php echo e(route('etudiants.index')); ?>">
            Réinitialiser
        </a>
    </form>

    <p>Nombre de résultats : <?php echo e($etudiants->count()); ?></p>

    <div class="table-conteneur">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>E-mail</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($etudiant->id); ?></td>
                        <td><?php echo e($etudiant->nom); ?></td>
                        <td><?php echo e($etudiant->prenom); ?></td>
                        <td><?php echo e($etudiant->email); ?></td>

                        <td>
                            <div class="actions">
                                <a class="bouton modifier"
                                   href="<?php echo e(route('etudiants.edit', $etudiant)); ?>">
                                    Modifier
                                </a>

                                <form
                                    action="<?php echo e(route('etudiants.destroy', $etudiant)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Voulez-vous vraiment supprimer cet étudiant ?')">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="supprimer">
                                        Supprimer
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">
                            Aucun étudiant trouvé.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\CCIT\mon-projet\resources\views/etudiants/index.blade.php ENDPATH**/ ?>