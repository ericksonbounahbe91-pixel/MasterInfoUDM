<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Université de Moundou | Gestion des étudiants</title>

    <style>
        * {
            box-sizing: border-box;
            scroll-behavior: smooth;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #eef2f8;
            color: #263247;
        }

        /* EN-TÊTE ET MENU */
        .entete {
            background: #1246a0;
            color: white;
            padding: 14px 5%;
        }

        .barre-navigation {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            flex-wrap: wrap;
        }

        .identite {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .logo {
            width: 75px;
            height: 75px;
            object-fit: contain;
            background: white;
            border-radius: 50%;
            padding: 5px;
        }

        .identite h1 {
            font-size: 20px;
            margin: 0 0 6px;
        }

        .identite p {
            font-size: 12px;
            margin: 0;
        }

        nav {
            display: flex;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        nav a:hover {
            color: #ffdc73;
        }

        /* BANNIÈRE */
        .banniere {
            background: linear-gradient(
                120deg,
                #1246a0,
                #1768c4
            );
            color: white;
            text-align: center;
            padding: 65px 20px;
        }

        .banniere h2 {
            font-size: 34px;
            margin: 0 0 15px;
        }

        .banniere p {
            max-width: 700px;
            margin: auto;
            line-height: 1.8;
        }

        .bouton-banniere {
            display: inline-block;
            margin-top: 25px;
            background: white;
            color: #1246a0;
            text-decoration: none;
            padding: 13px 22px;
            border-radius: 7px;
            font-weight: bold;
        }

        /* CONTENU */
        main {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .carte {
            background: white;
            padding: 28px;
            margin-bottom: 28px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
        }

        .titre-section {
            color: #1246a0;
            border-left: 5px solid #1246a0;
            padding-left: 12px;
            margin-top: 0;
            margin-bottom: 22px;
        }

        /* ACTUALITÉS */
        .actualites-container {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
        }

        .actualite-card {
            border: 1px solid #e0e5ed;
            border-radius: 10px;
            overflow: hidden;
            background: white;
            transition: transform 0.2s;
        }

        .actualite-card:hover {
            transform: translateY(-4px);
        }

        .actualite-card img {
            display: block;
            width: 100%;
            height: 210px;
            object-fit: cover;
        }

        .actualite-contenu {
            padding: 18px;
        }

        .actualite-contenu h3 {
            color: #1246a0;
            font-size: 17px;
        }

        .actualite-contenu p {
            line-height: 1.6;
            font-size: 14px;
        }

        .actualite-contenu a {
            color: #1246a0;
            font-weight: bold;
            text-decoration: none;
        }

        /* FORMULAIRE */
        .formulaire {
            max-width: 850px;
            margin: auto;
        }

        .grille-formulaire {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }

        .champ {
            margin-bottom: 5px;
        }

        .champ label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            font-size: 14px;
        }

        .champ input,
        .champ select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd3df;
            border-radius: 7px;
            font-size: 15px;
            background: white;
        }

        .champ input:focus,
        .champ select:focus {
            outline: none;
            border-color: #1246a0;
        }

        .pleine-largeur {
            grid-column: 1 / -1;
        }

        .bouton {
            background: #1246a0;
            color: white;
            padding: 13px 22px;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-size: 15px;
            font-weight: bold;
        }

        .bouton:hover {
            background: #0b347a;
        }

        .message {
            padding: 13px;
            border-radius: 7px;
            margin-bottom: 18px;
        }

        .succes {
            background: #d1e7dd;
            color: #0f5132;
        }

        .erreurs {
            background: #f8d7da;
            color: #842029;
        }

        /* TABLEAU DES ÉTUDIANTS */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #e0e5ed;
            padding: 13px;
            text-align: left;
        }

        th {
            background: #1246a0;
            color: white;
        }

        tbody tr:nth-child(even) {
            background: #f4f7fb;
        }

        /* PRÉSENTATION ET FORMATIONS */
        .texte-section {
            line-height: 1.8;
        }

        .formations {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
        }

        .formation {
            background: #f1f5fc;
            padding: 20px;
            border-radius: 8px;
            border-top: 4px solid #1246a0;
        }

        .formation h3 {
            color: #1246a0;
        }

        /* PIED DE PAGE */
        footer {
            background: #0b2f6b;
            color: white;
            text-align: center;
            padding: 25px 15px;
            line-height: 1.8;
        }

        footer p {
            margin: 5px;
        }

        @media (max-width: 850px) {
            .barre-navigation {
                flex-direction: column;
                align-items: flex-start;
            }

            nav {
                gap: 15px;
            }

            .actualites-container,
            .formations {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 600px) {
            .actualites-container,
            .formations,
            .grille-formulaire {
                grid-template-columns: 1fr;
            }

            .pleine-largeur {
                grid-column: auto;
            }

            .banniere h2 {
                font-size: 26px;
            }

            .carte {
                padding: 18px;
            }
        }

        /* Barre de menu */
nav {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    padding: 15px 20px;
    background: #003b70;
    position: relative;
    z-index: 10;
}

nav a {
    color: white;
    text-decoration: none;
    padding: 10px 14px;
    border-radius: 6px;
    font-weight: bold;
    transition: background 0.3s;
}

nav a:hover {
    background: #0879c9;
}

/* Accueil avec vidéo en arrière-plan */
.hero {
    position: relative;
    min-height: 520px;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    text-align: left;
    padding: 180px 8% 50px !important;
    box-sizing: border-box;
    overflow: hidden;
    color: white;
}

/* Vidéo en plein écran dans la section */
.hero video {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 0;
}

/* Voile sombre au-dessus de la vidéo */
.hero::before {
    content: "";
    position: absolute;
    inset: 0;
    background: rgba(0, 25, 50, 0.62);
    z-index: 1;
}

/* Texte au-dessus de la vidéo */
.hero-content {
    position: relative;
    z-index: 2;
    width: 100%;
    max-width: 700px;
    margin: 0 !important;
    text-align: left !important;
}

.hero h1 {
    text-align: left !important;
    font-size: 48px;
    margin: 0 0 20px !important;
}

.hero p {
    text-align: left !important;
    font-size: 19px;
    line-height: 1.7;
}

.hero .bouton-accueil {
    display: inline-block;
    background: #0879c9;
    color: white;
    padding: 14px 25px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    transition: background 0.3s;
}

.hero .bouton-accueil:hover {
    background: #00569b;
}

@media (max-width: 600px) {
    .hero {
        min-height: 420px;
    }
}
    .hero p {
        font-size: 16px;
    }

    nav {
        gap: 5px;
        padding: 10px;
    }

    nav a {
        padding: 8px;
        font-size: 13px;
    }






/* MOT DU PRÉSIDENT : TEXTE À GAUCHE, PHOTOS À DROITE */
.president-contenu {
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
    gap: 30px;
    align-items: center;
}

.president-texte {
    min-width: 0;
    line-height: 1.8;
    text-align: justify;
}

.president-texte p {
    margin-top: 0;
    margin-bottom: 16px;
}

.president-texte h3 {
    color: #1246a0;
    font-size: 24px;
}

.signature-president {
    color: #1246a0;
    margin-top: 20px;
}

.president-photos {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    align-items: center;
}


.photo-president {
    display: block;
    width: 200%;
    height: 350px;
    object-fit: cover;
    border-radius: 14px;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.18);
}


.photo-president:nth-child(2) {
    margin-top: 30px;
}

@media (max-width: 700px) {
    .president-contenu {
        grid-template-columns: 1fr;
    }

    .photo-president {
        height: 220px;
    }
}

@media (max-width: 420px) {
    .president-photos {
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .photo-president {
        height: 180px;
    }
}

    

/* PIED DE PAGE */
.pied-page {
    background: #4f4eb3;
    color: white;
    margin-top: 40px;
    padding: 40px 25px 0;
}

.footer-contenu {
    max-width: 1200px;
    margin: auto;
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 35px;
    padding-bottom: 30px;
}

.footer-colonne h3 {
    color: #ffffff;
    margin-bottom: 18px;
    font-size: 20px;
}

.footer-colonne p {
    margin: 10px 0;
    line-height: 1.7;
    color: #e4ecff;
}

.footer-logo {
    width: 85px;
    height: 85px;
    object-fit: contain;
    background: white;
    border-radius: 50%;
    padding: 5px;
    margin-bottom: 12px;
}

.reseaux-sociaux {
    display: flex;
    gap: 15px;
}

.reseaux-sociaux a {
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: white;
    color: #200eec;
    text-decoration: none;
    font-size: 25px;
    font-weight: bold;
    transition: 0.3s;
}

.reseaux-sociaux a:hover {
    background: #f0b429;
    color: #848991;
    transform: translateY(-4px);
}

.footer-bas {
    border-top: 1px solid rgba(255, 255, 255, 0.25);
    text-align: center;
    padding: 18px 10px;
}

.footer-bas p {
    margin: 0;
    font-size: 14px;
}

@media (max-width: 700px) {
    .footer-contenu {
        grid-template-columns: 1fr;
        text-align: center;
    }

    .footer-logo {
        margin-left: auto;
        margin-right: auto;
    }

    .reseaux-sociaux {
        justify-content: center;
    }
}

    

    </style>
</head>

<body>

<!-- EN-TÊTE : LOGO ET MENU -->
<header class="entete" id="accueil">
    <div class="barre-navigation">
    
        <div class="identite">
             
            <img
                class="logo"
                src="<?php echo e(asset('images/logo-universite.png')); ?>"
                alt="Logo de l'Université de Moundou"
            >

            <div>
                <h1>UNIVERSITÉ <bbr>DE MOUNDOU</bbr></h1>
                
            </div>
        </div>

       

<nav>
    <a href="<?php echo e(route('accueil')); ?>">Accueil</a>
    <a href="<?php echo e(route('accueil')); ?>#president">Mot du Président</a>
    <a href="<?php echo e(route('accueil')); ?>#actualites">Actualités</a>
    <a href="<?php echo e(route('formations')); ?>">Nos formations</a>
    <a href="<?php echo e(route('inscription')); ?>">Inscription</a>
    <a href="<?php echo e(route('connexion')); ?>">Connexion</a>
    <a href="<?php echo e(route('etudiants.index')); ?>">Liste des étudiants</a>
    
</nav>



    </div>


</header>


<!-- BANNIÈRE D'ACCUEIL -->
<section class="hero" id="accueil">

    <video autoplay muted loop playsinline>
        <source src="<?php echo e(asset('videos/universite.mp4')); ?>" type="video/mp4">
        Votre navigateur ne prend pas en charge la lecture vidéo.
    </video>

    <div class="hero-content">
        <h1>Bienvenue à l'Université de Moundou</h1>

        <p>
            Un établissement d'enseignement supérieur engagé dans
            la formation, la recherche et l'excellence académique
            au service du développement du Tchad.
        </p>

        <a href="<?php echo e(route('inscription')); ?>" class="bouton-accueil">
            Rejoindre notre université
        </a>
    </div>

</section>

<main>

   
<!-- MOT DU PRÉSIDENT -->
<section class="carte" id="president">
    <h2 class="titre-section">Mot du Président</h2>

    <div class="president-contenu">

        <!-- TEXTE À GAUCHE -->
        <div class="president-texte">
            <p>
                Chères étudiantes, chers étudiants, chers collègues,
                partenaires et amis de l’Université de Moundou,
                c’est avec un immense plaisir que je vous souhaite
                la bienvenue sur le site officiel de l’Université
                de Moundou (UDM), véritable portail d’échanges,
                de savoir et d’innovation.
            </p>

            <p>
                Ce site a été conçu pour renforcer les liens entre
                les enseignants-chercheurs, le personnel administratif
                et technique, les étudiants, les anciens diplômés
                et nos partenaires institutionnels et économiques.
                Vous êtes ici chez vous.
            </p>

            <p>
                Notre ambition est claire : faire de cette plateforme un espace vivant,
                 fidèle reflet des activités, projets et ambitions de notre université. 
                 Vous y trouverez des informations actualisées sur nos formations, nos événements, 
                 nos opportunités de recherche, ainsi que les services mis à disposition de notre communauté.
            </p>

            <p class="signature-president">
                <strong>Le Président de l'Université de Moundou</strong>
            </p>
        </div>

        <!-- DEUX PHOTOS À DROITE -->
        <div class="president-photos">
            

            <img
                src="<?php echo e(asset('images/universite-president.jpg')); ?>"
                alt="Président dans le cadre universitaire"
                class="photo-president"
            >
        </div>

    </div>
</section>


    <!-- ACTUALITÉS -->
    <section class="carte" id="actualites">
        <h2 class="titre-section">Actualités de l'Université</h2>

        <div class="actualites-container">

            <article class="actualite-card">
                <img
                    src="<?php echo e(asset('images/actualites/actualite1.jpg')); ?>"
                    alt="Bâtiments de l'Université de Moundou"
                >

                <div class="actualite-contenu">
                    <h3>Les bâtiments de l'Université de Moundou</h3>

                    <p>
                        Découvrez les informations sur les infrastructures
                        de l'université.
                    </p>

                    <a
                        href="https://flashtchad.com/les-batiments-de-luniversite-de-moundou-sont-prets/"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Lire l'article →
                    </a>
                </div>
            </article>

            <article class="actualite-card">
                <img
                    src="https://journaldutchad.com/wp-content/uploads/2023/10/385517123_816386960495436_848112190781811688_n-780x440.jpg"
                    alt="Rentrée universitaire"
                >

                <div class="actualite-contenu">
                    <h3>Rentrée académique</h3>

                    <p>
                        Retrouvez les informations sur la rentrée
                        académique à l'Université de Moundou.
                    </p>

                    <a
                        href="https://journaldutchad.com/tchad-luniversite-de-moundou-lance-la-rentree-academique-2023-2024/"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Lire l'article →
                    </a>
                </div>
            </article>

            <article class="actualite-card">
                <img
                    src="<?php echo e(asset('images/actualites/actualite3.jpg')); ?>"
                    alt="Étudiants en géographie"
                >

                <div class="actualite-contenu">
                    <h3>Les étudiants en géographie</h3>

                    <p>
                        Découvrez une activité pédagogique autour
                        des richesses naturelles du Tchad.
                    </p>

                    <a
                        href="https://www.alwihdainfo.com/Tchad-Universite-de-Moundou-Les-etudiants-en-geographie-explorent-les-merveilles-du-lac-Lere_a139998.html"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Lire l'article →
                    </a>
                </div>
            </article>

        </div>
    </section>




    <!-- À PROPOS -->
    <section class="carte" id="apropos">
        <h2 class="titre-section">À propos de l'application</h2>

        <p><strong>Établissement :</strong> Université de Moundou</p>
        <p><strong>Projet :</strong> Gestion des étudiants</p>
        <p><strong>Framework :</strong> Laravel 13</p>
        <p><strong>Interface :</strong> HTML, CSS et Blade</p>
        <p><strong>Développeur :</strong> Ibin_nour</p>
    </section>

</main>


<footer class="pied-page">
    <div class="footer-contenu">

        <!-- LOGO ET UNIVERSITÉ -->
        <div class="footer-colonne footer-universite">
            <img src="<?php echo e(asset('images/logo-universite.png')); ?>"
                 alt="Logo de l'Université de Moundou"
                 class="footer-logo">

            <h3>Université de Moundou</h3>
            <p>Le savoir au service du développement.</p>
        </div>

        <!-- CONTACT -->
        <div class="footer-colonne">
            <h3>Contactez-nous</h3>
            <p>Université de Moundou, Tchad</p>
            <p>Email : contact@univ-moundou.td</p>
            <p>Téléphone : +235 XX XX XX XX</p>
        </div>

        <!-- RÉSEAUX SOCIAUX -->
        <div class="footer-colonne">
            <h3>Suivez-nous</h3>

            <div class="reseaux-sociaux">
                <a href="https://www.facebook.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="Facebook">f</a>

                <a href="https://www.instagram.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="Instagram">◎</a>

                <a href="https://x.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="Twitter ou X">𝕏</a>
            </div>
        </div>

    </div>

    <div class="footer-bas">
        <p>© <?php echo e(date('Y')); ?> Université de Moundou — Tous droits réservés.</p>
    </div>
</footer>


</body>
</html>
<?php /**PATH C:\Users\CCIT\mon-projet\resources\views/etudiants.blade.php ENDPATH**/ ?>