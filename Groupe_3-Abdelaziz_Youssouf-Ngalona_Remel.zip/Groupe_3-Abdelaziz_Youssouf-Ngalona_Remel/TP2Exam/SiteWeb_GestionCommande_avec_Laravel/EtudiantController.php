public function store(Request $request)
{
    // Affiche toutes les données reçues du formulaire et arrête le script
    dd($request->all());
}