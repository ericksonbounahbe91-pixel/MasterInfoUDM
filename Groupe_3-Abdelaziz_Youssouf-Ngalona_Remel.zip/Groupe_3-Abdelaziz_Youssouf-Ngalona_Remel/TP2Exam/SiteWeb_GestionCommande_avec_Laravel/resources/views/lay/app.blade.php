
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Université de Moundou')</title>

    <style>
        * { box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            color: #1e293b;
            background: #f4f7fb;
        }

        .entete {
            background: #1246a0;
            color: white;
            padding: 18px 5%;
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .logo {
            width: 78px;
            height: 78px;
            object-fit: contain;
            background: white;
            border-radius: 50%;
            padding: 5px;
        }

        .identite h1 {
            margin: 0 0 7px;
            font-size: 25px;
        }

        .identite p {
            margin: 0;
            font-size: 13px;
        }

        nav {
            background: white;
            padding: 17px 5%;
            display: flex;
            gap: 25px;
            flex-wrap: wrap;
            align-items: center;
            box-shadow: 0 3px 12px #0000000c;
        }

        nav a {
            color: #1246a0;
            text-decoration: none;
            font-weight: bold;
        }

        nav a:hover { color: #d18b19; }

        .gestion { margin-left: auto; }

        main {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .carte {
            background: white;
            padding: 26px;
            margin-bottom: 24px;
            border-radius: 12px;
            box-shadow: 0 5px 20px #0000000b;
        }

        h2 { color: #1246a0; }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
        }

        label {
            display: block;
            margin: 15px 0 7px;
            font-weight: bold;
        }

        button, .bouton {
            display: inline-block;
            padding: 12px 17px;
            border: none;
            border-radius: 7px;
            background: #1246a0;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .secondaire { background: #64748b; }
        .modifier { background: #0f766e; }
        .supprimer { background: #dc2626; }

        .message {
            padding: 14px;
            margin-bottom: 20px;
            border-radius: 7px;
            background: #dcfce7;
            color: #166534;
        }

        .erreurs {
            padding: 14px;
            background: #fee2e2;
            color: #991b1b;
        }

        .table-conteneur { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }

        th { background: #1246a0; color: white; }

        .actions { display: flex; gap: 7px; flex-wrap: wrap; }

        footer {
            background: #0c2f68;
            color: white;
            text-align: center;
            padding: 28px 15px;
            margin-top: 45px;
        }

        @media (max-width: 650px) {
            .entete { padding: 15px; gap: 12px; }
            .logo { width: 58px; height: 58px; }
            .identite h1 { font-size: 18px; }
            .identite p { font-size: 11px; }
            nav { gap: 15px; padding: 15px; }
            .gestion { margin-left: 0; }
        }


/* SECTION NOS FACULTÉS */
.formations-section {
    padding: 75px 7%;
    background: #f5f7fb;
}

.formations-entete {
    max-width: 760px;
    margin: 0 auto 45px;
    text-align: center;
}

.surtitre {
    display: inline-block;
    color: #1764b1;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 2px;
    margin-bottom: 12px;
}

.formations-entete h2,
.detail-faculte h2 {
    color: #102d50;
    font-size: clamp(28px, 4vw, 40px);
    margin: 0 0 16px;
}

.formations-entete p {
    color: #64748b;
    line-height: 1.8;
}

.facultes-grille {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 28px;
    max-width: 1200px;
    margin: auto;
}

.faculte-carte {
    background: #fff;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 8px 28px rgba(16, 45, 80, .08);
    transition: transform .25s, box-shadow .25s;
}

.faculte-carte:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 35px rgba(16, 45, 80, .14);
}

.faculte-image {
    height: 190px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #123c70, #2684c7);
}

.faculte-image > span {
    position: absolute;
    top: 16px;
    left: 20px;
    color: white;
    font-size: 14px;
    font-weight: bold;
    opacity: .85;
}

.faculte-icone {
    width: 85px;
    height: 85px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, .15);
    border: 1px solid rgba(255, 255, 255, .35);
    border-radius: 50%;
    font-size: 40px;
}

.image-droit {
    background: linear-gradient(135deg, #193653, #537b9d);
}

.image-lettres {
    background: linear-gradient(135deg, #59417d, #a17cc4);
}

.image-sciences {
    background: linear-gradient(135deg, #087f80, #38b6a4);
}

.faculte-contenu {
    padding: 26px;
}

.faculte-label {
    color: #1764b1;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1px;
}

.faculte-contenu h3 {
    color: #102d50;
    font-size: 21px;
    line-height: 1.45;
    margin: 12px 0;
}

.faculte-contenu p,
.detail-faculte p {
    color: #64748b;
    line-height: 1.8;
    font-size: 14px;
}

.faculte-lien {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    margin-top: 12px;
    color: #1764b1;
    font-weight: 700;
    text-decoration: none;
}

.faculte-lien:hover {
    color: #0b3c70;
}

.faculte-lien span {
    font-size: 20px;
}

.details-facultes {
    max-width: 1100px;
    margin: auto;
    padding: 45px 7%;
}

.detail-faculte {
    scroll-margin-top: 100px;
    padding: 35px 0;
    border-bottom: 1px solid #e2e8f0;
}

.detail-faculte h2 {
    font-size: 28px;
}

html {
    scroll-behavior: smooth;
    scroll-padding-top: 90px;
}

@media (max-width: 700px) {
    .formations-section {
        padding: 50px 5%;
    }

    .facultes-grille {
        grid-template-columns: 1fr;
    }

    .faculte-image {
        height: 160px;
    }

    .faculte-contenu {
        padding: 22px;
    }
}


/* BANNIÈRE VIDÉO DE L'UNIVERSITÉ */
.hero-universite {
    position: relative;
    min-height: 610px;
    display: flex;
    align-items: center;
    overflow: hidden;
    background: #092849;
    color: #fff;
    padding: 80px 8%;
}

.hero-video {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 0;
}

.hero-overlay {
    position: absolute;
    inset: 0;
    z-index: 1;
    background: linear-gradient(
        90deg,
        rgba(4, 27, 55, .94) 0%,
        rgba(7, 44, 83, .76) 55%,
        rgba(7, 44, 83, .30) 100%
    );
}

.hero-contenu {
    position: relative;
    z-index: 2;
    max-width: 850px;
    animation: apparitionHero 1.1s ease-out;
}

.hero-badge {
    display: inline-block;
    padding: 9px 15px;
    margin-bottom: 20px;
    border: 1px solid rgba(255, 255, 255, .55);
    border-radius: 30px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 2px;
}

.hero-contenu h1 {
    color: #fff;
    font-size: clamp(32px, 5vw, 58px);
    line-height: 1.15;
    font-weight: 800;
    margin: 0 0 22px;
}

.hero-contenu h2 {
    color: #dcecff;
    font-size: clamp(19px, 2.5vw, 27px);
    line-height: 1.5;
    margin: 0 0 18px;
}

.hero-contenu p {
    max-width: 650px;
    color: #edf4ff;
    font-size: 16px;
    line-height: 1.9;
    margin-bottom: 30px;
}

.hero-boutons {
    display: flex;
    flex-wrap: wrap;
    gap: 14px;
}

.btn-hero {
    display: inline-block;
    padding: 15px 23px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 700;
    transition: .25s ease;
}

.btn-principal {
    background: #fff;
    color: #104d8a;
}

.btn-principal:hover {
    background: #dcecff;
    transform: translateY(-3px);
}

.btn-secondaire {
    color: #fff;
    border: 1px solid rgba(255, 255, 255, .8);
    background: rgba(255, 255, 255, .08);
}

.btn-secondaire:hover {
    background: rgba(255, 255, 255, .2);
    transform: translateY(-3px);
}

.hero-indication {
    position: absolute;
    z-index: 2;
    right: 8%;
    bottom: 28px;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #fff;
    font-size: 12px;
}

.hero-indication span {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #7ee7c2;
    box-shadow: 0 0 12px #7ee7c2;
}

@keyframes apparitionHero {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 700px) {
    .hero-universite {
        min-height: 620px;
        padding: 65px 6%;
    }

    .hero-contenu p {
        font-size: 14px;
    }

    .hero-boutons {
        flex-direction: column;
        align-items: stretch;
    }

    .btn-hero {
        text-align: center;
    }

    .hero-indication {
        right: auto;
        left: 6%;
    }
}

@media (prefers-reduced-motion: reduce) {
    .hero-contenu {
        animation: none;
    }
}
    

/* EN-TÊTE : conserver le fond bleu original */
.entete-universite {
    background: #1246a0;
    color: white;
    padding: 18px 5%;
    min-height: 95px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
}

/* Logo et nom à gauche */
.identite-universite {
    display: flex;
    align-items: center;
    gap: 18px;
    color: white;
    text-decoration: none;
    flex-shrink: 0;
}

.identite-universite img {
    width: 78px;
    height: 78px;
    object-fit: contain;
    background: white;
    border-radius: 50%;
    padding: 5px;
}

.identite-universite span {
    font-size: 25px;
    font-weight: bold;
}

/* Menu à droite, dans le même fond bleu */
.menu-universite {
    background: transparent;
    padding: 10px 0;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 25px;
    flex-wrap: wrap;
    box-shadow: none;
}

.menu-universite a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    white-space: nowrap;
}

.menu-universite a:hover {
    color: #d18b19;
}

@media (max-width: 900px) {
    .entete-universite {
        flex-wrap: wrap;
    }

    .menu-universite {
        justify-content: flex-start;
        gap: 15px;
    }
}

@media (max-width: 650px) {
    .identite-universite img {
        width: 58px;
        height: 58px;
    }

    .identite-universite span {
        font-size: 18px;
    }
}


    .menu-universite {
        justify-content: center;
    }

/* SECTION ACTUALITÉS */
.actualites-section {
    padding: 65px 5%;
    background: #f4f7fb;
}

.actualites-entete {
    max-width: 760px;
    margin: 0 auto 40px;
    text-align: center;
}

.actualites-entete .surtitre {
    display: inline-block;
    color: #1764b1;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 2px;
    margin-bottom: 12px;
}

.actualites-entete h2 {
    color: #1246a0;
    font-size: clamp(26px, 4vw, 36px);
    margin: 0 0 16px;
}

.actualites-entete p {
    color: #64748b;
    line-height: 1.8;
}

.actualites-grille {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 25px;
    max-width: 1200px;
    margin: 0 auto;
}

.actualite-carte {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(16, 45, 80, .08);
    transition: transform .25s ease, box-shadow .25s ease;
}

.actualite-carte:hover {
    transform: translateY(-5px);
    box-shadow: 0 14px 30px rgba(16, 45, 80, .14);
}

.actualite-image {
    display: block;
    width: 100%;
    height: 220px;
    object-fit: cover;
}

.actualite-contenu {
    padding: 24px;
}

.actualite-date {
    color: #d18b19;
    font-size: 12px;
    font-weight: bold;
    margin-bottom: 10px;
}

.actualite-contenu h3 {
    color: #1246a0;
    font-size: 20px;
    line-height: 1.4;
    margin: 0 0 12px;
}

.actualite-contenu p {
    color: #64748b;
    font-size: 14px;
    line-height: 1.8;
}

.actualite-lien {
    display: inline-block;
    margin-top: 10px;
    color: #1246a0;
    font-weight: bold;
    text-decoration: none;
}

.actualite-lien:hover {
    color: #d18b19;
}

@media (max-width: 900px) {
    .actualites-grille {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 600px) {
    .actualites-section {
        padding: 45px 5%;
    }

    .actualites-grille {
        grid-template-columns: 1fr;
    }

    .actualite-image {
        height: 210px;
    }

    .actualite-contenu {
        padding: 20px;
    }
}

    </style>
    
</head>

<body>


<header class="entete-universite">
    <a href="{{ route('accueil') }}" class="identite-universite">
        <img
            src="{{ asset('images/logo-universite.png') }}"
            alt="Logo de l'Université de Moundou"
        >
        <span>UNIVERSITÉ DE MOUNDOU</span>
    </a>

    <nav class="menu-universite">
        <a href="{{ route('accueil') }}">Accueil</a>
        <a href="{{ route('accueil') }}#president">Mot du Président</a>
        <a href="{{ route('accueil') }}#actualites">Actualités</a>
        <a href="{{ route('formations') }}">Nos formations</a>
    </nav>
</header>


    




    <main>
        @if(session('success'))
            <div class="message">{{ session('success') }}</div>
        @endif

        @if($errors->any())
            <div class="erreurs">
                <strong>Veuillez corriger les erreurs :</strong>
                <ul>
                    @foreach($errors->all() as $erreur)
                        <li>{{ $erreur }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @yield('content')
    </main>

    <footer>
        <strong>Université de Moundou</strong>
        <p>Enseignement supérieur et formation</p>
        <small>© {{ date('Y') }} — Tous droits réservés</small>
    </footer>

</body>
</html>