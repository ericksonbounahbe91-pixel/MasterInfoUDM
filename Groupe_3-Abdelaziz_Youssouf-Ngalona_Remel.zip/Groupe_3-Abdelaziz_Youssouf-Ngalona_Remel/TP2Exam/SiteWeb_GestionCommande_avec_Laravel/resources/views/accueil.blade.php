
@extends('layouts.app')

@section('title', 'Accueil - Université de Moundou')

@section('content')

<style>
    .hero {
        background: linear-gradient(120deg, #0c2f68, #2163bd);
        color: white;
        padding: 65px 35px;
        border-radius: 16px;
        margin-bottom: 30px;
    }

    .hero h2 {
        color: white;
        font-size: 36px;
        max-width: 700px;
        line-height: 1.2;
    }

    .hero p {
        font-size: 17px;
        line-height: 1.8;
        max-width: 700px;
    }

    .hero .bouton {
        background: white;
        color: #1246a0;
        margin-top: 12px;
        font-weight: bold;
    }

    .grille {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
    }

    .formation {
        border: 1px solid #e2e8f0;
        padding: 22px;
        border-radius: 12px;
        background: white;
    }

    .formation h3 { color: #1246a0; }

    .section-texte {
        line-height: 1.9;
        color: #475569;
    }

    .video {
        width: 100%;
        aspect-ratio: 16 / 9;
        border: 0;
        border-radius: 12px;
        background: #0c2f68;
    }

    .president {
        border-left: 5px solid #d6a243;
        padding-left: 22px;
    }
</style>




<section class="hero-universite">

    <video class="hero-video" autoplay muted loop playsinline>
        <source src="{{ asset('videos/campus-universite.mp4') }}"
                type="video/mp4">
        Votre navigateur ne prend pas en charge les vidéos.
    </video>

    <div class="hero-overlay"></div>

    <div class="hero-contenu">
        <span class="hero-badge">UNIVERSITÉ DE MOUNDOU</span>

        <h1>BIENVENUE À L'UNIVERSITÉ DE MOUNDOU</h1>

        <h2>
            Le savoir, la pratique et l'innovation
            au service de l'avenir
        </h2>

        <p>
            Découvrez notre université, ses formations,
            ses activités pédagogiques et son engagement
            en faveur de l'enseignement supérieur.
        </p>

        <div class="hero-boutons">
            <a href="{{ route('formations') }}" class="btn-hero btn-principal">
                Découvrir nos formations →
            </a>

            <a href="#universite" class="btn-hero btn-secondaire">
                Découvrir l'université
            </a>
        </div>
    </div>

    <div class="hero-indication">
        <span></span>
        Découvrez notre université
    </div>

</section>


<section class="carte" id="universite">
    <h2>Notre université</h2>

    <div class="section-texte">
        <p>
            L'Université de Moundou est un établissement d'enseignement
            supérieur situé au Tchad. Cette rubrique présente son histoire,
            ses missions, ses composantes et ses activités.
        </p>

        <p>
            <strong>À compléter :</strong> ajoute ici la date de création,
            les facultés ou instituts, les laboratoires, les services
            universitaires et les informations officielles sur l'université.
        </p>
    </div>
</section>

<section class="carte" id="president">
    <h2>Mot du Président de l'université</h2>

    <div class="president section-texte">
        <p><em>
            Texte de présentation à remplacer par le message officiel
            du Président de l'Université.
        </em></p>

        <p>
            Cet espace permettra au Président de présenter la vision de
            l'établissement, ses priorités en matière de formation,
            de recherche et d'accompagnement des étudiants.
        </p>

        <p><strong>Le Président de l'Université</strong></p>
    </div>
</section>

<section id="actualites" class="actualites-section">
    <div class="actualites-entete">
        <span class="actualites-surtitre">RESTEZ INFORMÉS</span>
        <h2>Actualités de l'Université</h2>
        <p>
            Retrouvez les dernières nouvelles, les activités pédagogiques
            et les événements de l'Université de Moundou.
        </p>
    </div>

    <div class="actualites-grille">

        <!-- Actualité 1 -->
        <article class="actualite-carte">
            <img
                src="{{ asset('images/actualites/actualite1.jpg') }}"
                alt="Activité universitaire"
                class="actualite-image"
            >
            <div class="actualite-contenu">
                <span class="actualite-date">À renseigner</span>
                <h3>Vie universitaire</h3>
                <p>
                    Retrouvez ici les informations sur les activités
                    et les événements organisés à l'université.
                </p>
                <a href="#actualites">En savoir plus →</a>
            </div>
        </article>

        <!-- Actualité 2 -->
        <article class="actualite-carte">
            <img
                src="{{ asset('images/actualites/actualite2.jpg') }}"
                alt="Séance de travaux pratiques"
                class="actualite-image"
            >
            <div class="actualite-contenu">
                <span class="actualite-date">À renseigner</span>
                <h3>Activités pédagogiques</h3>
                <p>
                    Découvrez les séances de travaux pratiques,
                    les projets et les activités des étudiants.
                </p>
                <a href="#actualites">En savoir plus →</a>
            </div>
        </article>
        
        <!-- Actualité 3 -->
        <article class="actualite-carte">
            <img
                src="{{ asset('images/actualites/actualite3.jpg') }}"
                alt="Rencontre universitaire"
                class="actualite-image"
            >
            <div class="actualite-contenu">
                <span class="actualite-date">À renseigner</span>
                <h3>Conférences et rencontres</h3>
                <p>
                    Consultez les annonces des conférences,
                    des rencontres et des manifestations universitaires.
                </p>
                <a href="#actualites">En savoir plus →</a>
            </div>
        </article>

    </div>
</section>






<section class="carte" id="video">
    <h2>La formation pratique en vidéo</h2>

    <p class="section-texte">
        Découvrez les séances de travaux pratiques, les laboratoires,
        les équipements et les activités pédagogiques des étudiants.
    </p>

    <iframe
        class="video"
        src="https://www.youtube.com/embed/REMPLACER_PAR_ID_VIDEO"
        title="Travaux pratiques à l'université"
        allowfullscreen
        loading="lazy">
    </iframe>

    <p>
        <small>
            Remplace le lien de démonstration par celui d'une vidéo
            réelle de l'université.
        </small>
    </p>
</section>

<section class="carte">
    <h2>Espace de gestion des étudiants</h2>

    <p class="section-texte">
        Accédez à l'outil de gestion des inscriptions et des informations
        des étudiants.
    </p>

    <a class="bouton" href="{{ route('etudiants.index') }}">
        Accéder à la gestion des étudiants
    </a>
</section>

@endsection
