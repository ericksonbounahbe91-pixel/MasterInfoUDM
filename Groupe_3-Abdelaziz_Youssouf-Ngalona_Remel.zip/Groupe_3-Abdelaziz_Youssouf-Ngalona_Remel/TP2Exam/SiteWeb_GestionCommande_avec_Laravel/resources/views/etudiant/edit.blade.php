@extends('layouts.app')

@section('title', 'Modifier un étudiant')

@section('content')
<section class="carte">
    <h2>Modifier l'étudiant n°{{ $etudiant->id }}</h2>

    <form action="{{ route('etudiants.update', $etudiant) }}"
          method="POST">

        @csrf
        @method('PUT')

        <label for="nom">Nom</label>
        <input id="nom" name="nom" type="text"
               value="{{ old('nom', $etudiant->nom) }}" required>

        <label for="prenom">Prénom</label>
        <input id="prenom" name="prenom" type="text"
               value="{{ old('prenom', $etudiant->prenom) }}" required>

        <label for="email">Adresse e-mail</label>
        <input id="email" name="email" type="email"
               value="{{ old('email', $etudiant->email) }}" required>

        <br><br>
        <button type="submit">Enregistrer les modifications</button>

        <a class="bouton secondaire"
           href="{{ route('etudiants.index') }}">
            Retour à la liste
        </a>
    </form>
</section>
@endsection