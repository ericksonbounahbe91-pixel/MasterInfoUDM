@extends('layouts.app')

@section('title', 'Liste des étudiants')

@section('content')
<section class="carte">
    <h2>Liste des étudiants</h2>

    <form action="{{ route('etudiants.index') }}"
          method="GET" class="recherche">

        <div class="champ">
            <label for="search">Rechercher par nom</label>
            <input type="text" id="search" name="search"
                   value="{{ $recherche }}"
                   placeholder="Saisir le nom recherché...">
        </div>

        <button type="submit">Rechercher</button>

        <a class="bouton secondaire"
           href="{{ route('etudiants.index') }}">
            Réinitialiser
        </a>
    </form>

    <p>Nombre de résultats : {{ $etudiants->count() }}</p>

    <div class="table-conteneur">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>E-mail</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                @forelse($etudiants as $etudiant)
                    <tr>
                        <td>{{ $etudiant->id }}</td>
                        <td>{{ $etudiant->nom }}</td>
                        <td>{{ $etudiant->prenom }}</td>
                        <td>{{ $etudiant->email }}</td>

                        <td>
                            <div class="actions">
                                <a class="bouton modifier"
                                   href="{{ route('etudiants.edit', $etudiant) }}">
                                    Modifier
                                </a>

                                <form
                                    action="{{ route('etudiants.destroy', $etudiant) }}"
                                    method="POST"
                                    onsubmit="return confirm('Voulez-vous vraiment supprimer cet étudiant ?')">

                                    @csrf
                                    @method('DELETE')

                                    <button type="submit" class="supprimer">
                                        Supprimer
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5">
                            Aucun étudiant trouvé.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</section>
@endsection