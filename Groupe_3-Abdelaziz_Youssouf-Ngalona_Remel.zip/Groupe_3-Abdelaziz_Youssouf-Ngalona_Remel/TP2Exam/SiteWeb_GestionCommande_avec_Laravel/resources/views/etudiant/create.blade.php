@extends('layouts.app')

@section('title', 'Ajouter un étudiant')

@section('content')
<section class="carte">
    <h2>Ajouter un étudiant</h2>

    <form action="{{ route('etudiants.store') }}" method="POST">
        @csrf

        <label for="nom">Nom</label>
        <input id="nom" name="nom" type="text"
               value="{{ old('nom') }}" required>

        <label for="prenom">Prénom</label>
        <input id="prenom" name="prenom" type="text"
               value="{{ old('prenom') }}" required>

        <label for="email">Adresse e-mail</label>
        <input id="email" name="email" type="email"
               value="{{ old('email') }}" required>

        <br><br>
        <button type="submit">Enregistrer</button>

        <a class="bouton secondaire"
           href="{{ route('etudiants.index') }}">
            Annuler
        </a>
    </form>
</section>
@endsection