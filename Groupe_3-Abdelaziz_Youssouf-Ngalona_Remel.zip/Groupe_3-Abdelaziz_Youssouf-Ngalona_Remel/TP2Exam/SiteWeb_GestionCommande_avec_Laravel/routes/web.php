<?php

use App\Http\Controllers\Admin\AdminController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\AuthController;

// Page d'accueil
Route::get('/', [EtudiantController::class, 'accueil'])
    ->name('accueil');

// Page des formations
Route::view('/formations', 'formations')
    ->name('formations');

// Page des informations de l'université
Route::view('/informations', 'formations')
    ->name('informations');

// Gestion des étudiants
Route::resource('etudiants', EtudiantController::class)
    ->except(['show']);

// Inscription
Route::get('/inscription', [AuthController::class, 'showInscription'])
    ->name('inscription');

Route::post('/inscription', [AuthController::class, 'inscription'])
    ->name('inscription.store');

// Connexion
Route::get('/connexion', [AuthController::class, 'showConnexion'])
    ->name('connexion');

Route::post('/connexion', [AuthController::class, 'connexion'])
    ->name('connexion.store');

// Espace étudiant réservé aux utilisateurs connectés
Route::middleware('auth')->group(function () {
    Route::get('/espace-etudiant', [AuthController::class, 'dashboard'])
        ->name('etudiant.dashboard');

    Route::post('/deconnexion', [AuthController::class, 'deconnexion'])
        ->name('deconnexion');
});

Route::middleware(['auth', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/', [AdminController::class, 'index'])
            ->name('index');

        Route::patch('/utilisateurs/{user}/approuver', [
            AdminController::class,
            'approuver'
        ])->name('approuver');

        Route::patch('/utilisateurs/{user}/refuser', [
            AdminController::class,
            'refuser'
        ])->name('refuser');
    });
