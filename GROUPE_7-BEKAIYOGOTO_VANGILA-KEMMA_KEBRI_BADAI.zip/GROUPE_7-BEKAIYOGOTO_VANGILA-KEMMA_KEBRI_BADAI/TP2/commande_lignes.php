<?php
require_once 'config.php';
$titre = 'Produits de la commande'; $page = 'commandes';

$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT c.idCmd, c.dateCmd, cl.nomCli, cl.prenomCli
                     FROM commande c JOIN client cl ON cl.idCli = c.idCli WHERE c.idCmd = ?');
$st->execute([$id]);
$cmd = $st->fetch();
if (!$cmd) { http_response_code(404); exit('Commande introuvable.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? '';
    try {
        $pdo->beginTransaction();

        if ($action === 'add') {                       // 1) Enregistrer des produits dans la commande
            $prods = $_POST['idProd'] ?? [];
            $qtes  = $_POST['qteCmd'] ?? [];
            $n = 0;
            foreach ($prods as $i => $idP) {
                $idP = (int)$idP;
                $q   = (int)($qtes[$i] ?? 0);
                if ($idP <= 0 || $q <= 0) continue;
                $s = $pdo->prepare('SELECT designProd, qteStock FROM produit WHERE idProd = ? FOR UPDATE');
                $s->execute([$idP]);
                $p = $s->fetch();
                if (!$p) throw new RuntimeException('Produit introuvable.');
                if ($p['qteStock'] < $q) {
                    throw new RuntimeException("Stock insuffisant pour « {$p['designProd']} » (disponible : {$p['qteStock']}).");
                }
                $pdo->prepare('INSERT INTO lignecommande (idCmd, idProd, qteCmd) VALUES (?, ?, ?)
                               ON DUPLICATE KEY UPDATE qteCmd = qteCmd + VALUES(qteCmd)')
                    ->execute([$id, $idP, $q]);
                $pdo->prepare('UPDATE produit SET qteStock = qteStock - ? WHERE idProd = ?')->execute([$q, $idP]);
                $n++;
            }
            if ($n === 0) throw new RuntimeException('Choisissez au moins un produit avec une quantité.');
            $pdo->commit();
            flash('success', $n . ' produit(s) enregistré(s) dans la commande.');

        } elseif ($action === 'delete') {              // 4) Supprimer un produit d'une commande
            $idP = (int)($_POST['idProd'] ?? 0);
            $s = $pdo->prepare('SELECT qteCmd FROM lignecommande WHERE idCmd = ? AND idProd = ? FOR UPDATE');
            $s->execute([$id, $idP]);
            $l = $s->fetch();
            if (!$l) throw new RuntimeException('Cette ligne n\'existe plus.');
            $pdo->prepare('DELETE FROM lignecommande WHERE idCmd = ? AND idProd = ?')->execute([$id, $idP]);
            $pdo->prepare('UPDATE produit SET qteStock = qteStock + ? WHERE idProd = ?')->execute([$l['qteCmd'], $idP]);
            $pdo->commit();
            flash('success', 'Produit retiré de la commande. Le stock a été remis à jour.');
        } else {
            throw new RuntimeException('Action inconnue.');
        }
    } catch (RuntimeException $e) {
        $pdo->rollBack();
        flash('error', $e->getMessage());
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', 'Erreur de base de données. Réessayez.');
    }
    header('Location: commande_lignes.php?id=' . $id); exit;
}

$st = $pdo->prepare('SELECT p.idProd, p.designProd, p.prixUProd, p.photoProd, l.qteCmd, (l.qteCmd * p.prixUProd) AS sousTotal
                     FROM lignecommande l JOIN produit p ON p.idProd = l.idProd
                     WHERE l.idCmd = ? ORDER BY p.designProd');
$st->execute([$id]);
$lignes = $st->fetchAll();
$total  = array_sum(array_column($lignes, 'sousTotal'));
$produits = $pdo->query('SELECT idProd, designProd, qteStock, prixUProd, photoProd FROM produit ORDER BY designProd')->fetchAll();
require 'header.php';
?>
<p><a class="back" href="commandes.php"><?= icon('back') ?> Toutes les commandes</a></p>
<div class="page-head">
  <div>
    <h1>Commande #<?= (int)$cmd['idCmd'] ?></h1>
    <p class="muted"><?= h($cmd['nomCli'] . ' ' . $cmd['prenomCli']) ?> · <?= date_fr($cmd['dateCmd']) ?></p>
  </div>
  <div class="total-box"><span>Total</span><strong><?= money($total) ?></strong></div>
</div>

<h2>Produits de la commande</h2>
<?php if (!$lignes): ?>
  <p class="empty">Cette commande est vide. Ajoutez des produits avec le formulaire ci-dessous.</p>
<?php else: ?>
<div class="table-wrap"><table>
  <thead><tr><th>Produit</th><th class="num">Prix unitaire</th><th class="num">Quantité</th><th class="num">Sous-total</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($lignes as $l): ?>
    <tr>
      <td><div class="who"><?= photo_tag($l['photoProd'], $l['designProd'], 'thumb') ?><strong><?= h($l['designProd']) ?></strong></div></td>
      <td class="num"><?= money($l['prixUProd']) ?></td>
      <td class="num"><?= (int)$l['qteCmd'] ?></td>
      <td class="num"><strong><?= money($l['sousTotal']) ?></strong></td>
      <td class="actions">
        <form method="post" onsubmit="return confirm('Retirer « <?= h(addslashes($l['designProd'])) ?> » de cette commande ?');">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="idProd" value="<?= (int)$l['idProd'] ?>">
          <button class="btn small danger"><?= icon('trash') ?> Retirer</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot><tr><th colspan="3">Total</th><th class="num"><?= money($total) ?></th><th></th></tr></tfoot>
</table></div>
<?php endif; ?>

<h2>Ajouter des produits</h2>
<form method="post" class="card" id="formLignes">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="add">
  <div id="lignes">
    <div class="ligne">
      <div class="ligne-img"><span class="thumb ph" style="--h:210">?</span></div>
      <label>Produit
        <select name="idProd[]">
          <option value="">Choisir un produit</option>
          <?php foreach ($produits as $p): ?>
            <option value="<?= (int)$p['idProd'] ?>" data-img="<?= h(photo_url($p['photoProd']) ?? '') ?>" <?= $p['qteStock'] == 0 ? 'disabled' : '' ?>>
              <?= h($p['designProd']) ?> (<?= money($p['prixUProd']) ?>, stock : <?= (int)$p['qteStock'] ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Quantité
        <input type="number" name="qteCmd[]" min="1" step="1" placeholder="1">
      </label>
    </div>
  </div>
  <div class="actions">
    <button type="button" class="btn" id="addLigne"><?= icon('plus') ?> Ajouter une ligne</button>
    <button class="btn primary">Enregistrer dans la commande</button>
  </div>
</form>
<script>
const zone = document.getElementById('lignes');
function majApercu(ligne) {
  const opt = ligne.querySelector('select').selectedOptions[0];
  const box = ligne.querySelector('.ligne-img');
  box.innerHTML = '';
  if (opt && opt.dataset.img) {
    const img = document.createElement('img');
    img.className = 'thumb'; img.src = opt.dataset.img; img.alt = '';
    box.appendChild(img);
  } else {
    box.innerHTML = '<span class="thumb ph" style="--h:210">?</span>';
  }
}
zone.addEventListener('change', e => { if (e.target.matches('select')) majApercu(e.target.closest('.ligne')); });
document.getElementById('addLigne').addEventListener('click', () => {
  const copie = zone.firstElementChild.cloneNode(true);
  copie.querySelector('select').value = '';
  copie.querySelector('input').value = '';
  majApercu(copie);
  zone.appendChild(copie);
});
</script>
<?php require 'footer.php'; ?>
