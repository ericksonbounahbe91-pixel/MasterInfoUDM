<?php
require_once 'config.php';
$titre = 'Commandes'; $page = 'commandes';

// Création d'une commande (étape préalable au formulaire d'enregistrement des produits)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $idCli = (int)($_POST['idCli'] ?? 0);
    $date  = $_POST['dateCmd'] ?? '';
    $d = DateTime::createFromFormat('Y-m-d', $date);
    if ($idCli > 0 && $d && $d->format('Y-m-d') === $date) {
        $pdo->prepare('INSERT INTO commande (dateCmd, idCli) VALUES (?, ?)')->execute([$date, $idCli]);
        flash('success', 'Commande créée. Ajoutez maintenant ses produits.');
        header('Location: commande_lignes.php?id=' . $pdo->lastInsertId()); exit;
    }
    flash('error', 'Choisissez un client et une date valide.');
    header('Location: commandes.php'); exit;
}

$commandes = $pdo->query(
    'SELECT c.idCmd, c.dateCmd, cl.nomCli, cl.prenomCli, COUNT(l.idProd) AS nbLignes,
            COALESCE(SUM(l.qteCmd * p.prixUProd), 0) AS total
     FROM commande c
     JOIN client cl ON cl.idCli = c.idCli
     LEFT JOIN lignecommande l ON l.idCmd = c.idCmd
     LEFT JOIN produit p ON p.idProd = l.idProd
     GROUP BY c.idCmd, c.dateCmd, cl.nomCli, cl.prenomCli
     ORDER BY c.dateCmd DESC, c.idCmd DESC'
)->fetchAll();
$clients = $pdo->query('SELECT idCli, nomCli, prenomCli FROM client ORDER BY nomCli, prenomCli')->fetchAll();
require 'header.php';
?>
<div class="page-head"><div><h1>Commandes</h1><p class="muted"><?= count($commandes) ?> commande(s)</p></div><a class="btn" href="clients.php"><?= icon('users') ?> Enregistrer un client</a></div>

<form method="post" class="card inline-form">
  <?= csrf_field() ?>
  <label>Client
    <select name="idCli" required>
      <option value="">Choisir un client</option>
      <?php foreach ($clients as $c): ?>
        <option value="<?= (int)$c['idCli'] ?>"><?= h($c['nomCli'] . ' ' . $c['prenomCli']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Date
    <input type="date" name="dateCmd" value="<?= date('Y-m-d') ?>" required>
  </label>
  <button class="btn primary"><?= icon('plus') ?> Nouvelle commande</button>
</form>

<?php if (!$commandes): ?>
  <p class="empty">Aucune commande. Créez la première avec le formulaire ci-dessus.</p>
<?php else: ?>
<div class="table-wrap"><table>
  <thead><tr><th>N°</th><th>Date</th><th>Client</th><th class="num">Produits</th><th class="num">Total</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($commandes as $c): ?>
    <tr>
      <td><strong>#<?= (int)$c['idCmd'] ?></strong></td>
      <td><?= date_fr($c['dateCmd']) ?></td>
      <td><div class="who"><?= photo_tag(null, $c['prenomCli'] . ' ' . $c['nomCli'], 'avatar sm') ?><?= h($c['nomCli'] . ' ' . $c['prenomCli']) ?></div></td>
      <td class="num"><?= (int)$c['nbLignes'] ?></td>
      <td class="num"><strong><?= money($c['total']) ?></strong></td>
      <td class="actions"><a class="btn small" href="commande_lignes.php?id=<?= (int)$c['idCmd'] ?>">Gérer les produits</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<?php require 'footer.php'; ?>
