<?php
require_once 'config.php';
$titre = 'Modifier un produit'; $page = 'produits';
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM produit WHERE idProd = ?');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) { http_response_code(404); exit('Produit introuvable.'); }

$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $design = trim($_POST['designProd'] ?? '');
    $stock  = filter_var($_POST['qteStock'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    $prix   = filter_var($_POST['prixUProd'] ?? '', FILTER_VALIDATE_FLOAT);
    try {
        if ($design === '')              throw new RuntimeException('La désignation est obligatoire.');
        if ($stock === false)            throw new RuntimeException('Le stock doit être un entier positif ou nul.');
        if ($prix === false || $prix < 0) throw new RuntimeException('Le prix doit être un nombre positif ou nul.');
        $photo = upload_photo('photoProd') ?? $p['photoProd'];
        $pdo->prepare('UPDATE produit SET designProd=?, qteStock=?, prixUProd=?, photoProd=? WHERE idProd=?')
            ->execute([$design, $stock, $prix, $photo, $id]);
        if ($photo !== $p['photoProd']) delete_upload($p['photoProd']);   // supprime l'ancienne photo téléversée
        flash('success', 'Produit modifié.');
        header('Location: produits.php'); exit;
    } catch (RuntimeException $e) {
        $erreur = $e->getMessage();
        $p = array_merge($p, ['designProd' => $design, 'qteStock' => $_POST['qteStock'] ?? '', 'prixUProd' => $_POST['prixUProd'] ?? '']);
    }
}
require 'header.php';
?>
<p><a class="back" href="produits.php"><?= icon('back') ?> Retour aux produits</a></p>
<h1>Modifier « <?= h($p['designProd']) ?> »</h1>
<?php if ($erreur): ?><div class="flash error" role="alert"><?= h($erreur) ?></div><?php endif; ?>
<div class="edit-layout">
  <form method="post" enctype="multipart/form-data" class="card form">
    <?= csrf_field() ?>
    <label>Désignation
      <input name="designProd" value="<?= h($p['designProd']) ?>" required maxlength="150">
    </label>
    <div class="row2">
      <label>Quantité en stock
        <input type="number" name="qteStock" min="0" step="1" value="<?= h($p['qteStock']) ?>" required>
      </label>
      <label>Prix unitaire (<?= DEVISE ?>)
        <input type="number" name="prixUProd" min="0" step="0.01" value="<?= h($p['prixUProd']) ?>" required>
      </label>
    </div>
    <label>Nouvelle photo (JPG, PNG ou WebP, 2 Mo max)
      <input type="file" name="photoProd" id="photoInput" accept="image/jpeg,image/png,image/webp">
    </label>
    <div class="actions">
      <button class="btn primary">Enregistrer les modifications</button>
      <a class="btn" href="produits.php">Annuler</a>
    </div>
  </form>
  <aside class="card preview">
    <h2>Aperçu</h2>
    <div class="preview-img" id="previewBox"><?= photo_tag($p['photoProd'], $p['designProd'], 'cover') ?></div>
    <p class="muted small-text">L'image choisie s'affiche ici avant l'enregistrement.</p>
  </aside>
</div>
<script>
document.getElementById('photoInput').addEventListener('change', e => {
  const f = e.target.files[0];
  if (!f) return;
  const box = document.getElementById('previewBox');
  box.innerHTML = '';
  const img = document.createElement('img');
  img.className = 'cover'; img.alt = 'Aperçu'; img.src = URL.createObjectURL(f);
  box.appendChild(img);
});
</script>
<?php require 'footer.php'; ?>
