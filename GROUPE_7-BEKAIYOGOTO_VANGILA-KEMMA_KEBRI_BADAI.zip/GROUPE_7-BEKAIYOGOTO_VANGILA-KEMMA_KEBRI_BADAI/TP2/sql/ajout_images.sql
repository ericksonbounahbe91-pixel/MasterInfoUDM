-- À exécuter UNIQUEMENT si la base existe déjà (sans réimporter database.sql) :
-- associe chaque produit à son image fournie dans images/produits/.
USE gestion_commande;
UPDATE produit SET photoProd = 'images/produits/ordinateur-portable.svg' WHERE designProd = 'Ordinateur portable' AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/souris-sans-fil.svg'     WHERE designProd = 'Souris sans fil'     AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/clavier-mecanique.svg'   WHERE designProd = 'Clavier mécanique'   AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/ecran-24-pouces.svg'     WHERE designProd = 'Écran 24 pouces'     AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/imprimante-laser.svg'    WHERE designProd = 'Imprimante laser'    AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/cle-usb-64go.svg'        WHERE designProd = 'Clé USB 64 Go'       AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/casque-audio.svg'        WHERE designProd = 'Casque audio'        AND photoProd IS NULL;
UPDATE produit SET photoProd = 'images/produits/webcam-hd.svg'           WHERE designProd = 'Webcam HD'           AND photoProd IS NULL;
