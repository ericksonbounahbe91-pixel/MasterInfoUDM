SET NAMES utf8mb4;
UPDATE region SET nomRegion = 'Abéché' WHERE idRegion = 3;
UPDATE region SET nomRegion = 'Laï' WHERE idRegion = 7;
SELECT idRegion, nomRegion, HEX(nomRegion) AS hexa FROM region ORDER BY idRegion;
