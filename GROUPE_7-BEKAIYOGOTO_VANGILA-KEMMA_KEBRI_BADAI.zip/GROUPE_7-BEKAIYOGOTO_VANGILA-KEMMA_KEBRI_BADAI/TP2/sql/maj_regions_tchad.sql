-- ============================================================
-- Migration : remplacer les régions du Cameroun par celles du Tchad
-- À exécuter une seule fois sur une base déjà importée.
-- phpMyAdmin > Importer > ce fichier (base : gestion_commande)
-- ============================================================

USE gestion_commande;
SET NAMES utf8mb4;

-- 1) S'assurer qu'un département « Tchad » existe (on conserve idDep = 1
--    pour ne pas casser les liaisons existantes)
INSERT INTO departement (idDep, nomDep)
    SELECT 1, 'Tchad' WHERE NOT EXISTS (SELECT 1 FROM departement WHERE idDep = 1);
UPDATE departement SET nomDep = 'Tchad' WHERE idDep = 1;

-- 2) Remettre les régions du Tchad
--    On réutilise idRegion 1..5 pour les régions déjà référencées par les clients,
--    puis on ajoute les nouvelles régions.
DELETE FROM region WHERE idRegion > 8;

INSERT INTO region (idRegion, nomRegion, idDep) VALUES (1, 'Djamena', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (2, 'Moundou', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (3, 'Abéché', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (4, 'Doba', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (5, 'Sarh', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (6, 'Bongor', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (7, 'Laï', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);
INSERT INTO region (idRegion, nomRegion, idDep) VALUES (8, 'Mongo', 1)
    ON DUPLICATE KEY UPDATE nomRegion = VALUES(nomRegion), idDep = VALUES(idDep);

-- 3) Supprimer les anciens départements (les régions pointent désormais vers idDep = 1)
DELETE FROM departement WHERE idDep <> 1;

-- 4) Vérification
SELECT r.idRegion, r.nomRegion, d.nomDep
FROM region r JOIN departement d ON d.idDep = r.idDep
ORDER BY r.idRegion;
