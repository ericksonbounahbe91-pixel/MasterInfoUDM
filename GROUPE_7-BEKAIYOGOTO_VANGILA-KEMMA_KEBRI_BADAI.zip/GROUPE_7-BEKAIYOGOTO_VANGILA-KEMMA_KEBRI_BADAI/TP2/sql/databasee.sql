-- =====================================================
--  TP Gestion d'une ligne de commande  (MySQL / MariaDB)
-- =====================================================
CREATE DATABASE IF NOT EXISTS gestion_commande CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_commande;

-- Compte applicatif fourni dans l'énoncé (à ignorer s'il existe déjà)
CREATE USER IF NOT EXISTS 'MasTMound2'@'localhost' IDENTIFIED BY 'MoundMasT2@2026';
GRANT SELECT, INSERT, UPDATE, DELETE ON gestion_commande.* TO 'MasTMound2'@'localhost';
FLUSH PRIVILEGES;

DROP TABLE IF EXISTS lignecommande;
DROP TABLE IF EXISTS commande;
DROP TABLE IF EXISTS client;
DROP TABLE IF EXISTS produit;
DROP TABLE IF EXISTS region;
DROP TABLE IF EXISTS departement;

CREATE TABLE departement (
  idDep  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomDep VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE region (
  idRegion  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomRegion VARCHAR(100) NOT NULL,
  idDep     INT UNSIGNED NOT NULL,
  CONSTRAINT fk_region_dep FOREIGN KEY (idDep) REFERENCES departement(idDep)
) ENGINE=InnoDB;

CREATE TABLE client (
  idCli     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomCli    VARCHAR(80)  NOT NULL,
  prenomCli VARCHAR(80)  NOT NULL,
  email     VARCHAR(150) NOT NULL UNIQUE,
  photo     VARCHAR(255) NULL,
  idRegion  INT UNSIGNED NOT NULL,
  CONSTRAINT fk_client_region FOREIGN KEY (idRegion) REFERENCES region(idRegion)
) ENGINE=InnoDB;

CREATE TABLE produit (
  idProd     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  designProd VARCHAR(150) NOT NULL,
  qteStock   INT UNSIGNED NOT NULL DEFAULT 0,
  prixUProd  DECIMAL(10,2) NOT NULL CHECK (prixUProd >= 0),
  photoProd  VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE commande (
  idCmd   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  dateCmd DATE NOT NULL,
  idCli   INT UNSIGNED NOT NULL,
  CONSTRAINT fk_cmd_client FOREIGN KEY (idCli) REFERENCES client(idCli),
  INDEX idx_commande_date (dateCmd)          -- accélère les statistiques par période
) ENGINE=InnoDB;

CREATE TABLE lignecommande (
  idCmd   INT UNSIGNED NOT NULL,
  idProd  INT UNSIGNED NOT NULL,
  qteCmd  INT UNSIGNED NOT NULL CHECK (qteCmd > 0),
  PRIMARY KEY (idCmd, idProd),               -- un produit une seule fois par commande
  CONSTRAINT fk_ligne_cmd  FOREIGN KEY (idCmd)  REFERENCES commande(idCmd) ON DELETE CASCADE,
  CONSTRAINT fk_ligne_prod FOREIGN KEY (idProd) REFERENCES produit(idProd),
  INDEX idx_ligne_prod (idProd)              -- accélère les "top produits"
) ENGINE=InnoDB;

-- ---------- Jeu de données de test ----------
INSERT INTO departement (nomDep) VALUES ('Tchad');
INSERT INTO region (nomRegion, idDep) VALUES
 ('Djamena',1),('Moundou',1),('Abéché',1),('Doba',1),('Sarh',1),('Bongor',1),('Laï',1),('Mongo',1);
INSERT INTO client (nomCli,prenomCli,email,idRegion) VALUES
 ('Mballa','Jean','jean.mballa@mail.com',1),('Ndongo','Sarah','sarah.ndongo@mail.com',3),
 ('Fotso','Paul','paul.fotso@mail.com',5),('Kamga','Linda','linda.kamga@mail.com',1),
 ('Biya','Marc','marc.biya@mail.com',4),('Tchoua','Alice','alice.tchoua@mail.com',2),
 ('Essomba','David','david.essomba@mail.com',3),('Nkoulou','Rita','rita.nkoulou@mail.com',5);
INSERT INTO produit (designProd,qteStock,prixUProd,photoProd) VALUES
 ('Ordinateur portable',25,350000,'images/produits/ordinateur-portable.svg'),
 ('Souris sans fil',120,5000,'images/produits/souris-sans-fil.svg'),
 ('Clavier mécanique',60,18000,'images/produits/clavier-mecanique.svg'),
 ('Écran 24 pouces',30,85000,'images/produits/ecran-24-pouces.svg'),
 ('Imprimante laser',12,120000,'images/produits/imprimante-laser.svg'),
 ('Clé USB 64 Go',200,4500,'images/produits/cle-usb-64go.svg'),
 ('Casque audio',45,22000,'images/produits/casque-audio.svg'),
 ('Webcam HD',4,15000,'images/produits/webcam-hd.svg');
INSERT INTO commande (dateCmd,idCli) VALUES
 ('2026-01-12',1),('2026-01-25',2),('2026-02-03',3),('2026-02-18',1),('2026-03-07',4),('2026-03-21',5),
 ('2026-04-02',6),('2026-04-15',7),('2026-05-09',8),('2026-05-27',2),('2026-06-11',3),('2026-07-04',1),
 ('2026-08-19',4),('2026-09-08',5);
INSERT INTO lignecommande (idCmd,idProd,qteCmd) VALUES
 (1,1,1),(1,2,2),(2,3,1),(2,6,5),(3,4,2),(3,2,1),(4,5,1),(4,7,2),(5,1,2),(5,8,1),(6,6,10),(6,3,2),
 (7,2,4),(7,7,1),(8,4,1),(8,1,1),(9,5,1),(9,6,3),(10,7,3),(11,1,1),(11,4,1),(12,3,2),(12,2,3),(13,8,2),(14,1,2),(14,6,4);
