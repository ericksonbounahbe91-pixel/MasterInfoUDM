# TP Examen – Gestion d'une ligne de commande (PHP / MySQL)

## Installation
1. Copier le dossier dans `htdocs` (XAMPP/WAMP) ou `/var/www/html`.
2. Importer `sql/database.sql` (phpMyAdmin → Importer, ou `mysql -u root -p < sql/database.sql`).
   Le script crée la base `gestion_commande`, les tables, un jeu de test et l'utilisateur
   `MasTMound2` / `MoundMasT2@2026` (identifiants de l'énoncé, déjà saisis dans `config.php`).
3. Ouvrir `http://localhost/tp_commande/`.

> Sous Linux les noms de tables MySQL sont sensibles à la casse : les tables sont créées en minuscules
> (`lignecommande`, `departement`...).

## Nouveautés de cette version
- **Images des produits** : 8 illustrations vectorielles (`images/produits/*.svg`) déjà liées aux produits
  du jeu de test (colonne `photoProd`). Elles s'affichent dans le catalogue, les commandes, le tableau de bord
  et l'aperçu lors de l'ajout d'un produit à une commande.
- **Photo personnalisée** : depuis « Modifier un produit », une photo téléversée remplace l'image (aperçu avant envoi).
  Les images fournies ne sont jamais supprimées ; seules les photos téléversées le sont.
- **Nouveau design** : barre latérale, catalogue en cartes, indicateurs avec icônes, classement des produits
  avec barres, badges de stock (En stock / Stock faible / Rupture), avatars clients, responsive mobile.
- **Base déjà importée ?** Exécutez `sql/ajout_images.sql` au lieu de tout réimporter.
- PHP 8.0 ou plus requis (`str_starts_with`).

## Correspondance avec le sujet
| Question | Fichier |
|---|---|
| 1. Formulaire d'enregistrement des produits d'une commande | `commande_lignes.php?id=...` (plusieurs produits à la fois) |
| 2. Listes produits, commandes, clients | `produits.php`, `commandes.php`, `clients.php` |
| 3. Modifier un produit | `produit_modifier.php?id=...` |
| 4. Supprimer un produit d'une commande | bouton « Retirer » dans `commande_lignes.php` |
| 5. Tableau de bord + analyse de performance | `index.php` |

## Justification des choix du tableau de bord (question 5)
- **CA, nombre de commandes, panier moyen, clients** : les 4 chiffres qu'un gérant consulte en premier.
- **CA par mois** : montre la tendance et la saisonnalité des ventes.
- **Top 5 produits** : oriente les achats et le réapprovisionnement.
- **CA par département / région** : exploite les tables Region et Département pour repérer les zones fortes et faibles.
- **Top clients** : identifie les clients à fidéliser.
- **Stock faible** : évite les ruptures (seuil `SEUIL_STOCK` dans `config.php`).

## Analyse de performance
- Clés primaires et étrangères indexées ; index ajoutés sur `commande(dateCmd)` (stats par période)
  et `lignecommande(idProd)` (top produits).
- Requêtes préparées (PDO) : plan réutilisé et protection contre l'injection SQL.
- Agrégations faites en SQL (`SUM`, `GROUP BY`) et non en PHP : un seul aller-retour par indicateur.
- Le bloc « Analyse de performance » du tableau de bord affiche le temps de chaque requête.
  À présenter avec `EXPLAIN SELECT ...` pour montrer l'usage des index.
- Pistes pour un gros volume : table de synthèse mensuelle, cache des statistiques, pagination des listes.

## Sécurité et intégrité
- Requêtes préparées, échappement `htmlspecialchars`, jeton CSRF sur tous les formulaires POST.
- Ajout/suppression de ligne en **transaction** : le stock est décrémenté à l'ajout, remis à jour à la suppression,
  et une quantité supérieure au stock est refusée.
- Photos : JPG/PNG/WebP, 2 Mo max, type vérifié côté serveur.
