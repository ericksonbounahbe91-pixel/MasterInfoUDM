<?php
// ---------- Connexion (identifiants fournis dans l'énoncé) ----------
const DB_HOST = 'localhost';
const DB_NAME = 'gestion_commande';
const DB_USER = 'MasTMound2';
const DB_PASS = 'MoundMasT2@2026';
const DEVISE  = 'FCFA';      // à adapter
const SEUIL_STOCK = 5;       // stock considéré comme faible

session_start();

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Connexion à la base impossible. Vérifiez config.php et que sql/database.sql a été importé.');
}

// ---------- Fonctions utilitaires ----------
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n): string { return number_format((float)$n, 0, ',', ' ') . ' ' . DEVISE; }
function date_fr($d): string { return date('d/m/Y', strtotime($d)); }

function flash(string $type, string $msg): void { $_SESSION['flash'] = [$type, $msg]; }

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Session expirée. Rechargez la page et recommencez.');
    }
}

/** Téléverse une photo (JPG/PNG/WebP, 2 Mo max). Retourne le nom du fichier ou null si aucun fichier. */
function upload_photo(string $field): ?string {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK)  throw new RuntimeException('Échec du téléversement de la photo.');
    if ($f['size'] > 2 * 1024 * 1024)   throw new RuntimeException('Photo trop lourde (2 Mo maximum).');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) throw new RuntimeException('Format non accepté : utilisez JPG, PNG ou WebP.');
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) throw new RuntimeException('Impossible d\'enregistrer la photo.');
    return $name;
}

/** Exécute une requête et mesure son temps (affiché dans « Analyse de performance »). */
$PERF = [];
function timed(string $label, string $sql, array $params = []): array {
    global $pdo, $PERF;
    $t = microtime(true);
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $rows = $st->fetchAll();
    $PERF[] = ['label' => $label, 'ms' => (microtime(true) - $t) * 1000, 'rows' => count($rows)];
    return $rows;
}

/** URL d'une photo : image fournie avec le projet (images/...) ou fichier téléversé (uploads/...). */
function photo_url(?string $file): ?string {
    if (!$file) return null;
    $path = str_starts_with($file, 'images/') ? $file : 'uploads/' . $file;
    return is_file(__DIR__ . '/' . $path) ? $path : null;
}

/** Supprime une photo téléversée (jamais les images fournies avec le projet). */
function delete_upload(?string $file): void {
    if ($file && !str_starts_with($file, 'images/') && is_file(__DIR__ . '/uploads/' . $file)) {
        unlink(__DIR__ . '/uploads/' . $file);
    }
}

/** Vignette : photo si elle existe, sinon avatar avec initiale colorée. */
function photo_tag(?string $file, string $alt, string $class = 'thumb'): string {
    if ($url = photo_url($file)) {
        return '<img class="' . $class . '" src="' . h($url) . '" alt="' . h($alt) . '" loading="lazy">';
    }
    $hue = crc32($alt) % 360;
    return '<span class="' . $class . ' ph" style="--h:' . $hue . '" aria-hidden="true">' . h(mb_strtoupper(mb_substr($alt, 0, 1))) . '</span>';
}

/** Statut de stock : [classe CSS, libellé]. */
function stock_status(int $q): array {
    if ($q <= 0)            return ['out',  'Rupture'];
    if ($q <= SEUIL_STOCK)  return ['low',  'Stock faible'];
    return ['ok', 'En stock'];
}

/** Icônes SVG (style trait). */
function icon(string $name): string {
    $p = [
        'grid'   => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'cart'   => '<circle cx="9" cy="20" r="1.6"/><circle cx="18" cy="20" r="1.6"/><path d="M2 3h3l2.6 12.4a1.5 1.5 0 0 0 1.5 1.2h8.4a1.5 1.5 0 0 0 1.5-1.1L21 8H6"/>',
        'box'    => '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
        'users'  => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.3a6.5 6.5 0 0 1 3.5 5.7"/>',
        'wallet' => '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2z"/><circle cx="16.5" cy="14.5" r="1.2"/>',
        'receipt'=> '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
        'alert'  => '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4.5M12 17.5v.01"/>',
        'trend'  => '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
        'edit'   => '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/>',
        'plus'   => '<path d="M12 5v14M5 12h14"/>',
        'trash'  => '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
        'back'   => '<path d="m15 18-6-6 6-6"/>',
        'clock'  => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    ];
    return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($p[$name] ?? '') . '</svg>';
}
