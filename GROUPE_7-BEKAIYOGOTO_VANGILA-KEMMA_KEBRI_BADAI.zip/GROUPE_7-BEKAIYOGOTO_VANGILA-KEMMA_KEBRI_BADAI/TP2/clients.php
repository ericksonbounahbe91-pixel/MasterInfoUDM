<?php
require_once 'config.php';
$titre = 'Clients'; $page = 'clients';
$erreur = '';

// Enregistrement d'un client (y compris depuis la page des commandes)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $nom    = trim($_POST['nomCli'] ?? '');
    $prenom = trim($_POST['prenomCli'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $region = (int)($_POST['idRegion'] ?? 0);
    try {
        $pdo->beginTransaction();
        if ($nom === '')                          throw new RuntimeException('Le nom est obligatoire.');
        if ($prenom === '')                       throw new RuntimeException('Le prénom est obligatoire.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Adresse e-mail invalide.');
        if ($region <= 0)                         throw new RuntimeException('Choisissez une région.');

        $s = $pdo->prepare('SELECT idCli FROM client WHERE email = ?');
        $s->execute([$email]);
        if ($s->fetch()) throw new RuntimeException('Un client utilise déjà cette adresse e-mail.');

        $photo = upload_photo('photo');
        $pdo->prepare('INSERT INTO client (nomCli, prenomCli, email, photo, idRegion) VALUES (?, ?, ?, ?, ?)')
            ->execute([$nom, $prenom, $email, $photo, $region]);
        $pdo->commit();
        flash('success', 'Client « ' . $nom . ' ' . $prenom . ' » enregistré.');
        header('Location: clients.php'); exit;
    } catch (RuntimeException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $erreur = $e->getMessage();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $erreur = 'Erreur de base de données. Réessayez.';
    }
}

$clients = $pdo->query(
    'SELECT c.idCli, c.nomCli, c.prenomCli, c.email, c.photo, r.nomRegion, d.nomDep, COUNT(cm.idCmd) AS nbCmd
     FROM client c
     JOIN region r ON r.idRegion = c.idRegion
     JOIN departement d ON d.idDep = r.idDep
     LEFT JOIN commande cm ON cm.idCli = c.idCli
     GROUP BY c.idCli, c.nomCli, c.prenomCli, c.email, c.photo, r.nomRegion, d.nomDep
     ORDER BY c.nomCli, c.prenomCli'
)->fetchAll();
$regions = $pdo->query('SELECT r.idRegion, r.nomRegion, d.nomDep FROM region r JOIN departement d ON d.idDep = r.idDep ORDER BY d.nomDep, r.nomRegion')->fetchAll();
require 'header.php';
?>
<div class="page-head"><div><h1>Clients</h1><p class="muted"><?= count($clients) ?> client(s) enregistré(s)</p></div></div>

<?php if ($erreur): ?><div class="flash error" role="alert"><?= h($erreur) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card form">
  <?= csrf_field() ?>
  <h2 style="margin-top:0">Enregistrer un nouveau client</h2>
  <div class="row2">
    <label>Nom
      <input name="nomCli" value="<?= h($_POST['nomCli'] ?? '') ?>" required maxlength="80">
    </label>
    <label>Prénom
      <input name="prenomCli" value="<?= h($_POST['prenomCli'] ?? '') ?>" required maxlength="80">
    </label>
  </div>
  <label>E-mail
    <input type="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" required maxlength="150">
  </label>
  <label>Région
    <select name="idRegion" required>
      <option value="">Choisir une région</option>
      <?php foreach ($regions as $r): ?>
        <option value="<?= (int)$r['idRegion'] ?>" <?= (int)($_POST['idRegion'] ?? 0) === (int)$r['idRegion'] ? 'selected' : '' ?>>
          <?= h($r['nomRegion']) ?> — <?= h($r['nomDep']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Photo (JPG, PNG ou WebP, 2 Mo max)
    <input type="file" name="photo" accept="image/jpeg,image/png,image/webp">
  </label>
  <div class="actions">
    <button class="btn primary"><?= icon('plus') ?> Enregistrer le client</button>
  </div>
</form>
<?php if (!$clients): ?>
  <p class="empty">Aucun client enregistré.</p>
<?php else: ?>
<div class="table-wrap"><table>
  <thead><tr><th>Client</th><th>E-mail</th><th>Région</th><th>Département</th><th class="num">Commandes</th></tr></thead>
  <tbody>
  <?php foreach ($clients as $c): ?>
    <tr>
      <td><div class="who"><?= photo_tag($c['photo'], $c['prenomCli'] . ' ' . $c['nomCli'], 'avatar') ?><strong><?= h($c['nomCli'] . ' ' . $c['prenomCli']) ?></strong></div></td>
      <td class="muted"><?= h($c['email']) ?></td>
      <td><?= h($c['nomRegion']) ?></td>
      <td><span class="chip"><?= h($c['nomDep']) ?></span></td>
      <td class="num"><?= (int)$c['nbCmd'] ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<?php require 'footer.php'; ?>
