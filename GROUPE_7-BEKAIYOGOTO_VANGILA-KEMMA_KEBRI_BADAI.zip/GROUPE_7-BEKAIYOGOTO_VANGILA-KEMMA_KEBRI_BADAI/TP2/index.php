<?php
require_once 'config.php';
$titre = 'Tableau de bord'; $page = 'index';

$CA = 'SUM(l.qteCmd * p.prixUProd)';
$kpi = timed('Indicateurs globaux',
    "SELECT (SELECT COUNT(*) FROM commande) AS nbCmd,
            (SELECT COUNT(*) FROM client)   AS nbCli,
            (SELECT COALESCE(SUM(l.qteCmd * p.prixUProd), 0) FROM lignecommande l JOIN produit p ON p.idProd = l.idProd) AS ca,
            (SELECT COUNT(*) FROM produit WHERE qteStock <= ?) AS nbFaible", [SEUIL_STOCK])[0];
$panier = $kpi['nbCmd'] > 0 ? $kpi['ca'] / $kpi['nbCmd'] : 0;

$parMois = timed('Chiffre d\'affaires par mois',
    "SELECT DATE_FORMAT(c.dateCmd, '%Y-%m') AS mois, $CA AS ca
     FROM commande c JOIN lignecommande l ON l.idCmd = c.idCmd JOIN produit p ON p.idProd = l.idProd
     GROUP BY mois ORDER BY mois");

$topProd = timed('Top 5 produits (quantités vendues)',
    "SELECT p.designProd, p.photoProd, SUM(l.qteCmd) AS qte, $CA AS ca
     FROM lignecommande l JOIN produit p ON p.idProd = l.idProd
     GROUP BY p.idProd, p.designProd, p.photoProd ORDER BY qte DESC LIMIT 5");

$parDep = timed('Chiffre d\'affaires par département',
    "SELECT d.nomDep, $CA AS ca
     FROM lignecommande l JOIN produit p ON p.idProd = l.idProd
     JOIN commande c ON c.idCmd = l.idCmd JOIN client cl ON cl.idCli = c.idCli
     JOIN region r ON r.idRegion = cl.idRegion JOIN departement d ON d.idDep = r.idDep
     GROUP BY d.idDep, d.nomDep ORDER BY ca DESC");

$parRegion = timed('Chiffre d\'affaires par région',
    "SELECT r.nomRegion, d.nomDep, COUNT(DISTINCT c.idCmd) AS nbCmd, $CA AS ca
     FROM lignecommande l JOIN produit p ON p.idProd = l.idProd
     JOIN commande c ON c.idCmd = l.idCmd JOIN client cl ON cl.idCli = c.idCli
     JOIN region r ON r.idRegion = cl.idRegion JOIN departement d ON d.idDep = r.idDep
     GROUP BY r.idRegion, r.nomRegion, d.nomDep ORDER BY ca DESC");

$topCli = timed('Top 5 clients',
    "SELECT cl.nomCli, cl.prenomCli, COUNT(DISTINCT c.idCmd) AS nbCmd, $CA AS ca
     FROM lignecommande l JOIN produit p ON p.idProd = l.idProd
     JOIN commande c ON c.idCmd = l.idCmd JOIN client cl ON cl.idCli = c.idCli
     GROUP BY cl.idCli, cl.nomCli, cl.prenomCli ORDER BY ca DESC LIMIT 5");

$faible = timed('Produits à réapprovisionner',
    'SELECT designProd, photoProd, qteStock FROM produit WHERE qteStock <= ? ORDER BY qteStock, designProd LIMIT 8', [SEUIL_STOCK]);

require 'header.php';
?>
<div class="page-head"><div><h1>Tableau de bord</h1><p class="muted">Vue d'ensemble de l'activité commerciale</p></div></div>

<section class="kpis">
  <div class="kpi"><span class="kpi-ico c1"><?= icon('wallet') ?></span><div><span>Chiffre d'affaires</span><b><?= money($kpi['ca']) ?></b></div></div>
  <div class="kpi"><span class="kpi-ico c2"><?= icon('receipt') ?></span><div><span>Commandes</span><b><?= (int)$kpi['nbCmd'] ?></b></div></div>
  <div class="kpi"><span class="kpi-ico c3"><?= icon('trend') ?></span><div><span>Panier moyen</span><b><?= money($panier) ?></b></div></div>
  <div class="kpi"><span class="kpi-ico c4"><?= icon('users') ?></span><div><span>Clients</span><b><?= (int)$kpi['nbCli'] ?></b></div></div>
  <div class="kpi <?= $kpi['nbFaible'] ? 'alert' : '' ?>"><span class="kpi-ico c5"><?= icon('alert') ?></span><div><span>Stock faible</span><b><?= (int)$kpi['nbFaible'] ?></b></div></div>
</section>

<?php if (!$kpi['nbCmd']): ?>
  <p class="empty">Aucune donnée à analyser pour le moment. Créez une commande pour voir les statistiques.</p>
<?php else: ?>
<section class="grid">
  <article class="card wide"><h2>Chiffre d'affaires par mois</h2><canvas id="cMois" height="95"></canvas></article>
  <article class="card"><h2>Produits les plus vendus</h2>
    <?php $maxQ = max(array_map(fn($x) => (int)$x['qte'], $topProd)) ?: 1; ?>
    <ol class="rank">
      <?php foreach ($topProd as $i => $t): ?>
      <li>
        <span class="pos"><?= $i + 1 ?></span>
        <?= photo_tag($t['photoProd'], $t['designProd'], 'thumb') ?>
        <div class="rank-body">
          <div class="rank-top"><strong><?= h($t['designProd']) ?></strong><span><?= (int)$t['qte'] ?> vendus</span></div>
          <div class="bar"><i style="width:<?= round($t['qte'] / $maxQ * 100) ?>%"></i></div>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
  </article>
  <article class="card"><h2>Répartition par département</h2><div class="donut"><canvas id="cDep"></canvas></div></article>
</section>

<section class="grid">
  <article class="card"><h2>Chiffre d'affaires par région</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Région</th><th>Département</th><th class="num">Cmd</th><th class="num">CA</th></tr></thead>
      <tbody><?php foreach ($parRegion as $r): ?>
        <tr><td><strong><?= h($r['nomRegion']) ?></strong></td><td><span class="chip"><?= h($r['nomDep']) ?></span></td><td class="num"><?= (int)$r['nbCmd'] ?></td><td class="num"><?= money($r['ca']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </article>
  <article class="card"><h2>Meilleurs clients</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Client</th><th class="num">Cmd</th><th class="num">CA</th></tr></thead>
      <tbody><?php foreach ($topCli as $c): ?>
        <tr><td><div class="who"><?= photo_tag(null, $c['prenomCli'] . ' ' . $c['nomCli'], 'avatar sm') ?><?= h($c['nomCli'] . ' ' . $c['prenomCli']) ?></div></td><td class="num"><?= (int)$c['nbCmd'] ?></td><td class="num"><?= money($c['ca']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </article>
</section>

<?php if ($faible): ?>
<article class="card"><h2>À réapprovisionner</h2>
  <ul class="stock-list">
    <?php foreach ($faible as $f): [$cls, $lib] = stock_status((int)$f['qteStock']); ?>
    <li>
      <?= photo_tag($f['photoProd'], $f['designProd'], 'thumb') ?>
      <span><strong><?= h($f['designProd']) ?></strong><small class="muted"><?= (int)$f['qteStock'] ?> en stock</small></span>
      <span class="tag static <?= $cls ?>"><?= $lib ?></span>
    </li>
    <?php endforeach; ?>
  </ul>
</article>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
<script>
const mois = <?= json_encode($parMois) ?>, dep = <?= json_encode($parDep) ?>;
const couleurs = ['#4f46e5', '#0ea5e9', '#f59e0b', '#10b981', '#ec4899', '#8b5cf6'];
const fmt = v => new Intl.NumberFormat('fr-FR').format(v);
Chart.defaults.font.family = 'Inter, system-ui, sans-serif';
Chart.defaults.color = '#64748b';
new Chart(cMois, { type: 'bar',
  data: { labels: mois.map(m => m.mois), datasets: [{ label: 'CA', data: mois.map(m => +m.ca), backgroundColor: '#4f46e5', borderRadius: 6, maxBarThickness: 44 }] },
  options: { plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => fmt(c.parsed.y) + ' <?= DEVISE ?>' } } },
             scales: { y: { ticks: { callback: fmt }, grid: { color: '#eef2f7' } }, x: { grid: { display: false } } } } });
new Chart(cDep, { type: 'doughnut',
  data: { labels: dep.map(d => d.nomDep), datasets: [{ data: dep.map(d => +d.ca), backgroundColor: couleurs, borderWidth: 3, borderColor: '#fff' }] },
  options: { cutout: '64%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16 } },
             tooltip: { callbacks: { label: c => ' ' + c.label + ' : ' + fmt(c.parsed) + ' <?= DEVISE ?>' } } } } });
</script>
<?php endif; ?>

<details class="card perf">
  <summary>Analyse de performance (temps d'exécution des requêtes)</summary>
  <div class="table-wrap"><table>
    <thead><tr><th>Requête</th><th class="num">Lignes</th><th class="num">Temps</th></tr></thead>
    <tbody><?php foreach ($PERF as $x): ?>
      <tr><td><?= h($x['label']) ?></td><td class="num"><?= $x['rows'] ?></td><td class="num"><?= number_format($x['ms'], 2, ',', ' ') ?> ms</td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <p class="muted">Pour aller plus loin, préfixez une requête par <code>EXPLAIN</code> dans MySQL et vérifiez que les index (idx_commande_date, idx_ligne_prod, clés étrangères) sont bien utilisés.</p>
</details>
<?php require 'footer.php'; ?>
