<?php
require_once 'config.php';
$titre = 'Produits'; $page = 'produits';
$q = trim($_GET['q'] ?? '');
$st = $pdo->prepare('SELECT * FROM produit WHERE designProd LIKE ? ORDER BY designProd');
$st->execute(['%' . $q . '%']);
$produits = $st->fetchAll();
require 'header.php';
?>
<div class="page-head">
  <div><h1>Produits</h1><p class="muted"><?= count($produits) ?> produit(s) au catalogue</p></div>
  <form class="search" method="get" role="search">
    <?= icon('search') ?>
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Rechercher un produit" aria-label="Rechercher un produit">
    <button class="btn primary">Rechercher</button>
  </form>
</div>

<?php if (!$produits): ?>
  <p class="empty">Aucun produit ne correspond à « <?= h($q) ?> ».</p>
<?php else: ?>
<section class="products">
  <?php foreach ($produits as $p): [$cls, $lib] = stock_status((int)$p['qteStock']); ?>
  <article class="product">
    <div class="product-img">
      <?= photo_tag($p['photoProd'], $p['designProd'], 'cover') ?>
      <span class="tag <?= $cls ?>"><?= $lib ?></span>
    </div>
    <div class="product-body">
      <h2><?= h($p['designProd']) ?></h2>
      <div class="product-meta">
        <strong class="price"><?= money($p['prixUProd']) ?></strong>
        <span class="muted"><?= (int)$p['qteStock'] ?> en stock</span>
      </div>
      <a class="btn small block" href="produit_modifier.php?id=<?= (int)$p['idProd'] ?>"><?= icon('edit') ?> Modifier</a>
    </div>
  </article>
  <?php endforeach; ?>
</section>
<?php endif; ?>
<?php require 'footer.php'; ?>
