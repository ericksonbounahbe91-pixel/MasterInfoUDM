<?php require_once __DIR__ . '/config.php'; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($titre ?? 'Gestion des commandes') ?> · Gestion commandes</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="layout">
  <aside class="side">
    <a class="brand" href="index.php">
      <span class="logo"><?= icon('box') ?></span>
      <span>Gestion<small>des commandes</small></span>
    </a>
    <nav aria-label="Navigation principale">
      <?php foreach ([
        'index'     => ['Tableau de bord', 'grid'],
        'commandes' => ['Commandes', 'cart'],
        'produits'  => ['Produits', 'box'],
        'clients'   => ['Clients', 'users'],
      ] as $k => [$l, $ic]): ?>
        <a href="<?= $k ?>.php" <?= ($page ?? '') === $k ? 'aria-current="page"' : '' ?>><?= icon($ic) ?><span><?= $l ?></span></a>
      <?php endforeach; ?>
    </nav>
    <div class="side-foot">TP · PHP / MySQL</div>
  </aside>
  <main>
<?php if (!empty($_SESSION['flash'])): [$ft, $fm] = $_SESSION['flash']; unset($_SESSION['flash']); ?>
  <div class="flash <?= h($ft) ?>" role="status"><?= h($fm) ?></div>
<?php endif; ?>
