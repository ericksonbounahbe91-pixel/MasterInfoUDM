<?php
require __DIR__ . '/config.php';
require_login();
$id = null;
require __DIR__ . '/includes/form.php';
