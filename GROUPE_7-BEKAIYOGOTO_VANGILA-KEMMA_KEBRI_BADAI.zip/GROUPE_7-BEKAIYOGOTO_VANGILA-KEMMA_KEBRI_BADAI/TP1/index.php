<?php
require __DIR__ . '/config.php';
require_login();
$pdo = db();

/* ----- Statistiques ----- */
$total   = (int)$pdo->query('SELECT COUNT(*) FROM etudiants')->fetchColumn();
$femmes  = (int)$pdo->query("SELECT COUNT(*) FROM etudiants WHERE UPPER(LEFT(sexe,1)) = 'F'")->fetchColumn();
$hommes  = (int)$pdo->query("SELECT COUNT(*) FROM etudiants WHERE UPPER(LEFT(sexe,1)) = 'M'")->fetchColumn();
$cycles  = $pdo->query("SELECT LOWER(cycle) AS c, COUNT(*) AS n FROM etudiants GROUP BY LOWER(cycle) ORDER BY n DESC")->fetchAll();
$mentions = $pdo->query("SELECT DISTINCT mention FROM etudiants WHERE mention IS NOT NULL AND mention <> '' ORDER BY mention")->fetchAll(PDO::FETCH_COLUMN);

/* ----- Liste filtrée + pagination ----- */
[$where, $params, $order] = etudiant_filters($_GET);
$perPage = 10;
$cnt = $pdo->prepare("SELECT COUNT(*) FROM etudiants WHERE $where");
$cnt->execute($params);
$found  = (int)$cnt->fetchColumn();
$pages  = max(1, (int)ceil($found / $perPage));
$page   = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
$offset = ($page - 1) * $perPage;

$st = $pdo->prepare("SELECT * FROM etudiants WHERE $where ORDER BY $order LIMIT $perPage OFFSET $offset");
$st->execute($params);
$rows = $st->fetchAll();

$filtered = ($_GET['q'] ?? '') !== '' || ($_GET['cycle'] ?? '') !== '' || ($_GET['mention'] ?? '') !== '' || ($_GET['sexe'] ?? '') !== '';

function qs(array $over = []): string
{
    $q = array_merge($_GET, $over);
    foreach ($q as $k => $v) {
        if ($v === null || $v === '') {
            unset($q[$k]);
        }
    }
    return http_build_query($q);
}

$pageTitle = 'Étudiants';
require __DIR__ . '/includes/header.php';
?>

<div class="pagehead">
  <div>
    <h1>Étudiants inscrits</h1>
    <p class="muted">Consultez, recherchez et gérez les dossiers des étudiants.</p>
  </div>
  <a class="btn btn--primary" href="ajouter.php"><?= icon('plus', 16) ?> Ajouter un étudiant</a>
</div>

<section class="summary" aria-label="Statistiques">
  <div class="summary__nums">
    <div><b><?= $total ?></b><span>étudiant<?= $total > 1 ? 's' : '' ?> inscrit<?= $total > 1 ? 's' : '' ?></span></div>
    <div><b><?= $femmes ?></b><span>femme<?= $femmes > 1 ? 's' : '' ?></span></div>
    <div><b><?= $hommes ?></b><span>homme<?= $hommes > 1 ? 's' : '' ?></span></div>
  </div>
  <div class="summary__bar">
    <h2>Répartition par cycle</h2>
    <?php if ($total > 0): ?>
      <div class="bar" role="img" aria-label="Répartition par cycle">
        <?php foreach ($cycles as $c): ?>
          <i class="<?= e(cycle_class($c['c'])) ?>" style="width: <?= round($c['n'] / $total * 100, 2) ?>%"></i>
        <?php endforeach; ?>
      </div>
      <ul class="legend">
        <?php foreach ($cycles as $c): ?>
          <li><i class="dot <?= e(cycle_class($c['c'])) ?>"></i><?= e(mb_convert_case($c['c'], MB_CASE_TITLE)) ?> : <?= (int)$c['n'] ?></li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="muted">Aucune donnée pour l'instant.</p>
    <?php endif; ?>
  </div>
</section>

<form class="filters" method="get">
  <div class="input-ico filters__search"><?= icon('search') ?>
    <input type="search" name="q" placeholder="Nom, prénom, email ou matricule" value="<?= e($_GET['q'] ?? '') ?>" aria-label="Rechercher">
  </div>
  <select name="cycle" aria-label="Cycle">
    <option value="">Tous les cycles</option>
    <?php foreach (CYCLES as $c): ?>
      <option value="<?= e($c) ?>" <?= strcasecmp($_GET['cycle'] ?? '', $c) === 0 ? 'selected' : '' ?>><?= e($c) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="mention" aria-label="Mention">
    <option value="">Toutes les mentions</option>
    <?php foreach ($mentions as $m): ?>
      <option value="<?= e($m) ?>" <?= ($_GET['mention'] ?? '') === $m ? 'selected' : '' ?>><?= e($m) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="sexe" aria-label="Sexe">
    <option value="">Tous</option>
    <option value="F" <?= ($_GET['sexe'] ?? '') === 'F' ? 'selected' : '' ?>>Femmes</option>
    <option value="M" <?= ($_GET['sexe'] ?? '') === 'M' ? 'selected' : '' ?>>Hommes</option>
  </select>
  <select name="tri" aria-label="Trier par">
    <?php foreach (['nom_asc' => 'Nom (A à Z)', 'nom_desc' => 'Nom (Z à A)', 'recent' => 'Plus récents', 'ancien' => 'Plus anciens'] as $k => $lbl): ?>
      <option value="<?= $k ?>" <?= ($_GET['tri'] ?? 'nom_asc') === $k ? 'selected' : '' ?>><?= $lbl ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn btn--primary" type="submit">Filtrer</button>
  <?php if ($filtered): ?><a class="btn btn--ghost" href="index.php">Réinitialiser</a><?php endif; ?>
  <a class="btn btn--ghost filters__export" href="export.php?<?= e(qs(['page' => null])) ?>"><?= icon('download', 16) ?> Exporter en CSV (Excel)</a>
</form>

<section class="card">
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr><th>Étudiant</th><th>Email</th><th>Mention</th><th>Cycle</th><th class="t-right">Actions</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr class="empty"><td colspan="5">
          <?= $filtered ? 'Aucun étudiant ne correspond à ces filtres.' : 'Aucun étudiant enregistré. Cliquez sur « Ajouter un étudiant » pour commencer.' ?>
        </td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td data-label="Étudiant">
            <div class="person">
              <?= avatar($r) ?>
              <div>
                <a class="person__name" href="fiche.php?id=<?= (int)$r['id'] ?>"><?= e(nom_complet($r)) ?></a>
                <small class="muted">Matricule <?= (int)$r['id'] ?></small>
              </div>
            </div>
          </td>
          <td data-label="Email"><a class="mail" href="mailto:<?= e($r['email']) ?>"><?= e($r['email']) ?></a></td>
          <td data-label="Mention"><?php if (!empty($r['mention'])): ?><span class="badge badge--mention"><?= e($r['mention']) ?></span><?php else: ?><span class="muted">—</span><?php endif; ?></td>
          <td data-label="Cycle"><span class="badge <?= e(cycle_class((string)$r['cycle'])) ?>"><?= e(mb_convert_case((string)$r['cycle'], MB_CASE_TITLE)) ?></span></td>
          <td class="t-right">
            <div class="actions">
              <a class="icon-btn" href="fiche.php?id=<?= (int)$r['id'] ?>" title="Voir la fiche" aria-label="Voir la fiche"><?= icon('eye') ?></a>
              <a class="icon-btn" href="modifier.php?id=<?= (int)$r['id'] ?>" title="Modifier" aria-label="Modifier"><?= icon('edit') ?></a>
              <form method="post" action="supprimer.php" onsubmit="return confirm('Supprimer définitivement <?= e(addslashes(nom_complet($r))) ?> ?');">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="icon-btn icon-btn--danger" type="submit" title="Supprimer" aria-label="Supprimer"><?= icon('trash') ?></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($found > 0): ?>
  <div class="tablefoot">
    <span class="muted"><?= $found ?> résultat<?= $found > 1 ? 's' : '' ?></span>
    <?php if ($pages > 1): ?>
    <nav class="pager" aria-label="Pagination">
      <?php if ($page > 1): ?><a href="?<?= e(qs(['page' => $page - 1])) ?>">Précédent</a><?php endif; ?>
      <span>Page <?= $page ?> sur <?= $pages ?></span>
      <?php if ($page < $pages): ?><a href="?<?= e(qs(['page' => $page + 1])) ?>">Suivant</a><?php endif; ?>
    </nav>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
