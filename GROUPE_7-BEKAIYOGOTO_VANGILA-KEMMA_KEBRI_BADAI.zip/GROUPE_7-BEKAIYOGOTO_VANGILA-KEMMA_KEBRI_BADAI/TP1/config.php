<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------- Paramètres à adapter si besoin ---------- */
const DB_HOST = 'localhost';
const DB_NAME = 'gestion_etudiants';
const DB_USER = 'root';
const DB_PASS = '';

/* Compte créé automatiquement au premier lancement (si aucun admin n'existe) */
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'Admin@2026';

const UPLOAD_DIR = __DIR__ . '/uploads/';
const UPLOAD_URL = 'uploads/';
const CYCLES = ['Licence', 'Master', 'Doctorat'];

/* ---------- Base de données ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');
    init_schema($pdo);
    return $pdo;
}

function init_schema(PDO $pdo): void
{
    if (!empty($_SESSION['schema_ok'])) {
        return;
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS etudiants (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(100) NOT NULL,
        prenom VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(60) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Ajoute les colonnes manquantes sans toucher aux données existantes
    $expected = [
        'telephone'      => 'VARCHAR(30) NULL',
        'sexe'           => 'VARCHAR(10) NULL',
        'date_naissance' => 'DATE NULL',
        'mention'        => 'VARCHAR(100) NULL',
        'cycle'          => "VARCHAR(30) NOT NULL DEFAULT 'Licence'",
        'photo'          => 'VARCHAR(255) NULL',
        'created_at'     => 'TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP',
    ];
    $have = array_column($pdo->query('SHOW COLUMNS FROM etudiants')->fetchAll(), 'Field');
    foreach ($expected as $col => $def) {
        if (!in_array($col, $have, true)) {
            $pdo->exec("ALTER TABLE etudiants ADD COLUMN `$col` $def");
        }
    }

    if ((int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() === 0) {
        $st = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
        $st->execute([ADMIN_USER, password_hash(ADMIN_PASS, PASSWORD_DEFAULT)]);
    }
    $_SESSION['schema_ok'] = true;
}

/* ---------- Sécurité ---------- */
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function require_login(): void
{
    if (empty($_SESSION['admin'])) {
        header('Location: login.php');
        exit;
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', (string)$_POST['csrf']);
    if (!$ok) {
        http_response_code(400);
        exit('Session expirée. Rechargez la page et réessayez.');
    }
}

function flash(?string $type = null, ?string $msg = null): ?array
{
    if ($type !== null) {
        $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ---------- Aides d'affichage ---------- */
function icon(string $name, int $size = 18): string
{
    $paths = [
        'eye'      => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'edit'     => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
        'trash'    => '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/>',
        'plus'     => '<path d="M12 5v14M5 12h14"/>',
        'download' => '<path d="M12 3v12"/><path d="M7 11l5 5 5-5"/><path d="M5 21h14"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
        'search'   => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
        'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
        'lock'     => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/>',
        'back'     => '<path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/>',
        'print'    => '<path d="M6 9V3h12v6"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    ];
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
         . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$name] ?? '') . '</svg>';
}

function cycle_class(string $c): string
{
    $c = mb_strtolower(trim($c));
    return in_array($c, ['licence', 'master', 'doctorat'], true) ? 'c-' . $c : 'c-autre';
}

function nom_complet(array $r): string
{
    return trim(($r['nom'] ?? '') . ' ' . ($r['prenom'] ?? ''));
}

function initiales(array $r): string
{
    return mb_strtoupper(mb_substr((string)($r['prenom'] ?? ''), 0, 1) . mb_substr((string)($r['nom'] ?? ''), 0, 1));
}

function avatar(array $r, string $class = ''): string
{
    if (!empty($r['photo']) && is_file(UPLOAD_DIR . basename($r['photo']))) {
        return '<img class="avatar ' . $class . '" src="' . e(UPLOAD_URL . basename($r['photo'])) . '" alt="">';
    }
    return '<span class="avatar avatar--ini ' . $class . '" aria-hidden="true">' . e(initiales($r)) . '</span>';
}

/* ---------- Filtres de la liste (utilisés par index.php et export.php) ---------- */
function etudiant_filters(array $g): array
{
    $where = ['1=1'];
    $p = [];

    $q = trim((string)($g['q'] ?? ''));
    if ($q !== '') {
        $where[] = '(nom LIKE :q1 OR prenom LIKE :q2 OR email LIKE :q3 OR CAST(id AS CHAR) LIKE :q4)';
        foreach (['q1', 'q2', 'q3', 'q4'] as $k) {
            $p[':' . $k] = '%' . $q . '%';
        }
    }
    $cycle = trim((string)($g['cycle'] ?? ''));
    if ($cycle !== '') {
        $where[] = 'LOWER(cycle) = LOWER(:cycle)';
        $p[':cycle'] = $cycle;
    }
    $mention = trim((string)($g['mention'] ?? ''));
    if ($mention !== '') {
        $where[] = 'mention = :mention';
        $p[':mention'] = $mention;
    }
    $sexe = strtoupper(trim((string)($g['sexe'] ?? '')));
    if ($sexe === 'F' || $sexe === 'M') {
        $where[] = 'UPPER(LEFT(sexe, 1)) = :sexe';
        $p[':sexe'] = $sexe;
    }

    $orders = [
        'nom_asc'  => 'nom ASC, prenom ASC',
        'nom_desc' => 'nom DESC, prenom DESC',
        'recent'   => 'id DESC',
        'ancien'   => 'id ASC',
    ];
    $tri = $orders[$g['tri'] ?? ''] ?? $orders['nom_asc'];

    return [implode(' AND ', $where), $p, $tri];
}

/* ---------- Photo ---------- */
function save_photo(array $f): ?string
{
    $err = $f['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($err !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Le téléversement de la photo a échoué.');
    }
    if ($f['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('La photo dépasse 2 Mo.');
    }
    $info = @getimagesize($f['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]])) {
        throw new RuntimeException('Format de photo non accepté (JPG, PNG ou WebP).');
    }
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0775, true);
    }
    $name = bin2hex(random_bytes(8)) . '.' . $types[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $name)) {
        throw new RuntimeException("Impossible d'enregistrer la photo.");
    }
    return $name;
}

function delete_photo(?string $name): void
{
    if ($name) {
        $path = UPLOAD_DIR . basename($name);
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
