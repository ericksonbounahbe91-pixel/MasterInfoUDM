</main>
<footer class="foot">
  <span>© <?= date('Y') ?> Université de Moundou</span>
  <span>BP 206 · Moundou, Tchad</span>
</footer>
</body>
</html>
