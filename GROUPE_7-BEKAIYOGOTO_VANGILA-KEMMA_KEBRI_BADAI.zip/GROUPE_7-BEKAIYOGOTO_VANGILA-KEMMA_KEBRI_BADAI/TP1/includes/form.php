<?php
/* Formulaire partagé : ajouter.php ($id = null) et modifier.php ($id = n) */
$pdo = db();
$existing = null;
if ($id !== null) {
    $st = $pdo->prepare('SELECT * FROM etudiants WHERE id = ?');
    $st->execute([$id]);
    $existing = $st->fetch();
    if (!$existing) {
        flash('error', 'Étudiant introuvable.');
        header('Location: index.php');
        exit;
    }
}

$d = $existing ?: ['nom' => '', 'prenom' => '', 'email' => '', 'telephone' => '', 'sexe' => '', 'date_naissance' => '', 'mention' => '', 'cycle' => 'Licence', 'photo' => ''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach (['nom', 'prenom', 'email', 'telephone', 'mention', 'cycle', 'date_naissance'] as $k) {
        $d[$k] = trim((string)($_POST[$k] ?? ''));
    }
    $d['sexe'] = in_array($_POST['sexe'] ?? '', ['F', 'M'], true) ? $_POST['sexe'] : '';

    if ($d['nom'] === '')    $errors['nom'] = 'Le nom est obligatoire.';
    if ($d['prenom'] === '') $errors['prenom'] = 'Le prénom est obligatoire.';
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Saisissez une adresse email valide.';
    if (!in_array($d['cycle'], CYCLES, true)) $errors['cycle'] = 'Choisissez un cycle.';
    if ($d['date_naissance'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d['date_naissance'])) {
        $errors['date_naissance'] = 'Date invalide.';
    }

    if (!isset($errors['email'])) {
        $chk = $pdo->prepare('SELECT COUNT(*) FROM etudiants WHERE email = ? AND id <> ?');
        $chk->execute([$d['email'], $id ?? 0]);
        if ((int)$chk->fetchColumn() > 0) $errors['email'] = 'Cet email est déjà utilisé par un autre étudiant.';
    }

    $newPhoto = null;
    if (!$errors) {
        try {
            $newPhoto = save_photo($_FILES['photo'] ?? []);
        } catch (RuntimeException $ex) {
            $errors['photo'] = $ex->getMessage();
        }
    }

    if (!$errors) {
        $vals = [
            $d['nom'], $d['prenom'], $d['email'], $d['telephone'] ?: null, $d['sexe'] ?: null,
            $d['date_naissance'] ?: null, $d['mention'] ?: null, $d['cycle'],
        ];
        if ($id === null) {
            $vals[] = $newPhoto;
            $pdo->prepare('INSERT INTO etudiants (nom, prenom, email, telephone, sexe, date_naissance, mention, cycle, photo) VALUES (?,?,?,?,?,?,?,?,?)')->execute($vals);
            flash('success', 'Étudiant ajouté.');
        } else {
            $sql = 'UPDATE etudiants SET nom=?, prenom=?, email=?, telephone=?, sexe=?, date_naissance=?, mention=?, cycle=?';
            if ($newPhoto) {
                $sql .= ', photo=?';
                $vals[] = $newPhoto;
            }
            $vals[] = $id;
            $pdo->prepare($sql . ' WHERE id=?')->execute($vals);
            if ($newPhoto) delete_photo($existing['photo'] ?? null);
            flash('success', 'Modifications enregistrées.');
        }
        header('Location: index.php');
        exit;
    }
}

$mentions = $pdo->query("SELECT DISTINCT mention FROM etudiants WHERE mention IS NOT NULL AND mention <> '' ORDER BY mention")->fetchAll(PDO::FETCH_COLUMN);
$titre = $id === null ? 'Ajouter un étudiant' : 'Modifier un étudiant';
$pageTitle = $titre;
require __DIR__ . '/header.php';

function err(array $errors, string $k): string
{
    return isset($errors[$k]) ? '<small class="field__err">' . e($errors[$k]) . '</small>' : '';
}
?>
<div class="pagehead">
  <div>
    <h1><?= e($titre) ?></h1>
    <p class="muted"><?= $id === null ? 'Renseignez les informations du nouvel étudiant.' : 'Matricule ' . (int)$id ?></p>
  </div>
  <a class="btn btn--ghost" href="index.php"><?= icon('back', 16) ?> Retour à la liste</a>
</div>

<form class="card formcard" method="post" enctype="multipart/form-data" novalidate>
  <?= csrf_field() ?>
  <div class="formgrid">
    <div class="photo-pick">
      <?= avatar($d, 'avatar--xl') ?>
      <label class="btn btn--ghost" for="photo">Choisir une photo</label>
      <input id="photo" type="file" name="photo" accept="image/jpeg,image/png,image/webp" hidden>
      <small class="muted">JPG, PNG ou WebP · 2 Mo maximum</small>
      <?= err($errors, 'photo') ?>
    </div>

    <div class="fields">
      <label class="field"><span>Nom</span>
        <input type="text" name="nom" value="<?= e($d['nom']) ?>" required><?= err($errors, 'nom') ?></label>
      <label class="field"><span>Prénom</span>
        <input type="text" name="prenom" value="<?= e($d['prenom']) ?>" required><?= err($errors, 'prenom') ?></label>
      <label class="field"><span>Email</span>
        <input type="email" name="email" value="<?= e($d['email']) ?>" required><?= err($errors, 'email') ?></label>
      <label class="field"><span>Téléphone</span>
        <input type="tel" name="telephone" value="<?= e($d['telephone']) ?>"></label>
      <label class="field"><span>Sexe</span>
        <select name="sexe">
          <option value="">Non précisé</option>
          <option value="F" <?= strtoupper(substr((string)$d['sexe'], 0, 1)) === 'F' ? 'selected' : '' ?>>Féminin</option>
          <option value="M" <?= strtoupper(substr((string)$d['sexe'], 0, 1)) === 'M' ? 'selected' : '' ?>>Masculin</option>
        </select></label>
      <label class="field"><span>Date de naissance</span>
        <input type="date" name="date_naissance" value="<?= e($d['date_naissance']) ?>"><?= err($errors, 'date_naissance') ?></label>
      <label class="field"><span>Cycle</span>
        <select name="cycle">
          <?php foreach (CYCLES as $c): ?>
            <option value="<?= e($c) ?>" <?= strcasecmp((string)$d['cycle'], $c) === 0 ? 'selected' : '' ?>><?= e($c) ?></option>
          <?php endforeach; ?>
        </select><?= err($errors, 'cycle') ?></label>
      <label class="field"><span>Mention</span>
        <input type="text" name="mention" list="mentions" value="<?= e($d['mention']) ?>">
        <datalist id="mentions"><?php foreach ($mentions as $m): ?><option value="<?= e($m) ?>"><?php endforeach; ?></datalist></label>
    </div>
  </div>
  <div class="formfoot">
    <a class="btn btn--ghost" href="index.php">Annuler</a>
    <button class="btn btn--primary" type="submit"><?= $id === null ? 'Ajouter l\'étudiant' : 'Enregistrer les modifications' ?></button>
  </div>
</form>

<script>
document.getElementById('photo').addEventListener('change', function () {
  var f = this.files[0];
  if (!f) return;
  var box = document.querySelector('.photo-pick .avatar');
  var img = document.createElement('img');
  img.className = 'avatar avatar--xl';
  img.alt = '';
  img.src = URL.createObjectURL(f);
  box.replaceWith(img);
});
</script>
<?php require __DIR__ . '/footer.php'; ?>
