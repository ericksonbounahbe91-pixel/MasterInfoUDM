<?php
$pageTitle = $pageTitle ?? 'Étudiants';
$flash = flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | Université de Moundou</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topbar">
  <div class="topbar__in">
    <a class="brand" href="index.php">
      <img src="assets/img/logo.png" alt="Logo de l'Université de Moundou" width="44" height="44">
      <span class="brand__txt">
        <strong>Université de Moundou</strong>
        <small>Gestion des étudiants</small>
      </span>
    </a>
    <div class="topbar__user">
      <span class="who"><?= icon('user', 16) ?> <?= e($_SESSION['admin'] ?? '') ?></span>
      <a class="btn btn--light" href="logout.php"><?= icon('logout', 16) ?> Se déconnecter</a>
    </div>
  </div>
  <div class="stripe" aria-hidden="true"><i></i><i></i><i></i></div>
</header>
<main class="page">
<?php if ($flash): ?>
  <div class="alert alert--<?= e($flash['type']) ?>" role="status"><?= e($flash['msg']) ?></div>
<?php endif; ?>
