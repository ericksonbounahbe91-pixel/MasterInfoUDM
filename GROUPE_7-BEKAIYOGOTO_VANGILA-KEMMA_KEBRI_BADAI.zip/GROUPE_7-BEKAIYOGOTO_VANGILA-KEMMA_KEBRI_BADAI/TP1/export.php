<?php
require __DIR__ . '/config.php';
require_login();

[$where, $params, $order] = etudiant_filters($_GET);
$st = db()->prepare("SELECT * FROM etudiants WHERE $where ORDER BY $order");
$st->execute($params);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="etudiants_' . date('Y-m-d') . '.csv"');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // BOM pour les accents dans Excel
fputcsv($out, ['Matricule', 'Nom', 'Prénom', 'Sexe', 'Date de naissance', 'Email', 'Téléphone', 'Mention', 'Cycle'], ';');
while ($r = $st->fetch()) {
    fputcsv($out, [
        $r['id'], $r['nom'], $r['prenom'], $r['sexe'], $r['date_naissance'],
        $r['email'], $r['telephone'], $r['mention'], $r['cycle'],
    ], ';');
}
fclose($out);
