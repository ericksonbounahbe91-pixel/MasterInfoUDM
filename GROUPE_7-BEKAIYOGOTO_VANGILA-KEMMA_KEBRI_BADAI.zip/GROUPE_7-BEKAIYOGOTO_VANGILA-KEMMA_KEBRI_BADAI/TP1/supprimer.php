<?php
require __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}
csrf_check();

$id  = (int)($_POST['id'] ?? 0);
$pdo = db();
$st  = $pdo->prepare('SELECT photo FROM etudiants WHERE id = ?');
$st->execute([$id]);
if ($row = $st->fetch()) {
    $pdo->prepare('DELETE FROM etudiants WHERE id = ?')->execute([$id]);
    delete_photo($row['photo'] ?? null);
    flash('success', 'Étudiant supprimé.');
} else {
    flash('error', 'Étudiant introuvable.');
}
header('Location: index.php');
exit;
