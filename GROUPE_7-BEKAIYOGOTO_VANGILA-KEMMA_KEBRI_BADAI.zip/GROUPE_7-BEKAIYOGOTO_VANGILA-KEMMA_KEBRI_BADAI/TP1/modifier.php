<?php
require __DIR__ . '/config.php';
require_login();
$id = (int)($_GET['id'] ?? 0);
require __DIR__ . '/includes/form.php';
