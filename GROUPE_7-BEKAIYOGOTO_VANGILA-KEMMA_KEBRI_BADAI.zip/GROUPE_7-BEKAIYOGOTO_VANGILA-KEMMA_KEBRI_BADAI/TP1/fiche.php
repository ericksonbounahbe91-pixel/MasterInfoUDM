<?php
require __DIR__ . '/config.php';
require_login();

$st = db()->prepare('SELECT * FROM etudiants WHERE id = ?');
$st->execute([(int)($_GET['id'] ?? 0)]);
$r = $st->fetch();
if (!$r) {
    flash('error', 'Étudiant introuvable.');
    header('Location: index.php');
    exit;
}

$sexe = strtoupper(substr((string)$r['sexe'], 0, 1));
$sexeLbl = $sexe === 'F' ? 'Féminin' : ($sexe === 'M' ? 'Masculin' : '—');
$naiss = !empty($r['date_naissance']) ? date('d/m/Y', strtotime($r['date_naissance'])) : '—';

$pageTitle = 'Fiche de ' . nom_complet($r);
require __DIR__ . '/includes/header.php';
?>
<div class="pagehead no-print">
  <a class="btn btn--ghost" href="index.php"><?= icon('back', 16) ?> Retour à la liste</a>
  <div class="row-gap">
    <button class="btn btn--ghost" type="button" onclick="window.print()"><?= icon('print', 16) ?> Imprimer</button>
    <a class="btn btn--primary" href="modifier.php?id=<?= (int)$r['id'] ?>"><?= icon('edit', 16) ?> Modifier</a>
  </div>
</div>

<section class="card fiche">
  <div class="fiche__id">
    <?= avatar($r, 'avatar--xl') ?>
    <h1><?= e(nom_complet($r)) ?></h1>
    <p class="muted">Matricule <?= (int)$r['id'] ?></p>
    <div class="row-gap">
      <span class="badge <?= e(cycle_class((string)$r['cycle'])) ?>"><?= e(mb_convert_case((string)$r['cycle'], MB_CASE_TITLE)) ?></span>
      <?php if (!empty($r['mention'])): ?><span class="badge badge--mention"><?= e($r['mention']) ?></span><?php endif; ?>
    </div>
  </div>
  <dl class="fiche__data">
    <div><dt>Nom</dt><dd><?= e($r['nom']) ?></dd></div>
    <div><dt>Prénom</dt><dd><?= e($r['prenom']) ?></dd></div>
    <div><dt>Sexe</dt><dd><?= e($sexeLbl) ?></dd></div>
    <div><dt>Date de naissance</dt><dd><?= e($naiss) ?></dd></div>
    <div><dt>Email</dt><dd><a class="mail" href="mailto:<?= e($r['email']) ?>"><?= e($r['email']) ?></a></dd></div>
    <div><dt>Téléphone</dt><dd><?= e($r['telephone'] ?: '—') ?></dd></div>
    <div><dt>Cycle</dt><dd><?= e(mb_convert_case((string)$r['cycle'], MB_CASE_TITLE)) ?></dd></div>
    <div><dt>Mention</dt><dd><?= e($r['mention'] ?: '—') ?></dd></div>
  </dl>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
