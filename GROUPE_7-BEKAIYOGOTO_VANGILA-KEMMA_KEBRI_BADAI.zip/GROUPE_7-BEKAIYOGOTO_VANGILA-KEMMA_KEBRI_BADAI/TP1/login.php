<?php
require __DIR__ . '/config.php';

if (!empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $user = trim($_POST['identifiant'] ?? '');
    $pass = (string)($_POST['mot_de_passe'] ?? '');

    $st = db()->prepare('SELECT username, password_hash FROM admins WHERE username = ?');
    $st->execute([$user]);
    $row = $st->fetch();

    if ($row && password_verify($pass, $row['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin'] = $row['username'];
        header('Location: index.php');
        exit;
    }
    usleep(500000); // ralentit les tentatives répétées
    $error = 'Identifiant ou mot de passe incorrect.';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Connexion | Université de Moundou</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth">
  <div class="auth__card">
    <div class="auth__head">
      <img src="assets/img/logo.png" alt="Logo de l'Université de Moundou" width="84" height="84">
      <h1 align="center" >Université de Moundou</h1>
      <p>Gestion des étudiants</p>
    </div>
    <div class="stripe" aria-hidden="true"><i></i><i></i><i></i></div>

    <form class="auth__form" method="post" autocomplete="on">
      <?= csrf_field() ?>
      <?php if ($error): ?>
        <div class="alert alert--error" role="alert"><?= e($error) ?></div>
      <?php endif; ?>

      <label class="field">
        <span>Identifiant</span>
        <div class="input-ico"><?= icon('user') ?>
          <input type="text" name="identifiant" required autofocus autocomplete="username"
                 value="<?= e($_POST['identifiant'] ?? '') ?>">
        </div>
      </label>

      <label class="field">
        <span>Mot de passe</span>
        <div class="input-ico"><?= icon('lock') ?>
          <input type="password" name="mot_de_passe" required autocomplete="current-password">
        </div>
      </label>

      <button class="btn btn--primary btn--block" type="submit">Se connecter</button>
    </form>
  </div>
  <p class="auth__foot">© <?= date('Y') ?> Université de Moundou · BP 206</p>
</body>
</html>
