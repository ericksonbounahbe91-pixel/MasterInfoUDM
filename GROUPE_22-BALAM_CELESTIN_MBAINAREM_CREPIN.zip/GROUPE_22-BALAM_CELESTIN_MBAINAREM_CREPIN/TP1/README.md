# GESTION DES ÉTUDIANTS

Application web en **PHP / MySQL (PDO)** pour gérer les étudiants d'une université : liste, recherche, ajout, modification et suppression (CRUD).

---

## 1. Contenu du projet

| Fichier | Rôle |
|---|---|
| `config.php` | Connexion PDO à MySQL, fonction `h()` (échappement HTML) et constante `CHAMPS` |
| `header.php` / `footer.php` | En-tête « GESTION DES ÉTUDIANTS » et pied de page communs à toutes les pages |
| `index.php` | **Read** : liste des étudiants + recherche |
| `form.php` | Formulaire partagé de création et de modification |
| `save.php` | **Create / Update** : validation et enregistrement (POST uniquement) |
| `delete.php` | **Delete** : suppression (POST uniquement) |
| `style.css` | Feuille de style (thème bleu marine / or) |
| `udm.jpg` | Logo de l'Université de Moundou (120×120 px) affiché dans l'en-tête |
| `gestion_etudiants.sql` | Création de la base, de la table `etudiant` et de 3 étudiants d'exemple |

---

## 2. Processus de développement

### Étape 1 : Analyse de l'existant
Le projet de départ (`NEW_WEB.rar`) contenait plusieurs fichiers, dont des doublons (`index.php` / `indexes.php`, `form.php` / `formes.php`, trois fichiers SQL). Nous avons lu chaque fichier pour identifier la version à garder et les problèmes à corriger.

### Étape 2 : Correction des anomalies
- **`indexes.php`** : une balise `</td>` manquait après la colonne Cycle, ce qui décalait les colonnes du tableau.
- **`form.php`** : les champs texte utilisaient la variable `$opt` (inexistante hors des listes déroulantes) au lieu de `$etu[$c]`. À la modification, les champs s'affichaient donc vides.
- **`formes.php`** : faute de frappe « Nouv el » dans le titre ; ce fichier est un doublon de `form.php`, nous n'avons conservé qu'une seule version.
- **`config.php`** : la base visée était `universite`, alors que le script `gestion_etudiants.sql` crée `gestion_etudiants`. Le nom a été aligné.

### Étape 3 : Réorganisation du code
Pour éviter de répéter le même HTML dans chaque page, l'en-tête et le pied de page ont été extraits dans `header.php` et `footer.php`. Chaque page définit simplement `$titrePage` puis inclut ces fichiers avec `require`.

### Étape 4 : Conception visuelle
- Choix d'une palette sobre et professionnelle, définie en **variables CSS** (`:root`) pour pouvoir changer le thème en un seul endroit :
  - bleu marine `#0b2545` (en-tête du tableau, titres),
  - bleu `#1d6fb8` (actions principales),
  - or `#c9a227` (liseré de l'en-tête, bouton « Nouvel étudiant »),
  - gris-bleu clair `#eef2f7` (fond de page).
- En-tête en dégradé avec le titre **GESTION DES ÉTUDIANTS** en majuscules.
- Intégration du **logo de l'Université de Moundou** (`udm.jpg`, 120×120 px, affiché à 56 px en cercle avec un liseré doré) à la place de l'icône provisoire.
- Tableau avec lignes alternées, survol de ligne, badges pour la mention et le cycle.
- Formulaire sur deux colonnes, qui passe sur une colonne sur petit écran (*responsive*).
- Messages de succès (vert) et d'erreur (rouge) harmonisés avec le thème.
- Le style est écrit en CSS pur (`style.css`) : plus de dépendance à Bootstrap ni de connexion internet nécessaire.

### Étape 5 : Améliorations fonctionnelles
- La recherche accepte maintenant le **nom, le prénom ou le matricule**.
- Ajout de la colonne **Téléphone** dans la liste.
- Ajout d'un compteur d'étudiants affichés.
- Tri par nom puis par prénom.

### Étape 6 : Sécurité (conservée et vérifiée)
- **Requêtes préparées PDO** partout : protection contre les injections SQL.
- **`h()`** (`htmlspecialchars`) sur tout affichage : protection contre le XSS.
- **Suppression et enregistrement par POST uniquement** (réponse 405 sinon) : une simple URL ne peut pas modifier les données.
- **Revalidation côté serveur** dans `save.php` (champs obligatoires, format de l'email) : on ne fait pas confiance au navigateur.
- Le matricule (clé primaire) est en lecture seule lors de la modification.
- Les erreurs techniques vont dans les logs (`error_log`), l'utilisateur ne voit qu'un message générique.

---

## 3. Installation

1. Installer **XAMPP** et démarrer **Apache** et **MySQL**.
2. Copier le dossier `GESTION_ETUDIANTS` dans `C:\xampp\htdocs\`.
3. Ouvrir **phpMyAdmin** (`http://localhost/phpmyadmin`) → **Importer** → choisir `gestion_etudiants.sql`.
4. Ouvrir `http://localhost/GESTION_ETUDIANTS/`.

> La connexion utilise par défaut l'utilisateur `root` sans mot de passe (configuration XAMPP). Pour un autre environnement, modifier la ligne `new PDO(...)` dans `config.php`.

---

## 4. Structure de la base de données

Table **`etudiant`** :

| Colonne | Type | Remarque |
|---|---|---|
| `idEtu` | VARCHAR(20) | Clé primaire (matricule, ex. `21A0123`) |
| `nomEtu`, `prenomEtu` | VARCHAR(100) | |
| `dateNaiss` | DATE | |
| `emailEtu` | VARCHAR(150) | Unique |
| `numTelEtu` | VARCHAR(20) | Unique |
| `regEtu`, `departEtu`, `arrondisEtu` | VARCHAR(100) | Région, département, arrondissement |
| `mentionEtu` | ENUM | Informatique, Mécatronique, Mathématiques |
| `cycleEtu` | ENUM | Licence, Master, Doctorat |
| `parcoursEtu` | VARCHAR(100) | |
| `dateInscription` | TIMESTAMP | Rempli automatiquement |

---

## 5. Pistes d'évolution

- Pagination de la liste des étudiants.
- Authentification (page de connexion administrateur).
- Export de la liste en PDF ou Excel.
- Jeton CSRF sur les formulaires.
- Listes déroulantes liées pour région / département / arrondissement.
