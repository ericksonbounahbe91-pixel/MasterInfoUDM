<?php
/** Formulaire partagé création / modification.
 *  GET ?id=XXX : charge l'étudiant à modifier ; sans id : formulaire vierge. */
require 'config.php';

$id = $_GET['id'] ?? null;
$etu = array_fill_keys(CHAMPS, '');
if ($id !== null) {
    $stmt = $pdo->prepare('SELECT * FROM etudiant WHERE idEtu = ?');
    $stmt->execute([$id]);
    $etu = $stmt->fetch() ?: exit('Étudiant introuvable.');
}
$libelles = ['idEtu'=>'Matricule','nomEtu'=>'Nom','prenomEtu'=>'Prénom','dateNaiss'=>'Date de naissance',
  'emailEtu'=>'Email','numTelEtu'=>'Téléphone','regEtu'=>'Région','departEtu'=>'Département',
  'arrondisEtu'=>'Arrondissement','mentionEtu'=>'Mention','cycleEtu'=>'Cycle','parcoursEtu'=>'Parcours'];
// Listes déroulantes : mêmes valeurs que les ENUM de la base
$listes = ['mentionEtu' => ['Informatique','Mécatronique','Mathématiques'],
           'cycleEtu'   => ['Licence','Master','Doctorat']];

$titrePage = $id ? 'Modifier un étudiant' : 'Nouvel étudiant';
require 'header.php';
?>
<main class="container narrow">
  <div class="card">
    <div class="toolbar"><h2><?= $id ? 'Modifier' : 'Nouvel' ?> étudiant</h2></div>
    <form method="post" action="save.php">
      <input type="hidden" name="mode" value="<?= $id ? 'update' : 'create' ?>">
      <div class="grid">
      <?php foreach (CHAMPS as $c): ?>
        <div>
          <label for="<?= $c ?>"><?= $libelles[$c] ?></label>
          <?php if (isset($listes[$c])): ?>
            <select id="<?= $c ?>" name="<?= $c ?>" required>
              <option value="">-- Choisir --</option>
              <?php foreach ($listes[$c] as $opt): ?>
                <option <?= $etu[$c] === $opt ? 'selected' : '' ?>><?= h($opt) ?></option>
              <?php endforeach; ?>
            </select>
          <?php else: ?>
            <input id="<?= $c ?>" name="<?= $c ?>"
                   type="<?= $c === 'dateNaiss' ? 'date' : ($c === 'emailEtu' ? 'email' : 'text') ?>"
                   value="<?= h($etu[$c]) ?>" required
                   <?= ($id && $c === 'idEtu') ? 'readonly' : '' ?>>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      </div>
      <div style="margin-top:22px">
        <button class="btn btn-primary">Enregistrer</button>
        <a class="btn btn-link" href="index.php">Annuler</a>
      </div>
    </form>
  </div>
</main>
<?php require 'footer.php'; ?>
