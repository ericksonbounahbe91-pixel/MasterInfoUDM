<?php
/** READ : liste des étudiants (GET, recherche facultative via ?q=). */
require 'config.php';

$q = trim($_GET['q'] ?? '');
$stmt = $pdo->prepare(
    'SELECT idEtu, nomEtu, prenomEtu, emailEtu, numTelEtu, mentionEtu, cycleEtu, parcoursEtu
       FROM etudiant
      WHERE nomEtu LIKE :q OR prenomEtu LIKE :q OR idEtu LIKE :q
      ORDER BY nomEtu, prenomEtu'
);
$stmt->execute([':q' => "%$q%"]);
$etudiants = $stmt->fetchAll();

$titrePage = 'Liste des étudiants';
require 'header.php';
?>
<main class="container">
  <div class="card">
    <div class="toolbar">
      <h2>Liste des étudiants</h2>
      <form class="search" method="get">
        <input name="q" placeholder="Nom, prénom ou matricule…" value="<?= h($q) ?>">
        <button class="btn btn-primary">Rechercher</button>
      </form>
    </div>

    <?php if (isset($_GET['ok'])): ?><div class="alert alert-success">Opération réussie.</div><?php endif; ?>
    <?php if (isset($_GET['err'])): ?><div class="alert alert-danger"><?= h($_GET['err']) ?></div><?php endif; ?>

    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>Matricule</th><th>Nom</th><th>Prénom</th><th>Email</th><th>Téléphone</th><th>Mention</th><th>Cycle</th><th>Parcours</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($etudiants as $e): ?>
          <tr>
            <td><strong><?= h($e['idEtu']) ?></strong></td>
            <td><?= h($e['nomEtu']) ?></td>
            <td><?= h($e['prenomEtu']) ?></td>
            <td><?= h($e['emailEtu']) ?></td>
            <td><?= h($e['numTelEtu']) ?></td>
            <td><span class="badge"><?= h($e['mentionEtu']) ?></span></td>
            <td><span class="badge gold"><?= h($e['cycleEtu']) ?></span></td>
            <td><?= h($e['parcoursEtu']) ?></td>
            <td class="actions">
              <a class="btn btn-sm btn-outline" href="form.php?id=<?= urlencode($e['idEtu']) ?>">Modifier</a>
              <!-- Suppression par POST (jamais par GET) -->
              <form method="post" action="delete.php" onsubmit="return confirm('Supprimer cet étudiant ?');">
                <input type="hidden" name="idEtu" value="<?= h($e['idEtu']) ?>">
                <button class="btn btn-sm btn-danger">Supprimer</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$etudiants): ?><tr><td colspan="9" class="empty">Aucun résultat.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
    <p class="count"><?= count($etudiants) ?> étudiant(s) affiché(s)</p>
  </div>
</main>
<?php require 'footer.php'; ?>
