-- ============================================================
-- Base de données : gestion_etudiants
-- Projet : Inscription d'un étudiant (formulaire index.html)
-- Import : XAMPP > phpMyAdmin > Importer
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `gestion_etudiants`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `gestion_etudiants`;

-- ------------------------------------------------------------
-- Table : etudiant
-- Chaque colonne correspond à un champ (name) du formulaire
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `etudiant`;

CREATE TABLE `etudiant` (
  `idEtu`          VARCHAR(20)  NOT NULL COMMENT 'Matricule (ex. 21A0123)',
  `nomEtu`         VARCHAR(100) NOT NULL,
  `prenomEtu`      VARCHAR(100) NOT NULL,
  `dateNaiss`      DATE         NOT NULL,
  `emailEtu`       VARCHAR(150) NOT NULL,
  `numTelEtu`      VARCHAR(20)  NOT NULL COMMENT 'ex. +237 6XX XX XX XX',
  `regEtu`         VARCHAR(100) NOT NULL COMMENT 'Région',
  `departEtu`      VARCHAR(100) NOT NULL COMMENT 'Département',
  `arrondisEtu`    VARCHAR(100) NOT NULL COMMENT 'Arrondissement',
  `mentionEtu`     ENUM('Informatique','Mécatronique','Mathématiques') NOT NULL,
  `cycleEtu`       ENUM('Licence','Master','Doctorat') NOT NULL,
  `parcoursEtu`    VARCHAR(100) NOT NULL,
  `dateInscription` TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idEtu`),
  UNIQUE KEY `uk_etudiant_email` (`emailEtu`),
  UNIQUE KEY `uk_etudiant_tel` (`numTelEtu`),
  KEY `idx_etudiant_nom` (`nomEtu`, `prenomEtu`),
  KEY `idx_etudiant_mention_cycle` (`mentionEtu`, `cycleEtu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Données d'exemple (à supprimer si inutiles)
-- ------------------------------------------------------------
INSERT INTO `etudiant`
  (`idEtu`, `nomEtu`, `prenomEtu`, `dateNaiss`, `emailEtu`, `numTelEtu`,
   `regEtu`, `departEtu`, `arrondisEtu`, `mentionEtu`, `cycleEtu`, `parcoursEtu`)
VALUES
  ('21A0123', 'Mbarga',  'Jean',    '2002-03-14', 'jean.mbarga@example.com',  '+237 677 12 34 56', 'Centre',  'Mfoundi',     'Yaoundé 3e',    'Informatique',  'Licence',  'Génie logiciel'),
  ('21A0456', 'Nguemo',  'Aïcha',   '2001-11-02', 'aicha.nguemo@example.com', '+237 699 45 67 89', 'Littoral','Wouri',       'Douala 5e',     'Mécatronique',  'Master',   'Systèmes embarqués'),
  ('22A0789', 'Tchoua',  'Brice',   '2003-07-25', 'brice.tchoua@example.com', '+237 655 98 76 54', 'Ouest',   'Mifi',        'Bafoussam 1er', 'Mathématiques', 'Licence',  'Mathématiques appliquées');

SET FOREIGN_KEY_CHECKS = 1;
