<footer class="site-footer">© <?= date('Y') ?> – Gestion des étudiants</footer>
</body>
</html>
