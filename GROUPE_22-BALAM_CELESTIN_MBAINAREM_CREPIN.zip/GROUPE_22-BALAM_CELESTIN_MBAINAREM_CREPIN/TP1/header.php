<?php /** En-tête commun : $titrePage (optionnel) définit le <title>. */ ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($titrePage ?? 'Gestion des étudiants') ?> – GESTION DES ÉTUDIANTS</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="site-header">
  <div class="inner">
    <div class="brand">
      <div class="logo">🎓</div>
      <h1>Gestion des étudiants<small>Inscription, consultation et suivi des étudiants</small></h1>
    </div>
    <a class="btn btn-gold" href="form.php">+ Nouvel étudiant</a>
  </div>
</header>
