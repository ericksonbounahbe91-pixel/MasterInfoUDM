import 'package:flutter/material.dart';

class AppColors {
  static const blue = Color(0xFF2457D6);
  static const blueLight = Color(0xFF527CE9);
  static const navy = Color(0xFF17233D);
  static const muted = Color(0xFF77839B);
  static const background = Color(0xFFF5F7FC);
  static const green = Color(0xFF15966B);
  static const orange = Color(0xFFE18A24);
  static const purple = Color(0xFF8254C8);
  static const border = Color(0xFFE8ECF4);
}
