import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/student.dart';
import '../models/course.dart';

class AppRepository {
  static const _studentsKey = 'student_manager_students_v2';
  static const _coursesKey = 'student_manager_courses_v1';

  Future<List<Student>> loadStudents() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_studentsKey) ?? prefs.getString('student_manager_students');
    if (raw == null) return [];
    try {
      final data = jsonDecode(raw) as List<dynamic>;
      return data.map((e) => Student.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) { return []; }
  }

  Future<void> saveStudents(List<Student> students) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_studentsKey, jsonEncode(students.map((s) => s.toJson()).toList()));
  }

  Future<List<Course>> loadCourses() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_coursesKey);
    if (raw == null) return [];
    try {
      final data = jsonDecode(raw) as List<dynamic>;
      return data.map((e) => Course.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) { return []; }
  }

  Future<void> saveCourses(List<Course> courses) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_coursesKey, jsonEncode(courses.map((c) => c.toJson()).toList()));
  }
}
