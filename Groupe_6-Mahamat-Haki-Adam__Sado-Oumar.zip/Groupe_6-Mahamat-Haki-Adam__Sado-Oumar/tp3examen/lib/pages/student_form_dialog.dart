import 'package:flutter/material.dart';
import '../models/student.dart';

class StudentFormDialog extends StatefulWidget {
  final Student? student;
  const StudentFormDialog({super.key, this.student});
  @override
  State<StudentFormDialog> createState() => _StudentFormDialogState();
}

class _StudentFormDialogState extends State<StudentFormDialog> {
  final _key = GlobalKey<FormState>();
  late final TextEditingController _first;
  late final TextEditingController _last;
  late final TextEditingController _phone;
  late final TextEditingController _email;
  late final TextEditingController _matricule;
  final _filieres = const ['Informatique', 'Mathématiques', 'Gestion', 'Comptabilité', 'Communication', 'Autre'];
  final _niveaux = const ['Débutant', '1ère année', '2ème année', '3ème année', 'Autre'];
  late String _filiere;
  late String _niveau;

  @override
  void initState() {
    super.initState(); final s = widget.student;
    _first = TextEditingController(text: s?.firstName ?? '');
    _last = TextEditingController(text: s?.lastName ?? '');
    _phone = TextEditingController(text: s?.phone ?? '');
    _email = TextEditingController(text: s?.email ?? '');
    _matricule = TextEditingController(text: s?.matricule ?? 'SM-${DateTime.now().year}-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}');
    _filiere = _filieres.contains(s?.filiere) ? s!.filiere : _filieres.first;
    _niveau = _niveaux.contains(s?.niveau) ? s!.niveau : _niveaux[1];
  }

  @override
  void dispose() { _first.dispose(); _last.dispose(); _phone.dispose(); _email.dispose(); _matricule.dispose(); super.dispose(); }

  String? _required(String? value, String label) => value == null || value.trim().length < 2 ? '$label doit contenir au moins 2 caractères' : null;

  void _submit() {
    if (!_key.currentState!.validate()) return;
    final s = widget.student;
    Navigator.of(context).pop(Student(
      id: s?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      firstName: _first.text.trim(), lastName: _last.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(),
      filiere: _filiere, niveau: _niveau, matricule: _matricule.text.trim(),
      dateInscription: s?.dateInscription ?? DateTime.now().toIso8601String().substring(0, 10), actif: s?.actif ?? true,
    ));
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.student == null ? 'Inscrire un étudiant' : 'Modifier l’étudiant'),
    content: SizedBox(width: 440, child: SingleChildScrollView(child: Form(key: _key, child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextFormField(controller: _first, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Prénom', prefixIcon: Icon(Icons.person_outline)), validator: (v) => _required(v, 'Le prénom')),
      const SizedBox(height: 12),
      TextFormField(controller: _last, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom', prefixIcon: Icon(Icons.badge_outlined)), validator: (v) => _required(v, 'Le nom')),
      const SizedBox(height: 12),
      TextFormField(controller: _matricule, decoration: const InputDecoration(labelText: 'Matricule', prefixIcon: Icon(Icons.confirmation_number_outlined)), validator: (v) => _required(v, 'Le matricule')),
      const SizedBox(height: 12),
      TextFormField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone', prefixIcon: Icon(Icons.phone_outlined))),
      const SizedBox(height: 12),
      TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)), validator: (v) { if (v == null || v.trim().isEmpty) return null; return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim()) ? null : 'Adresse email invalide'; }),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(initialValue: _filiere, isExpanded: true, decoration: const InputDecoration(labelText: 'Filière', prefixIcon: Icon(Icons.school_outlined)), items: _filieres.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) setState(() => _filiere = v); }),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(initialValue: _niveau, isExpanded: true, decoration: const InputDecoration(labelText: 'Niveau', prefixIcon: Icon(Icons.layers_outlined)), items: _niveaux.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) setState(() => _niveau = v); }),
    ])))),
    actions: [TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Annuler')), FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer'))],
  );
}
