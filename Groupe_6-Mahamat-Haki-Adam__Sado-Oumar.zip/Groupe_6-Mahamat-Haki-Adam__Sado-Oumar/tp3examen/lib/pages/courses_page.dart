import 'package:flutter/material.dart';

import '../models/course.dart';
import '../theme/app_colors.dart';

class CoursesPage extends StatefulWidget {
  final List<Course> courses;
  final Future<void> Function() onChanged;

  const CoursesPage({
    super.key,
    required this.courses,
    required this.onChanged,
  });

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  bool _saving = false;

  Future<void> _addCourse() async {
    final formKey = GlobalKey<FormState>();
    final titleController = TextEditingController();
    final teacherController = TextEditingController();
    final scheduleController = TextEditingController();
    final roomController = TextEditingController();

    Course? result;

    try {
      result = await showDialog<Course>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return AlertDialog(
            title: const Text('Nouveau cours'),
            content: SizedBox(
              width: 420,
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        controller: titleController,
                        autofocus: true,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          labelText: 'Nom du cours *',
                          prefixIcon: Icon(Icons.menu_book),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Saisissez le nom du cours';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: teacherController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'Enseignant',
                          prefixIcon: Icon(Icons.person_outline),
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: scheduleController,
                        decoration: const InputDecoration(
                          labelText: 'Horaire',
                          hintText: 'Ex. : lundi 08h-10h',
                          prefixIcon: Icon(Icons.schedule),
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: roomController,
                        decoration: const InputDecoration(
                          labelText: 'Salle',
                          prefixIcon: Icon(Icons.meeting_room_outlined),
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                },
                child: const Text('Annuler'),
              ),
              FilledButton.icon(
                onPressed: () {
                  if (!(formKey.currentState?.validate() ?? false)) {
                    return;
                  }

                  final course = Course(
                    id: DateTime.now().microsecondsSinceEpoch.toString(),
                    title: titleController.text.trim(),
                    teacher: teacherController.text.trim(),
                    schedule: scheduleController.text.trim(),
                    room: roomController.text.trim(),
                  );

                  Navigator.of(dialogContext).pop(course);
                },
                icon: const Icon(Icons.save_outlined),
                label: const Text('Enregistrer'),
              ),
            ],
          );
        },
      );
    } finally {
      titleController.dispose();
      teacherController.dispose();
      scheduleController.dispose();
      roomController.dispose();
    }

    if (!mounted || result == null) return;

    setState(() {
      widget.courses.add(result!);
      _saving = true;
    });

    try {
      await widget.onChanged();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cours enregistré avec succès.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;

      setState(() {
        widget.courses.removeWhere((course) => course.id == result!.id);
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de la sauvegarde : $error'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  Future<void> _deleteCourse(Course course) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Supprimer le cours ?'),
          content: Text(
            'Voulez-vous vraiment supprimer « ${course.title} » ?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
              child: const Text('Annuler'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(true);
              },
              child: const Text('Supprimer'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    final index = widget.courses.indexWhere(
      (item) => item.id == course.id,
    );

    if (index == -1) return;

    setState(() {
      widget.courses.removeAt(index);
      _saving = true;
    });

    try {
      await widget.onChanged();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cours supprimé avec succès.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;

      setState(() {
        widget.courses.insert(
          index.clamp(0, widget.courses.length),
          course,
        );
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de la suppression : $error'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
            children: [
              const Text(
                'Cours',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w800,
                  color: AppColors.navy,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${widget.courses.length} cours enregistré(s)',
                style: const TextStyle(
                  color: AppColors.muted,
                ),
              ),
              const SizedBox(height: 18),
              if (widget.courses.isEmpty)
                Container(
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Column(
                    children: [
                      Icon(
                        Icons.menu_book_outlined,
                        size: 44,
                        color: AppColors.muted,
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Aucun cours pour le moment',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Ajoutez les cours de votre établissement.',
                        style: TextStyle(
                          color: AppColors.muted,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              else
                ...widget.courses.map(
                  (course) => Card(
                    elevation: 0,
                    color: Colors.white,
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFE9EFFF),
                        child: Icon(
                          Icons.menu_book,
                          color: AppColors.blue,
                        ),
                      ),
                      title: Text(
                        course.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: AppColors.navy,
                        ),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Text(
                          '${course.teacher.isEmpty ? 'Enseignant non précisé' : course.teacher}\n'
                          '${course.schedule.isEmpty ? 'Horaire non précisé' : course.schedule}'
                          '${course.room.isEmpty ? '' : ' • ${course.room}'}',
                        ),
                      ),
                      isThreeLine: true,
                      trailing: IconButton(
                        tooltip: 'Supprimer le cours',
                        onPressed: _saving
                            ? null
                            : () => _deleteCourse(course),
                        icon: const Icon(
                          Icons.delete_outline,
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          if (_saving)
            const Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _saving ? null : _addCourse,
        backgroundColor: AppColors.blue,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Ajouter un cours'),
      ),
    );
  }
}