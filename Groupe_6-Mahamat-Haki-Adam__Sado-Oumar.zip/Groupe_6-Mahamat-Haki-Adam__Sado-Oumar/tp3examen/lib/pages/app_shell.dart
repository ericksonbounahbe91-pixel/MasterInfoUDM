import 'package:flutter/material.dart';
import '../data/app_repository.dart';
import '../models/student.dart';
import '../models/course.dart';
import '../theme/app_colors.dart';
import '../widgets/section_title.dart';
import 'home_page.dart';
import 'students_page.dart';
import 'courses_page.dart';
import 'settings_page.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final _repo = AppRepository();
  List<Student> _students = [];
  List<Course> _courses = [];
  bool _loading = true;
  int _index = 0;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final students = await _repo.loadStudents(); final courses = await _repo.loadCourses();
    if (!mounted) return; setState(() { _students = students; _courses = courses; _loading = false; });
  }
  Future<void> _saveStudents() => _repo.saveStudents(_students);
  Future<void> _saveCourses() => _repo.saveCourses(_courses);
  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _showNotifications() async {
    await showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle(title: 'Notifications'), const SizedBox(height: 12), ListTile(leading: const Icon(Icons.person_add_alt_1, color: AppColors.blue), title: const Text('Effectif des étudiants'), subtitle: Text('${_students.length} étudiant(s) enregistré(s)')), ListTile(leading: const Icon(Icons.menu_book_outlined, color: AppColors.purple), title: const Text('Cours'), subtitle: Text('${_courses.length} cours enregistré(s)')), if (_students.where((s) => !s.actif).isNotEmpty) ListTile(leading: const Icon(Icons.warning_amber, color: AppColors.orange), title: const Text('Étudiants suspendus'), subtitle: Text('${_students.where((s) => !s.actif).length} fiche(s) à vérifier'))]))));
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Accueil', 'Étudiants', 'Cours', 'Paramètres'];
    return Scaffold(
      appBar: AppBar(title: Row(children: [Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: AppColors.blue, borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.school_rounded, color: Colors.white, size: 22)), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Student Manager', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), Text(titles[_index], style: const TextStyle(fontSize: 11, color: AppColors.muted))])]), actions: [IconButton(tooltip: 'Notifications', onPressed: _showNotifications, icon: Badge(isLabelVisible: _students.isNotEmpty, label: Text('${_students.length}'), child: const Icon(Icons.notifications_none_rounded))), PopupMenuButton<String>(tooltip: 'Profil', onSelected: (v) { if (v == 'profile') _toast('Profil administrateur — à personnaliser.'); if (v == 'settings') setState(() => _index = 3); if (v == 'logout') _toast('La déconnexion sera ajoutée avec un système de comptes.'); }, itemBuilder: (_) => const [PopupMenuItem(value: 'profile', child: ListTile(leading: Icon(Icons.person_outline), title: Text('Mon profil'), contentPadding: EdgeInsets.zero)), PopupMenuItem(value: 'settings', child: ListTile(leading: Icon(Icons.settings_outlined), title: Text('Paramètres'), contentPadding: EdgeInsets.zero)), PopupMenuItem(value: 'logout', child: ListTile(leading: Icon(Icons.logout), title: Text('Déconnexion'), contentPadding: EdgeInsets.zero))]), const SizedBox(width: 5)]),
      body: _loading ? const Center(child: CircularProgressIndicator()) : IndexedStack(index: _index, children: [
        HomePage(students: _students, courses: _courses, onAddStudent: () => setState(() => _index = 1), onOpenStudent: (s) {}, onEditStudent: (s) => setState(() => _index = 1), onToggleStudent: (s) { setState(() => s.actif = !s.actif); _saveStudents(); }, onDeleteStudent: (s) { setState(() => _students.removeWhere((x) => x.id == s.id)); _saveStudents(); }, onViewStudents: () => setState(() => _index = 1)),
        StudentsPage(students: _students, onChanged: _saveStudents),
        CoursesPage(courses: _courses, onChanged: _saveCourses),
        const SettingsPage(),
      ]),
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (v) => setState(() => _index = v), destinations: const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Accueil'), NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people_rounded), label: 'Étudiants'), NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book_rounded), label: 'Cours'), NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Paramètres')]),
      floatingActionButton: _index == 0 ? FloatingActionButton.extended(onPressed: () => setState(() => _index = 1), backgroundColor: AppColors.blue, foregroundColor: Colors.white, icon: const Icon(Icons.person_add_alt_1), label: const Text('Ajouter')) : null,
    );
  }
}
