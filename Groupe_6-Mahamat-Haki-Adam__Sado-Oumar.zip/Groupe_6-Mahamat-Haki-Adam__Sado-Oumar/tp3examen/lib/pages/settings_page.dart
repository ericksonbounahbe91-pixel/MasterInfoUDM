import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Paramètres', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: AppColors.navy)), const SizedBox(height: 6), const Text('Informations et préférences de l’application', style: TextStyle(color: AppColors.muted)), const SizedBox(height: 20),
    Card(color: Colors.white, elevation: 0, child: const ListTile(leading: Icon(Icons.school_outlined, color: AppColors.blue), title: Text('Student Manager'), subtitle: Text('Application de gestion des étudiants'))),
    Card(color: Colors.white, elevation: 0, child: const ListTile(leading: Icon(Icons.storage_outlined, color: AppColors.blue), title: Text('Stockage local'), subtitle: Text('Les données sont enregistrées sur cet appareil avec SharedPreferences.'))),
    Card(color: Colors.white, elevation: 0, child: const ListTile(leading: Icon(Icons.info_outline, color: AppColors.blue), title: Text('Version'), subtitle: Text('1.0.0 • Projet pédagogique Flutter'))),
  ]);
}
