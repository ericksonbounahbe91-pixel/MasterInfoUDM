import 'package:flutter/material.dart';
import '../models/student.dart';
import '../models/course.dart';
import '../theme/app_colors.dart';
import '../widgets/section_title.dart';
import '../widgets/stat_card.dart';
import '../widgets/student_card.dart';

class HomePage extends StatelessWidget {
  final List<Student> students;
  final List<Course> courses;
  final VoidCallback onAddStudent;
  final void Function(Student) onOpenStudent;
  final void Function(Student) onEditStudent;
  final void Function(Student) onToggleStudent;
  final void Function(Student) onDeleteStudent;
  final VoidCallback onViewStudents;
  const HomePage({super.key, required this.students, required this.courses, required this.onAddStudent, required this.onOpenStudent, required this.onEditStudent, required this.onToggleStudent, required this.onDeleteStudent, required this.onViewStudents});

  @override
  Widget build(BuildContext context) {
    final active = students.where((s) => s.actif).length;
    final filieres = students.map((s) => s.filiere).toSet().length;
    return ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 100), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.blue, AppColors.blueLight]), borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ESPACE ADMINISTRATEUR', style: TextStyle(color: Color(0xFFDDE7FF), fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12), const Text('Bienvenue !', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8), const Text('Pilotez les inscriptions, les cours et le suivi des étudiants depuis un seul espace.', style: TextStyle(color: Colors.white, height: 1.5)),
        const SizedBox(height: 18), FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.blue), onPressed: onAddStudent, icon: const Icon(Icons.person_add_alt_1), label: const Text('Inscrire un étudiant')),
      ])),
      const SizedBox(height: 24), const SectionTitle(title: 'Vue d’ensemble', subtitle: 'Les indicateurs de votre établissement'),
      const SizedBox(height: 14), GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.25, children: [
        StatCard(title: 'Étudiants', value: '${students.length}', icon: Icons.people_alt_outlined, color: AppColors.blue),
        StatCard(title: 'Actifs', value: '$active', icon: Icons.check_circle_outline, color: AppColors.green),
        StatCard(title: 'Cours', value: '${courses.length}', icon: Icons.menu_book_outlined, color: AppColors.purple),
        StatCard(title: 'Filières', value: '$filieres', icon: Icons.school_outlined, color: AppColors.orange),
      ]),
      const SizedBox(height: 24), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const SectionTitle(title: 'Derniers étudiants'), TextButton(onPressed: onViewStudents, child: const Text('Tout voir'))]),
      if (students.isEmpty) Container(padding: const EdgeInsets.all(25), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: const Column(children: [Icon(Icons.people_outline, size: 42, color: AppColors.muted), SizedBox(height: 8), Text('Aucun étudiant enregistré'), Text('Ajoutez votre premier étudiant pour commencer.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted))]))
      else ...students.reversed.take(3).map((s) => StudentCard(student: s, onTap: () => onOpenStudent(s), onEdit: () => onEditStudent(s), onToggle: () => onToggleStudent(s), onDelete: () => onDeleteStudent(s))),
    ]);
  }
}
