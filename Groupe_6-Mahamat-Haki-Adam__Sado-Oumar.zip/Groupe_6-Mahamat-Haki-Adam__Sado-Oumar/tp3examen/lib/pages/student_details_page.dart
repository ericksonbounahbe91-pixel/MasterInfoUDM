import 'package:flutter/material.dart';
import '../models/student.dart';
import '../theme/app_colors.dart';

class StudentDetailsPage extends StatelessWidget {
  final Student student;
  const StudentDetailsPage({super.key, required this.student});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Détails de l’étudiant')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.blue, AppColors.blueLight]), borderRadius: BorderRadius.circular(24)), child: Column(children: [
        CircleAvatar(radius: 38, backgroundColor: Colors.white, child: Text(student.initials, style: const TextStyle(color: AppColors.blue, fontSize: 24, fontWeight: FontWeight.w800))),
        const SizedBox(height: 12), Text(student.fullName, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5), Text(student.matricule, style: const TextStyle(color: Colors.white70)),
      ])),
      const SizedBox(height: 18),
      _info(Icons.school_outlined, 'Filière', student.filiere),
      _info(Icons.layers_outlined, 'Niveau', student.niveau),
      _info(Icons.phone_outlined, 'Téléphone', student.phone.isEmpty ? 'Non renseigné' : student.phone),
      _info(Icons.email_outlined, 'Email', student.email.isEmpty ? 'Non renseigné' : student.email),
      _info(Icons.calendar_month_outlined, 'Date d’inscription', student.dateInscription),
      _info(Icons.verified_outlined, 'Statut', student.actif ? 'Actif' : 'Suspendu'),
      const SizedBox(height: 18), FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back), label: const Text('Retour à la liste')),
    ]),
  );

  Widget _info(IconData icon, String label, String value) => Card(elevation: 0, color: Colors.white, child: ListTile(leading: Icon(icon, color: AppColors.blue), title: Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12)), subtitle: Text(value, style: const TextStyle(color: AppColors.navy, fontWeight: FontWeight.w600))));
}
