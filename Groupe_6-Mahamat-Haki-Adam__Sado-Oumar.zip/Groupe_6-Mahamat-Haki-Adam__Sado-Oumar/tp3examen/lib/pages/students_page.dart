import 'package:flutter/material.dart';
import '../models/student.dart';
import '../theme/app_colors.dart';
import '../widgets/student_card.dart';
import 'student_form_dialog.dart';
import 'student_details_page.dart';

class StudentsPage extends StatefulWidget {
  final List<Student> students;
  final Future<void> Function() onChanged;
  const StudentsPage({super.key, required this.students, required this.onChanged});
  @override
  State<StudentsPage> createState() => _StudentsPageState();
}

class _StudentsPageState extends State<StudentsPage> {
  final _search = TextEditingController();
  String _query = '';
  @override
  void dispose() { _search.dispose(); super.dispose(); }

  List<Student> get _filtered => widget.students.where((s) => '${s.fullName} ${s.phone} ${s.email} ${s.filiere} ${s.matricule}'.toLowerCase().contains(_query.trim().toLowerCase())).toList()..sort((a,b) => a.fullName.compareTo(b.fullName));

  Future<void> _addOrEdit({Student? student}) async {
    final result = await showDialog<Student>(context: context, barrierDismissible: false, builder: (_) => StudentFormDialog(student: student));
    if (!mounted || result == null) return;
    setState(() { final i = widget.students.indexWhere((s) => s.id == result.id); if (i < 0) { widget.students.add(result); } else { widget.students[i] = result; } });
    await widget.onChanged();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(student == null ? 'Étudiant enregistré avec succès.' : 'Fiche mise à jour.')));
  }

  Future<void> _delete(Student student) async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Supprimer cet étudiant ?'), content: Text('La fiche de ${student.fullName} sera supprimée de cet appareil.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer'))]));
    if (yes != true || !mounted) return;
    setState(() => widget.students.removeWhere((s) => s.id == student.id)); await widget.onChanged();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Étudiant supprimé.')));
  }

  Future<void> _toggle(Student s) async { setState(() => s.actif = !s.actif); await widget.onChanged(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.actif ? 'Étudiant réactivé.' : 'Étudiant suspendu.'))); }

  @override
  Widget build(BuildContext context) {
    final students = _filtered;
    return Scaffold(backgroundColor: Colors.transparent, body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(18, 8, 18, 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Nos étudiants', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: AppColors.navy)),
        const SizedBox(height: 4), Text('${widget.students.length} fiche(s) enregistrée(s)', style: const TextStyle(color: AppColors.muted)),
        const SizedBox(height: 14), TextField(controller: _search, onChanged: (v) => setState(() => _query = v), decoration: InputDecoration(hintText: 'Rechercher nom, matricule, téléphone...', prefixIcon: const Icon(Icons.search), suffixIcon: _query.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() => _query = ''); }, icon: const Icon(Icons.close)))),
      ])),
      Expanded(child: students.isEmpty ? Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.people_outline, size: 48, color: AppColors.muted), const SizedBox(height: 12), Text(_query.isEmpty ? 'Aucun étudiant pour le moment' : 'Aucun résultat trouvé', style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12), FilledButton.icon(onPressed: () => _addOrEdit(), icon: const Icon(Icons.add), label: const Text('Ajouter un étudiant'))]))) : ListView.separated(padding: const EdgeInsets.fromLTRB(18, 0, 18, 100), itemCount: students.length, separatorBuilder: (context, index) => const SizedBox(height: 8), itemBuilder: (_, i) { final s = students[i]; return StudentCard(student: s, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudentDetailsPage(student: s))), onEdit: () => _addOrEdit(student: s), onToggle: () => _toggle(s), onDelete: () => _delete(s)); })),
    ]), floatingActionButton: FloatingActionButton.extended(onPressed: () => _addOrEdit(), backgroundColor: AppColors.blue, foregroundColor: Colors.white, icon: const Icon(Icons.person_add_alt_1), label: const Text('Ajouter')));
  }
}
