class Student {
  final String id;
  String firstName;
  String lastName;
  String phone;
  String email;
  String filiere;
  String niveau;
  String matricule;
  final String dateInscription;
  bool actif;

  Student({
    required this.id,
    required this.firstName,
    required this.lastName,
    this.phone = '',
    this.email = '',
    required this.filiere,
    required this.niveau,
    required this.matricule,
    required this.dateInscription,
    this.actif = true,
  });

  String get fullName => '$firstName $lastName'.trim();
  String get initials => '${firstName.isNotEmpty ? firstName[0] : ''}${lastName.isNotEmpty ? lastName[0] : ''}'.toUpperCase();

  Map<String, dynamic> toJson() => {
        'id': id, 'firstName': firstName, 'lastName': lastName,
        'phone': phone, 'email': email, 'filiere': filiere,
        'niveau': niveau, 'matricule': matricule,
        'dateInscription': dateInscription, 'actif': actif,
      };

  factory Student.fromJson(Map<String, dynamic> json) => Student(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        firstName: json['firstName'] as String? ?? json['prenom'] as String? ?? '',
        lastName: json['lastName'] as String? ?? json['nom'] as String? ?? '',
        phone: json['phone'] as String? ?? json['telephone'] as String? ?? '',
        email: json['email'] as String? ?? '',
        filiere: json['filiere'] as String? ?? 'Informatique',
        niveau: json['niveau'] as String? ?? '1ère année',
        matricule: json['matricule'] as String? ?? 'SM-${DateTime.now().year}',
        dateInscription: json['dateInscription'] as String? ?? '',
        actif: json['actif'] as bool? ?? true,
      );
}
