class Course {
  final String id;
  String title;
  String teacher;
  String schedule;
  String room;
  bool active;

  Course({required this.id, required this.title, required this.teacher, required this.schedule, required this.room, this.active = true});

  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'teacher': teacher, 'schedule': schedule, 'room': room, 'active': active};
  factory Course.fromJson(Map<String, dynamic> json) => Course(
    id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
    title: json['title'] as String? ?? '', teacher: json['teacher'] as String? ?? '',
    schedule: json['schedule'] as String? ?? '', room: json['room'] as String? ?? '',
    active: json['active'] as bool? ?? true,
  );
}
