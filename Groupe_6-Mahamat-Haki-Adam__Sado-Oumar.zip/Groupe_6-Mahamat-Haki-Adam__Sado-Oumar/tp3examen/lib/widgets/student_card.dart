import 'package:flutter/material.dart';
import '../models/student.dart';
import '../theme/app_colors.dart';

class StudentCard extends StatelessWidget {
  final Student student;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onToggle;
  final VoidCallback onDelete;
  const StudentCard({super.key, required this.student, required this.onTap, required this.onEdit, required this.onToggle, required this.onDelete});

  @override
  Widget build(BuildContext context) => Card(
    elevation: 0, color: Colors.white,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: AppColors.border)),
    child: ListTile(
      onTap: onTap, contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      leading: CircleAvatar(backgroundColor: AppColors.blue.withValues(alpha: .12), child: Text(student.initials.isEmpty ? '?' : student.initials, style: const TextStyle(color: AppColors.blue, fontWeight: FontWeight.w800))),
      title: Text(student.fullName, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text('${student.filiere} • ${student.niveau}\n${student.matricule}', maxLines: 2),
      isThreeLine: true,
      trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') onEdit(); if (v == 'status') onToggle(); if (v == 'delete') onDelete(); }, itemBuilder: (_) => [
        const PopupMenuItem(value: 'edit', child: Text('Modifier la fiche')),
        PopupMenuItem(value: 'status', child: Text(student.actif ? 'Suspendre' : 'Réactiver')),
        const PopupMenuItem(value: 'delete', child: Text('Supprimer')),
      ]),
    ),
  );
}
