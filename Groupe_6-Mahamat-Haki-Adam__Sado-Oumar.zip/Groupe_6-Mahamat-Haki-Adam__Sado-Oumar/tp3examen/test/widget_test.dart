import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Vérifier que le test Flutter fonctionne', () {
    expect(2 + 2, 4);
  });
}