<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccueilController;
use App\Http\Controllers\InscriptionController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Admin\InscriptionAdminController;

// Page d'accueil
Route::get('/', [AccueilController::class, 'index'])
    ->name('accueil');

// Formulaire public d'inscription
Route::get('/inscription', [InscriptionController::class, 'create'])
    ->name('inscriptions.create');

Route::post('/inscription', [InscriptionController::class, 'store'])
    ->name('inscriptions.store');

// Connexion administrateur
Route::get('/admin/login', [AuthController::class, 'showLogin'])
    ->name('login');

Route::post('/admin/login', [AuthController::class, 'login'])
    ->name('login.submit');

// Pages réservées aux administrateurs connectés
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/admin/inscriptions', [
        InscriptionAdminController::class,
        'index'
    ])->name('admin.inscriptions.index');

    Route::post('/admin/logout', [AuthController::class, 'logout'])
        ->name('admin.logout');

Route::patch('/admin/inscriptions/{inscription}/statut', [
    InscriptionAdminController::class,
    'updateStatut'
])->name('admin.inscriptions.statut');
});
