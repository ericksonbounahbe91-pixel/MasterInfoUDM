
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des inscriptions - YaraïDigital</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #fffaf0;
            color: #222;
        }

        header {
            background: #151515;
            color: white;
            padding: 22px 5%;
            border-bottom: 5px solid #f5c542;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            color: #f5c542;
            font-size: 24px;
        }

        header p { margin-bottom: 0; }

        button, .bouton {
            padding: 11px 16px;
            border: 0;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }

        .deconnexion {
            background: #d62828;
            color: white;
        }

        main { padding: 30px 5%; }

        .resume, .recherche {
            background: white;
            padding: 22px;
            border-radius: 10px;
            margin-bottom: 22px;
            box-shadow: 0 3px 12px #00000010;
        }

        .resume h2 { margin-top: 0; }

        .filtres {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: end;
        }

        .champ {
            flex: 1;
            min-width: 190px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background: white;
        }

        .rechercher {
            background: #f5c542;
            color: #151515;
        }

        .reinitialiser {
            background: #eee;
            color: #222;
            display: inline-block;
            margin-top: 12px;
        }

        .table-conteneur {
            overflow-x: auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 12px #00000010;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #f5c542;
            color: #151515;
        }

        tr:hover td { background: #fff8df; }

        .statut {
            display: inline-block;
            padding: 5px 9px;
            background: #fff0c2;
            border-radius: 5px;
        }

        .vide {
            padding: 25px;
            text-align: center;
        }

        .pagination {
            padding: 20px;
            background: white;
        }

        .retour {
            display: inline-block;
            margin-top: 25px;
            color: #c62828;
            text-decoration: none;
            font-weight: bold;
        }

        @media (max-width: 600px) {
            main { padding: 20px 4%; }
            header h1 { font-size: 20px; }
            .filtres button, .filtres .bouton { width: 100%; text-align: center; }
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>YaraïDigital du Tchad</h1>
        <p>Espace d'administration</p>
    </div>

    <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="deconnexion" type="submit">Se déconnecter</button>
    </form>
</header>

<main>
    <section class="resume">
        <h2>Gestion des inscriptions</h2>
        <p>
            Résultats affichés :
            <strong><?php echo e($inscriptions->count()); ?></strong>
            sur <?php echo e($inscriptions->total()); ?> résultat(s) correspondant aux critères.
        </p>
    </section>

    <section class="recherche">
        <h3>Rechercher une inscription</h3>

        <form method="GET" action="<?php echo e(route('admin.inscriptions.index')); ?>">
            <div class="filtres">
                <div class="champ">
                    <label for="q">Nom ou téléphone</label>
                    <input
                        type="search"
                        id="q"
                        name="q"
                        value="<?php echo e($recherche); ?>"
                        placeholder="Ex. : Mahamat ou 99..."
                    >
                </div>

                <div class="champ">
                    <label for="formation">Formation</label>
                    <select id="formation" name="formation">
                        <option value="">Toutes les formations</option>
                        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>"
                                <?php if($formationSelectionnee === $item): echo 'selected'; endif; ?>>
                                <?php echo e($item); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button class="rechercher" type="submit">Rechercher</button>
            </div>

            <a class="bouton reinitialiser"
               href="<?php echo e(route('admin.inscriptions.index')); ?>">
                Réinitialiser les filtres
            </a>
        </form>
    </section>

    <div class="table-conteneur">
        <?php if($inscriptions->isEmpty()): ?>
            <div class="vide">
                <p>Aucune inscription ne correspond à votre recherche.</p>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Nom complet</th>
                        <th>Téléphone</th>
                        <th>E-mail</th>
                        <th>Formation</th>
                        <th>Statut</th>
                        <th>Date</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $inscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inscription->nom); ?></td>
                            <td><?php echo e($inscription->telephone); ?></td>
                            <td><?php echo e($inscription->email ?: 'Non renseigné'); ?></td>
                            <td><?php echo e($inscription->formation); ?></td>

                            <td>
                                <form method="POST"
                                      action="<?php echo e(route('admin.inscriptions.statut', $inscription)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>

                                    <select name="statut" aria-label="Statut de l'inscription"
                                            onchange="this.form.requestSubmit()">
                                        <option value="À traiter"
                                            <?php if(($inscription->statut ?? 'À traiter') === 'À traiter'): echo 'selected'; endif; ?>>
                                            À traiter
                                        </option>
                                        <option value="En cours"
                                            <?php if($inscription->statut === 'En cours'): echo 'selected'; endif; ?>>
                                            En cours
                                        </option>
                                        <option value="Acceptée"
                                            <?php if($inscription->statut === 'Acceptée'): echo 'selected'; endif; ?>>
                                            Acceptée
                                        </option>
                                    </select>
                                </form>
                            </td>

                            <td><?php echo e($inscription->created_at?->format('d/m/Y H:i') ?? '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="pagination">
                <?php echo e($inscriptions->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    <a class="retour" href="<?php echo e(route('accueil')); ?>">← Retour à l'accueil</a>
</main>

</body>
</html>
<?php /**PATH /home/hakimi/makalli/www/yarai_laravel/resources/views/admin/inscriptions/index.blade.php ENDPATH**/ ?>