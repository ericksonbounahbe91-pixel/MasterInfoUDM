
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inscription | YaraïDigital du Tchad</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #fffaf0;
            color: #222;
        }

        .conteneur {
            max-width: 650px;
            margin: auto;
        }

        header {
            background: #151515;
            color: white;
            text-align: center;
            padding: 25px 15px;
            border-bottom: 5px solid #f5c542;
            border-radius: 12px 12px 0 0;
        }

        header h1 {
            margin: 0 0 8px;
            color: #f5c542;
        }

        .formulaire {
            background: white;
            padding: 30px;
            border-radius: 0 0 12px 12px;
            box-shadow: 0 5px 20px #00000012;
        }

        label {
            display: block;
            margin: 17px 0 7px;
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font: inherit;
        }

        input:focus, select:focus, textarea:focus {
            outline: 2px solid #f5c542;
            border-color: #d62828;
        }

        button {
            width: 100%;
            margin-top: 24px;
            padding: 14px;
            background: #d62828;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #ad1f1f;
        }

        .succes {
            background: #e5f7e8;
            color: #17652b;
            padding: 12px;
            border-radius: 6px;
        }

        .erreur {
            color: #c62828;
            font-size: 14px;
            margin-top: 5px;
        }

        .retour {
            display: inline-block;
            margin-top: 20px;
            color: #b51f25;
            text-decoration: none;
        }

        footer {
            text-align: center;
            margin-top: 25px;
            color: #555;
        }

        @media (max-width: 480px) {
            .formulaire {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
<div class="conteneur">

    <header>
        <h1>YaraïDigital</h1>
        <p>Formulaire d'inscription aux formations</p>
    </header>

    <div class="formulaire">

        <?php if(session('success')): ?>
            <p class="succes"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="erreur">
                <p>Veuillez corriger les informations suivantes :</p>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($erreur); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('inscriptions.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label for="nom">Nom complet *</label>
            <input
                type="text"
                id="nom"
                name="nom"
                value="<?php echo e(old('nom')); ?>"
                maxlength="150"
                autocomplete="name"
                required
            >

            <label for="telephone">Téléphone *</label>
            <input
                type="tel"
                id="telephone"
                name="telephone"
                value="<?php echo e(old('telephone')); ?>"
                maxlength="30"
                autocomplete="tel"
                required
            >

            <label for="email">Adresse e-mail (facultatif)</label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                autocomplete="email"
            >

            <label for="formation">Formation souhaitée *</label>
            <select id="formation" name="formation" required>
                <option value="">-- Choisir une formation --</option>

                <?php $__currentLoopData = [
                    'Word',
                    'Excel',
                    'PowerPoint',
                    'Développement web',
                    'Intelligence artificielle'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($formation); ?>"
                        <?php if(old('formation') === $formation): echo 'selected'; endif; ?>
                    >
                        <?php echo e($formation); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="message">Message complémentaire (facultatif)</label>
            <textarea
                id="message"
                name="message"
                rows="4"
                maxlength="1000"
            ><?php echo e(old('message')); ?></textarea>

            <button type="submit">Envoyer mon inscription</button>
        </form>

        <a class="retour" href="<?php echo e(route('accueil')); ?>">
            ← Retour à l'accueil
        </a>
    </div>

    <footer>
        YaraïDigital du Tchad — Le numérique pour tous.
    </footer>

</div>
</body>
</html>
<?php /**PATH /home/hakimi/makalli/www/yarai_laravel/resources/views/inscriptions/create.blade.php ENDPATH**/ ?>