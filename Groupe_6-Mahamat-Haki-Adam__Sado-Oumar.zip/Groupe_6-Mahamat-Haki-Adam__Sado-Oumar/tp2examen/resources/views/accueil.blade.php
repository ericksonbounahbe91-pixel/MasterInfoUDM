<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="YaraïDigital du Tchad : formations informatiques, développement web, communication numérique et maintenance informatique.">

    <title>{{ $nom }} | Le numérique pour tous</title>

    <style>
        :root {
            --jaune: #f5c542;
            --rouge: #d62828;
            --noir: #151515;
            --blanc: #ffffff;
            --fond: #fffaf0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: Arial, sans-serif;
            color: #242424;
            background: var(--fond);
            line-height: 1.6;
        }

        /* En-tête */
        header {
            background: var(--noir);
            color: var(--blanc);
            padding: 18px 7%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }

        .identite {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo {
            width: 65px;
            height: 65px;
            object-fit: contain;
            background: white;
            border-radius: 8px;
            padding: 3px;
            flex-shrink: 0;
        }

        header h2 {
            color: var(--jaune);
            font-size: 25px;
        }

        header h2 span {
            color: var(--rouge);
        }

        /* Navigation */
        nav {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 20px;
        }

        nav a {
            color: var(--blanc);
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        nav a:hover {
            color: var(--jaune);
        }

        nav .lien-inscription {
            background: var(--rouge);
            color: var(--blanc);
            padding: 10px 16px;
            border-radius: 6px;
        }

        nav .lien-inscription:hover {
            background: var(--jaune);
            color: var(--noir);
        }

        /* Section d'accueil */
        .hero {
            text-align: center;
            padding: 100px 20px;
            background: linear-gradient(135deg, #171717, #3b1515);
            color: var(--blanc);
            border-bottom: 6px solid var(--jaune);
        }

        .hero h1 {
            font-size: clamp(30px, 5vw, 52px);
            line-height: 1.2;
            margin-bottom: 20px;
        }

        .hero h1 span {
            color: var(--jaune);
        }

        .hero p {
            max-width: 720px;
            margin: 0 auto 30px;
            font-size: 18px;
        }

        /* Boutons */
        .bouton {
            display: inline-block;
            padding: 13px 24px;
            background: var(--rouge);
            color: var(--blanc);
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: 0.3s;
            margin: 5px;
        }

        .bouton:hover {
            background: var(--jaune);
            color: var(--noir);
            transform: translateY(-2px);
        }

        .bouton-inscription {
            background: var(--jaune);
            color: var(--noir);
        }

        .bouton-inscription:hover {
            background: var(--rouge);
            color: var(--blanc);
        }

        /* Services */
        .services {
            padding: 65px 7%;
            text-align: center;
        }

        .services h2 {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .sous-titre {
            max-width: 650px;
            margin: 0 auto;
            color: #666;
        }

        .cartes {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 24px;
            margin-top: 35px;
        }

        .carte {
            background: var(--blanc);
            padding: 30px 22px;
            border-radius: 12px;
            border-bottom: 4px solid var(--jaune);
            box-shadow: 0 5px 20px #0000000d;
            transition: 0.3s;
        }

        .carte:hover {
            transform: translateY(-5px);
            border-bottom-color: var(--rouge);
        }

        .numero {
            width: 48px;
            height: 48px;
            display: grid;
            place-items: center;
            margin: 0 auto 15px;
            border-radius: 50%;
            background: var(--jaune);
            color: var(--noir);
            font-weight: bold;
            font-size: 20px;
        }

        .carte h3 {
            margin-bottom: 10px;
            color: var(--rouge);
        }

        /* Pied de page */
        footer {
            background: var(--noir);
            color: var(--blanc);
            text-align: center;
            padding: 28px 15px;
        }

        footer strong {
            color: var(--jaune);
        }

        /* Téléphones et petits écrans */
        @media (max-width: 600px) {
            header {
                justify-content: center;
                text-align: center;
                padding: 20px 15px;
            }

            .identite {
                justify-content: center;
            }

            .logo {
                width: 50px;
                height: 50px;
            }

            nav {
                justify-content: center;
                gap: 12px;
            }

            nav a {
                font-size: 14px;
            }

            .hero {
                padding: 65px 18px;
            }

            .services {
                padding: 45px 18px;
            }

            .services h2 {
                font-size: 27px;
            }
        }
        .surtitre {
            color: var(--jaune);
            font-weight: bold;
            letter-spacing: 3px;
            margin-bottom: 15px;
        }

        .hero h1 span {
            display: block;
            color: var(--jaune);
        }

        .hero-boutons {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .bouton-secondaire {
            background: transparent;
            border: 2px solid var(--jaune);
            color: var(--blanc);
        }

        .bouton-secondaire:hover {
            background: var(--jaune);
            color: var(--noir);
        }
        .contact {
            padding: 65px 7%;
            text-align: center;
            background: #fff1cc;
        }

        .contact h2 {
            font-size: 32px;
            margin-bottom: 15px;
        }

        .contact > p:not(.surtitre) {
            max-width: 650px;
            margin: 0 auto 20px;
            color: #555;
        }

        .contact-actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 25px;
        }

        .bouton-contact {
            background: var(--noir);
            color: var(--blanc);
        }

        .bouton-contact:hover {
            background: var(--rouge);
            color: var(--blanc);
        }

        footer p {
            margin: 5px 0;
        }

        @media (max-width: 600px) {
            .contact {
                padding: 45px 18px;
            }

            .contact h2 {
                font-size: 27px;
            }
        }
        .lien-connexion {
            border: 2px solid var(--jaune);
            color: var(--blanc);
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        nav .lien-connexion:hover {
            background: var(--jaune);
            color: var(--noir);
        }
        .image-accueil {
            width: 100%;
            max-width: 600px;
            height: 320px;
            object-fit: cover;
            border-radius: 12px;
            display: block;
            margin: 20px auto;
        }


        /* Carrousel en plein écran */
        .carrousel-accueil {
            position: relative;
            width: 100%;
            height: 100vh;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        /* Images du carrousel */
        .image-accueil {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            display: block;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        /* Image visible */
        .image-accueil.active {
            opacity: 1;
        }


        body {
            margin: 0 !important;
            padding: 0 !important;
            width: 100%;
        }

        /* Image sur toute la largeur de l'écran */
        .carrousel-accueil {
            position: relative;
            width: 100vw !important;
            max-width: 100vw !important;
            height: 100vh;
            margin: 0 !important;
            padding: 0 !important;
            left: 50%;
            transform: translateX(-50%);
            overflow: hidden;
        }

        /* Chaque image remplit tout le carrousel */
        .carrousel-accueil .image-accueil {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            max-width: none;
            object-fit: cover;
            display: block;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        .carrousel-accueil .image-accueil.active {
            opacity: 1;
        }

        
    </style>
</head>

<body>

    <!-- En-tête avec logo et navigation -->
    <header>
        <div class="identite">
            <img
                src="{{ asset('images/logo.png') }}"
                alt="Logo YaraïDigital du Tchad"
                class="logo"
            >

            <h2>Yaraï<span> Digital Du Tchad</span></h2>
        </div>

        <nav>
            <a href="#accueil" class="lien-accueil">Accueil</a>

            <a href="#services" class="lien-services">Services</a>
            <a href="#contact" class="lien-contact">Contact</a>
            <a href="{{ route('login') }}" class="lien-connexion">
                <i class="fas fa-sign-in-alt"></i> Connexion
            </a>

        </nav>
    </header>

    <main>

        <section class="hero" id="accueil">
            <p class="surtitre">YARAÏDIGITAL DU TCHAD</p>

            <h1>
                Le numérique pour tous,
                <span>les compétences pour demain.</span>
            </h1>

            <p>
                Nous accompagnons les jeunes, les étudiants,
                les entrepreneurs et les professionnels dans
                l'apprentissage du numérique, le développement
                de leurs compétences et la réalisation de leurs projets.
            </p>

            <div class="hero-boutons">
                <a class="bouton bouton-inscription"
                   href="{{ url('/inscription') }}">
                    Rejoindre nos formations
                </a>

                <a class="bouton bouton-secondaire"
                   href="#services">
                    Découvrir nos services
                </a>
            </div>
          

            <!-- Carrousel des images d'accueil -->
        <div class="container-fluid p-0">
            <div class="carrousel-accueil">

                <img
                    src="{{ asset('images/accueil.jpg') }}"
                    alt="Formation chez YaraïDigital du Tchad"
                    class="image-accueil active"
                >

                <img
                    src="{{ asset('images/accueil1.jpg') }}"
                    alt="Formation chez YaraïDigital du Tchad"
                    class="image-accueil"
                >

                <img
                    src="{{ asset('images/accueil2.jpg') }}"
                    alt="Formation chez YaraïDigital du Tchad"
                    class="image-accueil"
                >

                <img
                    src="{{ asset('images/accueil3.jpg') }}"
                    alt="Formation chez YaraïDigital du Tchad"
                    class="image-accueil"
                >

            </div>
        </div>
             
            
        </section>
        <!-- Services -->

        <section class="services" id="services">
            <p class="surtitre">NOS SOLUTIONS NUMÉRIQUES</p>

            <h2>Découvrez nos services</h2>

            <p class="sous-titre">
                Des formations pratiques et des solutions adaptées
                aux besoins des jeunes, des étudiants et des organisations.
            </p>

            <div class="cartes">

                <article class="carte">
                    <div class="numero">01</div>
                    <h3>Formation informatique</h3>
                    <p>
                        Apprenez à utiliser Word, Excel, PowerPoint,
                        Internet et les outils numériques essentiels
                        pour vos études et votre travail.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>

                </article>

                <article class="carte">
                    <div class="numero">02</div>
                    <h3>Développement web</h3>
                    <p>
                        Découvrez HTML, CSS, JavaScript et les bases
                        de la création de sites web pour transformer
                        vos idées en projets numériques.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>
                </article>

                <article class="carte">
                    <div class="numero">03</div>
                    <h3>Intelligence artificielle</h3>
                    <p>
                        Découvrez comment utiliser les outils d'IA
                        pour apprendre, créer du contenu, gagner
                        du temps et améliorer votre productivité.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>
                </article>

                <article class="carte">
                    <div class="numero">04</div>
                    <h3>Maintenance informatique</h3>
                    <p>
                        Familiarisez-vous avec le diagnostic,
                        l'entretien des ordinateurs et les notions
                        essentielles de dépannage informatique.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>
                </article>

                <article class="carte">
                    <div class="numero">05</div>
                    <h3>Communication numérique</h3>
                    <p>
                        Apprenez à mieux communiquer en ligne,
                        valoriser vos activités et développer
                        votre présence sur les plateformes numériques.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>
                </article>

                <article class="carte">
                    <div class="numero">06</div>
                    <h3>Accompagnement numérique</h3>
                    <p>
                        Faites avancer vos projets grâce à un
                        accompagnement adapté à vos besoins
                        informatiques et numériques.
                    </p>
                    <a href="{{ url('/inscription') }}" class="bouton">
                        S'inscrire
                    </a>
                </article>

            </div>
                @auth
                    <a href="{{ url('/admin/inscriptions') }}"
                       class="lien-inscription">
                        <i class="fas fa-users"></i>
                        Voir les inscrits
                    </a>
                @endauth
        </section>

        <section class="contact" id="contact">
            <p class="surtitre">RESTONS EN CONTACT</p>

            <h2>Un projet ou une question ?</h2>

            <p>
                Tu souhaites suivre une formation, obtenir des
                renseignements ou collaborer avec YaraïDigital ?
                Nous serons heureux d'échanger avec toi.
            </p>

            <div class="contact-actions">
                <a class="bouton bouton-inscription"
                   href="{{ url('/inscription') }}">
                    Demander une inscription
                </a>

                <a class="bouton bouton-contact"
                   href="https://wa.me/23599875012"
                   target="_blank"
                   rel="noopener noreferrer">
                    Nous écrire sur WhatsApp
                </a>
            </div>
        </section>

        <footer>
            <p>
                <strong>{{ $nom }}</strong>
                — Le numérique pour tous.
            </p>

            <p>
                Formation, innovation et accompagnement numérique au Tchad.
            </p>

            <p>
                &copy; {{ date('Y') }} {{ $nom }}.
                Tous droits réservés.
            </p>
        </footer>

    </main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const images = document.querySelectorAll(
        '.carrousel-accueil .image-accueil'
    );

    let index = 0;

    if (images.length > 1) {
        setInterval(function () {
            images[index].classList.remove('active');

            index = (index + 1) % images.length;

            images[index].classList.add('active');
        }, 4000);
    }
});
</script>

</script>

</body>
</html>
