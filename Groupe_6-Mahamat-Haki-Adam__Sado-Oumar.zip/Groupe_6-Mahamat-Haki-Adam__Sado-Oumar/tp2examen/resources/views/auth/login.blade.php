<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion administrateur - YaraïDigital</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .login-box {
            width: 100%;
            max-width: 420px;
            padding: 32px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 25px #00000015;
        }

        h1 { text-align: center; font-size: 25px; }
        .brand { color: #d62828; }
        p { color: #555; text-align: center; }

        label {
            display: block;
            margin: 18px 0 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            width: 100%;
            margin-top: 24px;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: #e6b800;
            color: #111;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover { background: #d62828; color: white; }
        .error { color: #c00; margin-top: 12px; }
        .back { display: block; margin-top: 20px; color: #333; text-align: center; }
    </style>
</head>
<body>
    <main class="login-box">
        <h1><span class="brand">YaraïDigital</span></h1>
        <p>Espace réservé à l'administration</p>

        @if ($errors->any())
            <div class="error">
                @foreach ($errors->all() as $error)
                    <p class="error">{{ $error }}</p>
                @endforeach
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <label for="email">Adresse e-mail</label>
            <input
                id="email"
                type="email"
                name="email"
                value="{{ old('email') }}"
                required
                autocomplete="username"
            >

            <label for="password">Mot de passe</label>
            <input
                id="password"
                type="password"
                name="password"
                required
                autocomplete="current-password"
            >

            <button type="submit">Se connecter</button>
        </form>

        <a class="back" href="{{ route('accueil') }}">Retour à l'accueil</a>
    </main>
</body>
</html>
