<?php
namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class CreateAdmin extends Command
{
    protected $signature = 'app:create-admin';

    protected $description = 'Créer ou promouvoir un compte administrateur';

    public function handle(): int
    {
        $email = $this->ask('Adresse e-mail de l’administrateur');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Adresse e-mail invalide.');
            return self::FAILURE;
        }

        $password = $this->secret('Choisissez un mot de passe');

        if (!$password || strlen($password) < 12) {
            $this->error('Le mot de passe doit contenir au moins 12 caractères.');
            return self::FAILURE;
        }

        $user = User::where('email', $email)->first();

        if (!$user) {
            $name = $this->ask('Nom de l’administrateur');

            $user = new User();
            $user->name = $name;
            $user->email = $email;
        }

        $user->password = Hash::make($password);
        $user->is_admin = true;
        $user->save();

        $this->info('Compte administrateur créé ou mis à jour avec succès.');

        return self::SUCCESS;
    }
}
