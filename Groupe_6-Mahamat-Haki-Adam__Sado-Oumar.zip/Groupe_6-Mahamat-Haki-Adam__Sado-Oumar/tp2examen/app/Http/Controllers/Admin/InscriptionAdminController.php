<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Inscription;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class InscriptionAdminController extends Controller
{
    public function index(Request $request)
    {
        $recherche = trim((string) $request->query('q', ''));
        $formation = (string) $request->query('formation', '');

        $formations = [
            'Word',
            'Excel',
            'PowerPoint',
            'Développement web',
            'Intelligence artificielle',
        ];

        $requete = Inscription::query();

        if ($recherche !== '') {
            $requete->where(function ($query) use ($recherche) {
                $query->where('nom', 'like', '%' . $recherche . '%')
                    ->orWhere('telephone', 'like', '%' . $recherche . '%');
            });
        }

        if (in_array($formation, $formations, true)) {
            $requete->where('formation', $formation);
        } else {
            $formation = '';
        }

        $inscriptions = $requete->latest()->paginate(10)->withQueryString();

        return view('admin.inscriptions.index', [
            'inscriptions' => $inscriptions,
            'recherche' => $recherche,
            'formationSelectionnee' => $formation,
            'formations' => $formations,
        ]);
    }

    public function updateStatut(Request $request, Inscription $inscription)
    {
        $donnees = $request->validate([
            'statut' => [
                'required',
                Rule::in(['À traiter', 'En cours', 'Acceptée']),
            ],
        ]);

        $inscription->statut = $donnees['statut'];
        $inscription->save();

        return redirect()
            ->route('admin.inscriptions.index')
            ->with('success', 'Le statut de l’inscription a été mis à jour.');
    }
}
