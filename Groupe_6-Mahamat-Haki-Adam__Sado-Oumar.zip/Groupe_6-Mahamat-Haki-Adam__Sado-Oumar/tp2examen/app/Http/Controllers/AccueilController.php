<?php

namespace App\Http\Controllers;

class AccueilController extends Controller
{
    public function index()
    {
        $nom = 'YaraïDigital du Tchad';

        $slogan = 'Informatique et communication pour tous';

        $services = [
            'Développement web',
            'Formation informatique',
            'Communication numérique',
            'Maintenance informatique'
        ];

        return view('accueil', [
            'nom' => $nom,
            'slogan' => $slogan,
            'services' => $services
        ]);
    }
}
