<?php
namespace App\Http\Controllers;

use App\Models\Inscription;
use Illuminate\Http\Request;

class InscriptionController extends Controller
{
    public function create()
    {
        return view('inscriptions.create');
    }

    public function store(Request $request)
    {
        $donnees = $request->validate([
            'nom' => ['required', 'string', 'max:150'],
            'telephone' => ['required', 'string', 'max:30'],
            'email' => ['nullable', 'email', 'max:255'],
            'formation' => [
                'required',
                'in:Word,Excel,PowerPoint,Développement web,Intelligence artificielle'
            ],
            'message' => ['nullable', 'string', 'max:1000'],
        ]);

        Inscription::create($donnees);

        return redirect()
            ->route('inscriptions.create')
            ->with('success', 'Votre demande d’inscription a été enregistrée avec succès !');
    }
}
