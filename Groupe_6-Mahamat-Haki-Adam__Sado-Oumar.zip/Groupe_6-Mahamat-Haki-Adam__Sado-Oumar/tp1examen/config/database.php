<?php

$configLocale = __DIR__ . '/database.local.php';

if (is_file($configLocale)) {
    $config = require $configLocale;
} else {
    $config = [
        'host'     => getenv('DB_HOST') ?: 'localhost',
        'dbname'   => getenv('DB_NAME') ?: 'gestion_commande',
        'username' => getenv('DB_USER') ?: '',
        'password' => getenv('DB_PASSWORD') ?: '',
    ];
}

$host = $config['host'];
$dbname = $config['dbname'];
$username = $config['username'];
$password = $config['password'];

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Erreur de connexion à la base : ' . $e->getMessage());
    http_response_code(500);
    exit('Impossible de se connecter à la base de données.');
}
