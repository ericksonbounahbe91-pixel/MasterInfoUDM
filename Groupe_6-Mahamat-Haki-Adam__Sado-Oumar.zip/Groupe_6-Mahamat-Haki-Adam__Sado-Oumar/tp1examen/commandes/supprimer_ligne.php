<?php

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| 1. Vérification stricte des paramètres
|--------------------------------------------------------------------------
*/

if (
    !isset($_GET['idCmd'], $_GET['idProd']) ||
    !ctype_digit((string) $_GET['idCmd']) ||
    !ctype_digit((string) $_GET['idProd'])
) {
    http_response_code(400);
    exit('Paramètres invalides.');
}

$idCmd = (int) $_GET['idCmd'];
$idProd = (int) $_GET['idProd'];

if ($idCmd <= 0 || $idProd <= 0) {
    http_response_code(400);
    exit('Identifiants invalides.');
}

/*
|--------------------------------------------------------------------------
| 2. Suppression sécurisée et restauration du stock
|--------------------------------------------------------------------------
*/

try {
    $pdo->beginTransaction();

    /*
     * Verrouiller d'abord le produit.
     * Cet ordre correspond à celui utilisé dans ajouter_ligne.php.
     */
    $sql = "
        SELECT idProd
        FROM Produit
        WHERE idProd = ?
        FOR UPDATE
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idProd]);

    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        throw new RuntimeException('Produit introuvable.');
    }

    /*
     * Verrouiller ensuite la ligne de commande.
     */
    $sql = "
        SELECT qteCmd
        FROM ligneCommande
        WHERE idCmd = ?
          AND idProd = ?
        FOR UPDATE
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idCmd, $idProd]);

    $ligne = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$ligne) {
        throw new RuntimeException(
            "Cette ligne de commande n'existe plus."
        );
    }

    $quantite = (int) $ligne['qteCmd'];

    if ($quantite <= 0) {
        throw new RuntimeException(
            'La quantité de cette ligne est invalide.'
        );
    }

    /*
     * Restaurer le stock.
     */
    $sql = "
        UPDATE Produit
        SET qteStock = qteStock + ?
        WHERE idProd = ?
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$quantite, $idProd]);

    /*
     * Supprimer la ligne concernée uniquement.
     */
    $sql = "
        DELETE FROM ligneCommande
        WHERE idCmd = ?
          AND idProd = ?
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idCmd, $idProd]);

    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException(
            'La ligne de commande n’a pas pu être supprimée.'
        );
    }

    /*
     * Valider les deux opérations ensemble.
     */
    $pdo->commit();

    header(
        'Location: ajouter_ligne.php?idCmd=' . $idCmd,
        true,
        303
    );
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Erreur suppression ligne commande : ' . $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Une erreur est survenue lors de la suppression. ' .
        'Vérifiez les journaux PHP si le problème persiste.'
    );
}
