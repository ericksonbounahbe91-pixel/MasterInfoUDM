
<?php
require_once __DIR__ . '/../config/database.php';

$sql = "
    SELECT
        c.idCmd,
        c.dateCmd,
        cl.idCli,
        cl.nomCli,
        cl.prenomCli,
        cl.email
    FROM Commande c
    INNER JOIN Client cl ON c.idCli = cl.idCli
    ORDER BY c.idCmd DESC
";

$stmt = $pdo->query($sql);
$commandes = $stmt->fetchAll();

$totalCommandes = count($commandes);

function e($valeur): string
{
    return htmlspecialchars(
        (string) $valeur,
        ENT_QUOTES,
        'UTF-8'
    );
}

function dateLisible($date): string
{
    if (empty($date)) {
        return 'Non renseignée';
    }

    try {
        return (new DateTime((string) $date))->format('d/m/Y H:i');
    } catch (Exception $exception) {
        return (string) $date;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Commandes | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

    <style>
        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 18px;
            margin-bottom: 26px;
        }

        .page-heading h1 {
            margin: 0 0 8px;
            font-size: clamp(1.5rem, 3vw, 2rem);
            color: var(--app-text, #202b3c);
        }

        .page-heading p {
            margin: 0;
            color: var(--app-muted, #8490a5);
        }

        .order-stat {
            display: flex;
            align-items: center;
            gap: 17px;
            padding: 22px;
            margin-bottom: 26px;
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
        }

        .order-stat-icon {
            width: 50px;
            height: 50px;
            display: grid;
            place-items: center;
            flex-shrink: 0;
            background: #edf2ff;
            color: #3457d5;
            border-radius: 13px;
            font-size: 1.3rem;
        }

        .order-stat-label {
            color: #8490a5;
            font-size: .9rem;
            margin-bottom: 5px;
        }

        .order-stat strong {
            display: block;
            font-size: 1.7rem;
            color: #202b3c;
        }

        .order-panel {
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
            overflow: hidden;
        }

        .order-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            padding: 22px;
            border-bottom: 1px solid #edf0f5;
        }

        .order-panel-header h2 {
            margin: 0 0 5px;
            color: #202b3c;
            font-size: 1.1rem;
        }

        .order-panel-header p {
            margin: 0;
            color: #8490a5;
            font-size: .88rem;
        }

        .order-search {
            width: min(100%, 320px);
            padding: 11px 13px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            font-size: .9rem;
            outline: none;
        }

        .order-search:focus {
            border-color: #3457d5;
            box-shadow: 0 0 0 3px rgba(52, 87, 213, .10);
        }

        .order-table-wrap {
            overflow-x: auto;
        }

        .order-table {
            width: 100%;
            min-width: 790px;
            border-collapse: collapse;
        }

        .order-table th {
            padding: 15px 18px;
            background: #f8f9fc;
            color: #748096;
            text-align: left;
            font-size: .76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .04em;
            white-space: nowrap;
        }

        .order-table td {
            padding: 15px 18px;
            border-top: 1px solid #edf0f5;
            color: #354155;
            vertical-align: middle;
        }

        .order-table tbody tr:hover {
            background: #fafbff;
        }

        .order-id {
            display: inline-block;
            padding: 6px 10px;
            background: #edf2ff;
            color: #3457d5;
            border-radius: 7px;
            font-weight: 800;
            white-space: nowrap;
        }

        .order-date {
            white-space: nowrap;
            color: #657187;
        }


        .order-client {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
            width: 100%;
        }

        .order-client-name {
            color: #202b3c;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .order-client-id {
            color: #8490a5;
            font-size: .8rem;
            margin-top: 3px;
        }


        .order-email {
            color: #3457d5;
            text-decoration: none;
            overflow-wrap: anywhere;
        }

        .order-email:hover {
            text-decoration: underline;
        }

        .order-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 9px 13px;
            color: #fff;
            background: #3457d5;
            border-radius: 8px;
            text-decoration: none;
            font-size: .85rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .order-action:hover {
            background: #243b91;
        }

        .order-empty {
            padding: 48px 20px;
            text-align: center;
            color: #8490a5;
        }

        .order-empty i {
            display: block;
            font-size: 2rem;
            margin-bottom: 14px;
        }

        .order-footer {
            padding: 16px 22px;
            border-top: 1px solid #edf0f5;
            color: #8490a5;
            font-size: .85rem;
        }

        @media (max-width: 600px) {
            .order-stat {
                padding: 17px;
            }

            .order-panel-header {
                padding: 17px;
            }

            .order-search {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <div class="page-heading">
        <div>
            <h1>Gestion des commandes</h1>
            <p>Consultez les commandes et gérez les produits associés.</p>
        </div>

        <a href="../index.php" class="product-action">
            <i class="fa-solid fa-house"></i>
            Retour à l'accueil
        </a>
    </div>

    <section class="order-stat">
        <div class="order-stat-icon">
            <i class="fa-solid fa-cart-shopping"></i>
        </div>

        <div>
            <div class="order-stat-label">Commandes enregistrées</div>
            <strong><?= number_format($totalCommandes, 0, ',', ' ') ?></strong>
        </div>
    </section>

    <section class="order-panel">

        <div class="order-panel-header">
            <div>
                <h2>Liste des commandes</h2>
                <p>Retrouvez une commande par son numéro ou les informations du client.</p>
            </div>

            <input
                type="search"
                id="rechercheCommande"
                class="order-search"
                placeholder="Rechercher une commande..."
                aria-label="Rechercher une commande"
            >
        </div>

        <?php if ($totalCommandes > 0): ?>

            <div class="order-table-wrap">
                <table class="order-table">
                    <thead>
                        <tr>

                            <th>Commande</th>
                            <th>Date</th>
                            <th>Client</th>
                            <th>Email</th>
                            <th>Facture</th>
                            <th>Action</th>

                        </tr>
                    </thead>

                    <tbody id="tableauCommandes">

                    <?php foreach ($commandes as $commande): ?>
                        <?php
                        $nomComplet = trim(
                            (string) $commande['prenomCli'] . ' ' .
                            (string) $commande['nomCli']
                        );

                        $initiales =
                            mb_substr((string) $commande['prenomCli'], 0, 1, 'UTF-8') .
                            mb_substr((string) $commande['nomCli'], 0, 1, 'UTF-8');

                        $initiales = mb_strtoupper($initiales, 'UTF-8');
                        ?>

                        <tr>
                            <td>
                                <span class="order-id">
                                    CMD-<?= e($commande['idCmd']) ?>
                                </span>
                            </td>

                            <td class="order-date">
                                <i class="fa-regular fa-calendar" style="margin-right:6px;"></i>
                                <?= e(dateLisible($commande['dateCmd'])) ?>
                            </td>

                            <td>
                                <div class="order-client">
                                    <div class="order-avatar">
                                        <?= e($initiales) ?>
                                    </div>

                                    <div>
                                        <div class="order-client-name">
                                            <?= e($nomComplet) ?>
                                        </div>
                                        <div class="order-client-id">
                                            Client <?= e($commande['idCli']) ?>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <?php if (!empty($commande['email'])): ?>
                                    <a
                                        class="order-email"
                                        href="mailto:<?= e($commande['email']) ?>"
                                    >
                                        <?= e($commande['email']) ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color:#9aa5b6;">Non renseigné</span>
                                <?php endif; ?>
                            </td>


                            <td>
                                <a
                                    href="facture.php?idCmd=<?= (int) $commande['idCmd'] ?>"
                                    class="order-action"
                                    target="_blank"
                                    rel="noopener"
                                >
                                    <i class="fa-solid fa-file-invoice"></i>
                                    Facture
                                </a>
                            </td>

                            <td>
                                <a
                                    href="ajouter_ligne.php?idCmd=<?= (int) $commande['idCmd'] ?>"
                                    class="order-action"
                                >
                                    <i class="fa-solid fa-sliders"></i>
                                    Gérer
                                </a>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

            <div class="order-footer" id="compteurCommandes">
                <?= number_format($totalCommandes, 0, ',', ' ') ?>
                commande(s) affichée(s)
            </div>

        <?php else: ?>

            <div class="order-empty">
                <i class="fa-solid fa-cart-shopping"></i>
                <strong>Aucune commande enregistrée</strong>
                <p>Les commandes apparaîtront ici lorsqu'elles seront créées.</p>
            </div>

        <?php endif; ?>

    </section>

    <footer style="text-align:center;color:#8490a5;padding:26px 10px;font-size:.85rem;">
        TP Examen — Gestion d'une ligne de commande
    </footer>

</main>

<script>
const rechercheCommande = document.getElementById('rechercheCommande');
const tableauCommandes = document.getElementById('tableauCommandes');
const compteurCommandes = document.getElementById('compteurCommandes');

if (rechercheCommande && tableauCommandes) {
    rechercheCommande.addEventListener('input', function () {
        const terme = this.value.trim().toLocaleLowerCase('fr');
        const lignes = Array.from(tableauCommandes.querySelectorAll('tr'));
        let visibles = 0;

        lignes.forEach(function (ligne) {
            const correspond = ligne.textContent
                .toLocaleLowerCase('fr')
                .includes(terme);

            ligne.hidden = !correspond;

            if (correspond) {
                visibles++;
            }
        });

        if (compteurCommandes) {
            compteurCommandes.textContent =
                visibles + ' commande(s) affichée(s) sur ' + lignes.length;
        }
    });
}
</script>

</body>
</html>
