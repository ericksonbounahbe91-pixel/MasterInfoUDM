<?php
require_once __DIR__ . '/../config/database.php';

/* =========================================================
   1. Vérification de la commande
========================================================= */

if (!isset($_GET['idCmd']) || !ctype_digit((string) $_GET['idCmd'])) {
    die('Commande invalide.');
}

$idCmd = (int) $_GET['idCmd'];

if ($idCmd <= 0) {
    die('Commande invalide.');
}

/* =========================================================
   2. Récupération de la commande et du client
========================================================= */

$sql = "
    SELECT
        c.idCmd,
        c.dateCmd,
        cl.idCli,
        cl.nomCli,
        cl.prenomCli
    FROM Commande c
    INNER JOIN Client cl ON c.idCli = cl.idCli
    WHERE c.idCmd = ?
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$idCmd]);
$commande = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$commande) {
    die('Commande introuvable.');
}

/* =========================================================
   3. Fonctions d'affichage
========================================================= */

function e($valeur): string
{
    return htmlspecialchars(
        (string) $valeur,
        ENT_QUOTES,
        'UTF-8'
    );
}

function fcfa($montant): string
{
    return number_format((float) $montant, 0, ',', ' ') . ' FCFA';
}

function dateCommande($date): string
{
    if (empty($date)) {
        return 'Non renseignée';
    }

    try {
        return (new DateTime((string) $date))->format('d/m/Y H:i');
    } catch (Exception $exception) {
        return (string) $date;
    }
}

/* =========================================================
   4. Traitement de l'ajout d'un produit
========================================================= */

$message = '';
$typeMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idProd = filter_input(INPUT_POST, 'idProd', FILTER_VALIDATE_INT);
    $qteCmd = filter_input(INPUT_POST, 'qteCmd', FILTER_VALIDATE_INT);

    $idProd = $idProd === false || $idProd === null ? 0 : $idProd;
    $qteCmd = $qteCmd === false || $qteCmd === null ? 0 : $qteCmd;

    if ($idProd <= 0 || $qteCmd <= 0) {
        $message = 'Sélectionnez un produit et une quantité valide.';
        $typeMessage = 'erreur';
    } else {
        try {
            $pdo->beginTransaction();

            /*
             * Verrouiller le produit pendant la transaction.
             * Le prix est lu au moment de l'ajout.
             */
            $sql = "
                SELECT idProd, designProd, qteStock, prixUProd
                FROM Produit
                WHERE idProd = ?
                FOR UPDATE
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idProd]);
            $produit = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$produit) {
                throw new RuntimeException('Produit introuvable.');
            }

            $stockDisponible = (int) $produit['qteStock'];

            if ($stockDisponible < $qteCmd) {
                throw new RuntimeException(
                    'Stock insuffisant. Stock disponible : ' .
                    $stockDisponible
                );
            }

            $prixActuel = (float) $produit['prixUProd'];

            /*
             * Vérifier si le produit figure déjà dans la commande.
             */
            $sql = "
                SELECT qteCmd, prixUCmd
                FROM ligneCommande
                WHERE idCmd = ? AND idProd = ?
                FOR UPDATE
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idCmd, $idProd]);
            $ligneExistante = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($ligneExistante) {
                /*
                 * Ajouter à la quantité existante.
                 * Garder le prix historique s'il est déjà enregistré.
                 */
                $nouvelleQte = (int) $ligneExistante['qteCmd'] + $qteCmd;

                $sql = "
                    UPDATE ligneCommande
                    SET
                        qteCmd = ?,
                        prixUCmd = COALESCE(prixUCmd, ?)
                    WHERE idCmd = ? AND idProd = ?
                ";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $nouvelleQte,
                    $prixActuel,
                    $idCmd,
                    $idProd
                ]);
            } else {
                /*
                 * Nouvelle ligne : enregistrer le prix du jour
                 * dans prixUCmd.
                 */
                $sql = "
                    INSERT INTO ligneCommande
                        (idCmd, idProd, qteCmd, prixUCmd)
                    VALUES (?, ?, ?, ?)
                ";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $idCmd,
                    $idProd,
                    $qteCmd,
                    $prixActuel
                ]);
            }

            /*
             * Décrémenter le stock de manière sécurisée.
             */
            $sql = "
                UPDATE Produit
                SET qteStock = qteStock - ?
                WHERE idProd = ? AND qteStock >= ?
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([$qteCmd, $idProd, $qteCmd]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'Le stock a changé. Actualisez la page puis réessayez.'
                );
            }

            $pdo->commit();

            $message = 'Produit ajouté à la commande avec succès.';
            $typeMessage = 'succes';

        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Erreur ajout ligne commande : ' . $exception->getMessage()
            );

            $message = $exception instanceof RuntimeException
                ? $exception->getMessage()
                : 'Une erreur est survenue. Vérifiez la base de données et réessayez.';

            $typeMessage = 'erreur';
        }
    }
}

/* =========================================================
   5. Récupération des produits disponibles
========================================================= */

$sql = "
    SELECT idProd, designProd, qteStock, prixUProd
    FROM Produit
    ORDER BY designProd
";

$stmt = $pdo->query($sql);
$produits = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   6. Récupération des lignes avec prix historique
========================================================= */

$sql = "
    SELECT
        lc.idCmd,
        lc.idProd,
        lc.qteCmd,
        COALESCE(lc.prixUCmd, p.prixUProd) AS prixUnitaire,
        p.designProd,
        (
            lc.qteCmd * COALESCE(lc.prixUCmd, p.prixUProd)
        ) AS montant
    FROM ligneCommande lc
    INNER JOIN Produit p ON lc.idProd = p.idProd
    WHERE lc.idCmd = ?
    ORDER BY p.designProd
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$idCmd]);
$lignes = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   7. Calcul des totaux
========================================================= */

$totalArticles = 0;
$totalCommande = 0;

foreach ($lignes as $ligne) {
    $totalArticles += (int) $ligne['qteCmd'];
    $totalCommande += (float) $ligne['montant'];
}

$nomClient = trim(
    (string) $commande['prenomCli'] . ' ' .
    (string) $commande['nomCli']
);

$initiales = '';

foreach (
    preg_split('/\s+/u', $nomClient, -1, PREG_SPLIT_NO_EMPTY) ?: []
    as $mot
) {
    $initiales .= mb_substr($mot, 0, 1, 'UTF-8');

    if (mb_strlen($initiales, 'UTF-8') >= 2) {
        break;
    }
}

if ($initiales === '') {
    $initiales = 'CL';
}

$initiales = mb_strtoupper($initiales, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Commande #<?= e($idCmd) ?> | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

  
    <style>
        /* =====================================================
           EN-TÊTE
        ===================================================== */

        .order-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 18px;
            margin-bottom: 25px;
        }

        .order-heading h1 {
            margin: 0 0 8px;
            font-size: clamp(1.5rem, 3vw, 2rem);
            color: #202b3c;
        }

        .order-heading p {
            margin: 0;
            color: #8490a5;
        }

        .order-back {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 11px 15px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            color: #354155;
            background: #fff;
            text-decoration: none;
            font-weight: 700;
            white-space: nowrap;
        }

        .order-back:hover {
            background: #f8f9fc;
        }

        /* =====================================================
           INFORMATIONS DE LA COMMANDE
        ===================================================== */

        .order-info-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 22px;
            padding: 23px;
            margin-bottom: 22px;
            background: #fff;
            border: 1px solid #e7ebf3;
            border-radius: 14px;
        }

        .order-info-client {
            display: flex;
            align-items: center;
            gap: 15px;
            min-width: 0;
        }

        .order-client-avatar {
            display: grid;
            place-items: center;
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #edf2ff;
            color: #3457d5;
            font-weight: 800;
            font-size: 1.1rem;
        }

        .order-info-client h2 {
            margin: 0 0 6px;
            font-size: 1.1rem;
            color: #202b3c;
            overflow-wrap: anywhere;
        }

        .order-info-client p {
            margin: 0;
            color: #8490a5;
            font-size: .9rem;
        }

        .order-info-date {
            color: #657187;
            font-size: .9rem;
            line-height: 1.8;
        }

        .order-info-date strong {
            color: #202b3c;
        }

        /* =====================================================
           INDICATEURS
        ===================================================== */

        .order-metrics {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 25px;
        }

        .order-metric {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 0;
            padding: 20px;
            background: #fff;
            border: 1px solid #e7ebf3;
            border-radius: 13px;
        }

        .order-metric-icon {
            display: grid;
            place-items: center;
            width: 45px;
            height: 45px;
            flex-shrink: 0;
            border-radius: 12px;
            background: #edf2ff;
            color: #3457d5;
            font-size: 1.15rem;
        }

        .order-metric-label {
            margin-bottom: 6px;
            color: #8490a5;
            font-size: .84rem;
        }

        .order-metric-value {
            color: #202b3c;
            font-size: clamp(1rem, 2vw, 1.35rem);
            font-weight: 800;
            overflow-wrap: anywhere;
        }

        /* =====================================================
           CARTES
        ===================================================== */

        .order-card {
            margin-bottom: 25px;
            background: #fff;
            border: 1px solid #e7ebf3;
            border-radius: 14px;
            overflow: hidden;
        }

        .order-card-header {
            padding: 21px 23px;
            border-bottom: 1px solid #edf0f5;
        }

        .order-card-header h2 {
            margin: 0 0 6px;
            color: #202b3c;
            font-size: 1.08rem;
        }

        .order-card-header p {
            margin: 0;
            color: #8490a5;
            font-size: .88rem;
        }

        /* =====================================================
           FORMULAIRE
        ===================================================== */

        .order-form-body {
            padding: 23px;
        }

        .order-form-grid {
            display: grid;
            grid-template-columns: minmax(0, 2fr) minmax(130px, 1fr);
            gap: 20px;
            align-items: end;
        }

        .order-field {
            min-width: 0;
        }

        .order-field label {
            display: block;
            margin-bottom: 9px;
            color: #354155;
            font-weight: 700;
            font-size: .9rem;
        }

        .order-field select,
        .order-field input {
            display: block;
            box-sizing: border-box;
            width: 100%;
            min-height: 46px;
            padding: 11px 13px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            background: #fff;
            color: #202b3c;
            font-size: .95rem;
            outline: none;
        }

        .order-field select:focus,
        .order-field input:focus {
            border-color: #3457d5;
            box-shadow: 0 0 0 3px rgba(52, 87, 213, .10);
        }

        .order-form-actions {
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
        }

        .order-help {
            color: #8490a5;
            font-size: .85rem;
        }

        .order-primary-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 44px;
            padding: 12px 18px;
            border: 0;
            border-radius: 9px;
            background: #3457d5;
            color: #fff;
            font-size: .9rem;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            transition: background .2s ease;
        }

        .order-primary-btn:hover {
            background: #243b91;
        }

        /* =====================================================
           MESSAGES
        ===================================================== */

        .order-alert {
            padding: 15px 18px;
            margin-bottom: 22px;
            border-radius: 10px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            line-height: 1.6;
        }

        .order-alert.succes {
            background: #e8f8ef;
            color: #17663b;
            border: 1px solid #c4ecd3;
        }

        .order-alert.erreur {
            background: #fff0f0;
            color: #9e2525;
            border: 1px solid #f5cccc;
        }

        /* =====================================================
           OUTILS DU TABLEAU
        ===================================================== */

        .order-table-tools {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
            padding: 17px 23px;
        }

        .order-table-search {
            box-sizing: border-box;
            width: min(100%, 300px);
            padding: 10px 12px;
            border: 1px solid #dfe5ef;
            border-radius: 8px;
            outline: none;
        }

        .order-table-search:focus {
            border-color: #3457d5;
        }

        /* =====================================================
           TABLEAU DES LIGNES
        ===================================================== */

        .order-table-wrap {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .order-lines-table {
            width: 100%;
            min-width: 700px;
            border-collapse: collapse;
            table-layout: auto;
        }

        .order-lines-table th {
            padding: 14px 18px;
            background: #f8f9fc;
            color: #748096;
            text-align: left;
            font-size: .76rem;
            letter-spacing: .04em;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .order-lines-table td {
            padding: 16px 18px;
            border-top: 1px solid #edf0f5;
            color: #354155;
            vertical-align: middle;
        }

        .order-lines-table tbody tr:hover {
            background: #fafbff;
        }

        .order-product-name {
            font-weight: 700;
            color: #202b3c;
            overflow-wrap: anywhere;
        }

        .order-quantity {
            display: inline-block;
            padding: 6px 10px;
            background: #f0f3f8;
            border-radius: 7px;
            font-weight: 700;
        }

        .order-line-total {
            font-weight: 800;
            white-space: nowrap;
            color: #202b3c;
        }

        .order-delete {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 8px 11px;
            border: 1px solid #f2caca;
            border-radius: 8px;
            background: #fff6f6;
            color: #b42323;
            text-decoration: none;
            font-size: .84rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .order-delete:hover {
            background: #ffe8e8;
        }

        /* =====================================================
           ÉTAT VIDE
        ===================================================== */

        .order-empty {
            padding: 45px 20px;
            text-align: center;
            color: #8490a5;
        }

        .order-empty i {
            display: block;
            margin-bottom: 13px;
            font-size: 2rem;
        }

        .order-empty strong {
            display: block;
            color: #354155;
            margin-bottom: 8px;
        }

        /* =====================================================
           TOTAL
        ===================================================== */

        .order-total-footer {
            display: flex;
            justify-content: flex-end;
            padding: 20px 23px;
            background: #f8f9fc;
            border-top: 1px solid #edf0f5;
        }

        .order-total-box {
            text-align: right;
        }

        .order-total-label {
            display: block;
            color: #8490a5;
            font-size: .88rem;
            margin-bottom: 7px;
        }

        .order-total-value {
            color: #3457d5;
            font-size: 1.5rem;
            font-weight: 900;
        }

        /* =====================================================
           RESPONSIVE : TABLETTES
        ===================================================== */

        @media (max-width: 800px) {
            .order-metrics {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .order-form-grid {
                grid-template-columns: 1fr;
            }

            .order-info-card {
                align-items: flex-start;
            }
        }

        /* =====================================================
           RESPONSIVE : TÉLÉPHONES
        ===================================================== */

        @media (max-width: 600px) {
            .order-info-card,
            .order-form-body {
                padding: 17px;
            }

            .order-card-header,
            .order-table-tools {
                padding: 17px;
            }

            .order-table-search {
                width: 100%;
            }

            .order-form-actions {
                align-items: stretch;
                flex-direction: column;
            }

            .order-primary-btn {
                width: 100%;
            }

            .order-total-footer {
                padding: 17px;
            }

            .order-total-value {
                font-size: 1.25rem;
            }
        }
    </style>

</head>

<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <div class="order-heading">
        <div>
            <h1>Gestion de la commande</h1>
            <p>Ajoutez des produits et consultez le détail de la commande.</p>
        </div>

        <a href="liste.php" class="order-back">
            <i class="fa-solid fa-arrow-left"></i>
            Retour aux commandes
        </a>
    </div>

    <?php if ($message !== ''): ?>
        <div class="order-alert <?= e($typeMessage) ?>" role="status">
            <i class="fa-solid <?= $typeMessage === 'succes'
                ? 'fa-circle-check'
                : 'fa-circle-exclamation' ?>"></i>
            <div><?= e($message) ?></div>
        </div>
    <?php endif; ?>

    <section class="order-info-card">
        <div class="order-info-client">
            <div class="order-client-avatar"><?= e($initiales) ?></div>
            <div>
                <h2><?= e($nomClient) ?></h2>
                <p>Client #<?= e($commande['idCli']) ?></p>
            </div>
        </div>

        <div class="order-info-date">
            <div><strong>Commande :</strong> CMD-<?= e($idCmd) ?></div>
            <div><strong>Date :</strong> <?= e(dateCommande($commande['dateCmd'])) ?></div>
        </div>
    </section>

    <section class="order-metrics">
        <div class="order-metric">
            <div class="order-metric-icon">
                <i class="fa-solid fa-boxes-stacked"></i>
            </div>
            <div>
                <div class="order-metric-label">Références de produits</div>
                <div class="order-metric-value"><?= count($lignes) ?></div>
            </div>
        </div>

        <div class="order-metric">
            <div class="order-metric-icon">
                <i class="fa-solid fa-cubes"></i>
            </div>
            <div>
                <div class="order-metric-label">Quantité totale</div>
                <div class="order-metric-value">
                    <?= number_format($totalArticles, 0, ',', ' ') ?>
                </div>
            </div>
        </div>

        <div class="order-metric">
            <div class="order-metric-icon">
                <i class="fa-solid fa-money-bill-wave"></i>
            </div>
            <div>
                <div class="order-metric-label">Montant total</div>
                <div class="order-metric-value"><?= e(fcfa($totalCommande)) ?></div>
            </div>
        </div>
    </section>

    <section class="order-card">
        <div class="order-card-header">
            <h2><i class="fa-solid fa-circle-plus"></i> Ajouter un produit</h2>
            <p>Choisissez le produit et indiquez la quantité à commander.</p>
        </div>

        <div class="order-form-body">
            <?php if (count($produits) > 0): ?>
                <form method="POST" action="ajouter_ligne.php?idCmd=<?= e($idCmd) ?>">
                    <div class="order-form-grid">
                        <div class="order-field">
                            <label for="idProd">Produit</label>
                            <select name="idProd" id="idProd" required>
                                <option value="">-- Sélectionner un produit --</option>

                                <?php foreach ($produits as $produit): ?>
                                    <option
                                        value="<?= e($produit['idProd']) ?>"
                                        <?= (int) $produit['qteStock'] <= 0 ? 'disabled' : '' ?>
                                    >
                                        <?= e($produit['designProd']) ?>
                                        — Stock : <?= e($produit['qteStock']) ?>
                                        — <?= e(fcfa($produit['prixUProd'])) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="order-field">
                            <label for="qteCmd">Quantité</label>
                            <input
                                type="number"
                                name="qteCmd"
                                id="qteCmd"
                                min="1"
                                step="1"
                                value="1"
                                required
                            >
                        </div>
                    </div>

                    <div class="order-form-actions">
                        <span class="order-help">
                            <i class="fa-solid fa-circle-info"></i>
                            Le stock sera mis à jour après validation.
                        </span>

                        <button type="submit" class="order-primary-btn">
                            <i class="fa-solid fa-plus"></i>
                            Ajouter à la commande
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="order-empty">
                    <i class="fa-solid fa-box-open"></i>
                    <strong>Aucun produit dans le catalogue</strong>
                    <p>Ajoutez d'abord des produits dans la rubrique Produits.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="order-card">
        <div class="order-card-header">
            <h2><i class="fa-solid fa-list-check"></i> Produits de la commande</h2>
            <p>Les montants utilisent le prix enregistré pour chaque commande.</p>
        </div>

        <?php if (count($lignes) > 0): ?>

            <div class="order-table-tools">
                <span class="order-help" id="compteurLignes">
                    <?= count($lignes) ?> ligne(s) de commande
                </span>

                <input
                    type="search"
                    id="rechercheLigne"
                    class="order-table-search"
                    placeholder="Rechercher un produit..."
                    aria-label="Rechercher un produit"
                >
            </div>

            <div class="order-table-wrap">
                <table class="order-lines-table">
                    <thead>
                        <tr>
                            <th>Produit</th>
                            <th>Quantité</th>
                            <th>Prix unitaire</th>
                            <th>Montant</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="tableauLignes">
                        <?php foreach ($lignes as $ligne): ?>
                            <tr>
                                <td class="order-product-name">
                                    <?= e($ligne['designProd']) ?>
                                </td>

                                <td>
                                    <span class="order-quantity">
                                        <?= e($ligne['qteCmd']) ?>
                                    </span>
                                </td>

                                <td><?= e(fcfa($ligne['prixUnitaire'])) ?></td>

                                <td class="order-line-total">
                                    <?= e(fcfa($ligne['montant'])) ?>
                                </td>

                                <td>
                                    <a
                                        href="supprimer_ligne.php?idCmd=<?= rawurlencode((string) $ligne['idCmd']) ?>&amp;idProd=<?= rawurlencode((string) $ligne['idProd']) ?>"
                                        class="order-delete"
                                        onclick="return confirm('Voulez-vous vraiment supprimer ce produit de la commande ?');"
                                    >
                                        <i class="fa-solid fa-trash"></i>
                                        Supprimer
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="order-total-footer">
                <div class="order-total-box">
                    <span class="order-total-label">Total de la commande</span>
                    <div class="order-total-value"><?= e(fcfa($totalCommande)) ?></div>
                </div>
            </div>

        <?php else: ?>

            <div class="order-empty">
                <i class="fa-solid fa-basket-shopping"></i>
                <strong>Aucun produit dans cette commande</strong>
                <p>Utilisez le formulaire ci-dessus pour ajouter le premier produit.</p>
            </div>

        <?php endif; ?>
    </section>

    <footer style="text-align:center;color:#8490a5;padding:20px 10px;font-size:.85rem;">
        TP Examen — Gestion d'une ligne de commande
    </footer>

</main>

<script>
const rechercheLigne = document.getElementById('rechercheLigne');
const tableauLignes = document.getElementById('tableauLignes');
const compteurLignes = document.getElementById('compteurLignes');

if (rechercheLigne && tableauLignes) {
    rechercheLigne.addEventListener('input', function () {
        const terme = this.value.trim().toLocaleLowerCase('fr');
        const lignes = Array.from(tableauLignes.querySelectorAll('tr'));
        let visibles = 0;

        lignes.forEach(function (ligne) {
            const correspond = ligne.textContent
                .toLocaleLowerCase('fr')
                .includes(terme);

            ligne.hidden = !correspond;

            if (correspond) {
                visibles++;
            }
        });

        if (compteurLignes) {
            compteurLignes.textContent =
                visibles + ' ligne(s) affichée(s) sur ' + lignes.length;
        }
    });
}
</script>

</body>
</html>
