<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| 1. VERIFICATION DE LA COMMANDE
|--------------------------------------------------------------------------
*/

$idCmd = filter_input(INPUT_GET, 'idCmd', FILTER_VALIDATE_INT);

if (!$idCmd || $idCmd <= 0) {
    http_response_code(400);
    exit('Numéro de commande invalide.');
}

/*
|--------------------------------------------------------------------------
| 2. RECUPERATION DE LA COMMANDE ET DU CLIENT
|--------------------------------------------------------------------------
*/

$sqlCommande = "
    SELECT
        c.idCmd,
        c.dateCmd,
        cl.idCli,
        cl.nomCli,
        cl.prenomCli,
        cl.email
    FROM Commande c
    INNER JOIN Client cl ON cl.idCli = c.idCli
    WHERE c.idCmd = ?
";

$stmt = $pdo->prepare($sqlCommande);
$stmt->execute([$idCmd]);
$commande = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$commande) {
    http_response_code(404);
    exit('Commande introuvable.');
}

/*
|--------------------------------------------------------------------------
| 3. RECUPERATION DES PRODUITS ET DES PRIX HISTORIQUES
|--------------------------------------------------------------------------
*/

$sqlLignes = "
    SELECT
        p.idProd,
        p.designProd,
        COALESCE(lc.prixUCmd, p.prixUProd) AS prixUnitaire,
        lc.qteCmd,
        (
            COALESCE(lc.prixUCmd, p.prixUProd) * lc.qteCmd
        ) AS montant
    FROM ligneCommande lc
    INNER JOIN Produit p ON p.idProd = lc.idProd
    WHERE lc.idCmd = ?
    ORDER BY p.designProd ASC
";

$stmt = $pdo->prepare($sqlLignes);
$stmt->execute([$idCmd]);
$lignes = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| 4. CALCUL DU TOTAL
|--------------------------------------------------------------------------
*/

$totalQuantite = 0;
$totalFacture = 0.0;

foreach ($lignes as $ligne) {
    $totalQuantite += (int) $ligne['qteCmd'];
    $totalFacture += (float) $ligne['montant'];
}

/*
|--------------------------------------------------------------------------
| 5. FONCTIONS D'AFFICHAGE
|--------------------------------------------------------------------------
*/

function e(mixed $valeur): string
{
    return htmlspecialchars(
        (string) $valeur,
        ENT_QUOTES,
        'UTF-8'
    );
}

function fcfa(mixed $valeur): string
{
    return number_format((float) $valeur, 2, ',', ' ');
}

function dateFacture(mixed $date): string
{
    if (empty($date)) {
        return 'Non renseignée';
    }

    try {
        return (new DateTime((string) $date))->format('d/m/Y H:i');
    } catch (Throwable $exception) {
        return (string) $date;
    }
}

$nomClient = trim(
    (string) $commande['prenomCli'] . ' ' .
    (string) $commande['nomCli']
);
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Facture CMD-<?= (int) $commande['idCmd'] ?></title>

    <style>
        :root {
            --bleu: #2345b5;
            --bleu-fonce: #172c6d;
            --texte: #253047;
            --gris: #718096;
            --bordure: #e4e9f2;
            --fond: #f3f6fc;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px 16px;
            background: var(--fond);
            color: var(--texte);
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin: 0 auto 20px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 18px;
            border: 0;
            border-radius: 9px;
            font-size: 14px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-primary {
            background: var(--bleu);
            color: white;
        }

        .btn-secondary {
            background: white;
            color: var(--texte);
            border: 1px solid var(--bordure);
        }

        .facture {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
            padding: 48px;
            background: white;
            border: 1px solid var(--bordure);
            border-radius: 12px;
            box-shadow: 0 12px 40px rgba(25, 40, 75, .07);
        }

        .facture-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 25px;
            padding-bottom: 30px;
            border-bottom: 3px solid var(--bleu);
        }

        .entreprise {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .logo {
            display: grid;
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            place-items: center;
            background: var(--bleu);
            color: white;
            border-radius: 13px;
            font-size: 25px;
            font-weight: 900;
        }

        .entreprise h1 {
            margin: 0 0 7px;
            color: var(--bleu-fonce);
            font-size: 21px;
        }

        .entreprise p {
            margin: 0;
            color: var(--gris);
            font-size: 12px;
            line-height: 1.6;
        }

        .facture-titre {
            text-align: right;
        }

        .facture-titre h2 {
            margin: 0 0 10px;
            color: var(--bleu);
            font-size: 29px;
            letter-spacing: 1px;
        }

        .numero-facture {
            display: inline-block;
            padding: 8px 11px;
            background: #edf2ff;
            color: var(--bleu);
            border-radius: 7px;
            font-weight: 800;
        }

        .date-facture {
            margin-top: 10px;
            color: var(--gris);
            font-size: 12px;
        }

        .informations {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin: 30px 0;
        }

        .info-bloc {
            padding: 20px;
            background: #f8faff;
            border: 1px solid var(--bordure);
            border-radius: 10px;
        }

        .info-bloc h3 {
            margin: 0 0 15px;
            color: var(--gris);
            font-size: 11px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .info-bloc strong {
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
        }

        .info-bloc p {
            margin: 5px 0;
            color: var(--gris);
            overflow-wrap: anywhere;
        }

        .titre-tableau {
            margin: 30px 0 13px;
            font-size: 16px;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead th {
            padding: 14px 12px;
            background: var(--bleu-fonce);
            color: white;
            font-size: 11px;
            text-align: left;
            text-transform: uppercase;
        }

        tbody td {
            padding: 15px 12px;
            border-bottom: 1px solid var(--bordure);
        }

        tbody tr:nth-child(even) {
            background: #fafbfe;
        }

        .nombre-cellule,
        .prix-cellule {
            text-align: right;
            white-space: nowrap;
        }

        .total-zone {
            display: flex;
            justify-content: flex-end;
            margin-top: 25px;
        }

        .total-box {
            width: 100%;
            max-width: 330px;
            padding: 20px;
            background: #f3f6ff;
            border: 1px solid #dce5ff;
            border-radius: 10px;
        }

        .total-ligne {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 12px;
        }

        .total-final {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding-top: 15px;
            margin-top: 12px;
            border-top: 2px solid #d5def7;
            color: var(--bleu-fonce);
            font-size: 18px;
            font-weight: 900;
        }

        .mention {
            margin-top: 30px;
            padding: 15px;
            background: #f8faff;
            border-left: 4px solid var(--bleu);
            color: var(--gris);
            font-size: 12px;
            line-height: 1.7;
        }

        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 35px;
            margin-top: 45px;
        }

        .signature {
            min-height: 100px;
            padding-top: 12px;
            border-top: 1px solid #cfd6e3;
            text-align: center;
            color: var(--gris);
            font-size: 12px;
        }

        .pied-page {
            margin-top: 30px;
            padding-top: 18px;
            border-top: 1px solid var(--bordure);
            color: var(--gris);
            text-align: center;
            font-size: 11px;
            line-height: 1.8;
        }

        @media (max-width: 600px) {
            body {
                padding: 12px 8px;
            }

            .facture {
                padding: 22px 15px;
            }

            .facture-header {
                flex-direction: column;
            }

            .facture-titre {
                text-align: left;
            }

            .informations,
            .signatures {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .entreprise h1 {
                font-size: 18px;
            }

            .facture-titre h2 {
                font-size: 25px;
            }

            thead th,
            tbody td {
                padding: 10px 8px;
                font-size: 12px;
            }
        }

        @page {
            size: A4;
            margin: 12mm;
        }

        @media print {
            body {
                padding: 0;
                background: white;
                font-size: 11px;
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }

            .actions {
                display: none !important;
            }

            .facture {
                max-width: none;
                padding: 0;
                border: 0;
                border-radius: 0;
                box-shadow: none;
            }

            .facture-header {
                padding-bottom: 18px;
            }

            .informations {
                margin: 18px 0;
            }

            .info-bloc {
                padding: 12px;
            }

            .titre-tableau {
                margin-top: 18px;
            }

            tbody td {
                padding: 10px 8px;
            }

            .total-zone,
            .signatures,
            .mention {
                break-inside: avoid;
            }
        }
    </style>
</head>

<body>

<div class="actions">
    <button class="btn btn-primary" onclick="window.print()">
        Imprimer / Enregistrer en PDF
    </button>

    <a
        class="btn btn-secondary"
        href="ajouter_ligne.php?idCmd=<?= (int) $commande['idCmd'] ?>"
    >
        Retour à la commande
    </a>

    <a class="btn btn-secondary" href="liste.php">
        Liste des commandes
    </a>
</div>

<main class="facture">

    <header class="facture-header">

        <div class="entreprise">
            <div class="logo">GC</div>

            <div>
                <h1>GESTION DES COMMANDES</h1>
                <p>Application de gestion commerciale</p>
                <p>Document généré par le système</p>
            </div>
        </div>

        <div class="facture-titre">
            <h2>FACTURE</h2>

            <div class="numero-facture">
                CMD-<?= (int) $commande['idCmd'] ?>
            </div>

            <div class="date-facture">
                Date : <?= e(dateFacture($commande['dateCmd'])) ?>
            </div>
        </div>

    </header>

    <section class="informations">

        <div class="info-bloc">
            <h3>Facturé à</h3>

            <strong><?= e($nomClient) ?></strong>

            <p>Numéro client : #<?= (int) $commande['idCli'] ?></p>

            <?php if (!empty($commande['email'])): ?>
                <p><?= e($commande['email']) ?></p>
            <?php else: ?>
                <p>Adresse électronique non renseignée</p>
            <?php endif; ?>
        </div>

        <div class="info-bloc">
            <h3>Informations du document</h3>

            <strong>
                Facture n° FAC-<?= (int) $commande['idCmd'] ?>
            </strong>

            <p>Commande : CMD-<?= (int) $commande['idCmd'] ?></p>
            <p>Nombre de références : <?= count($lignes) ?></p>
            <p>Quantité totale :
                <?= number_format($totalQuantite, 0, ',', ' ') ?>
            </p>
        </div>

    </section>

    <h3 class="titre-tableau">Détail des articles</h3>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Référence</th>
                    <th>Désignation</th>
                    <th class="nombre-cellule">Quantité</th>
                    <th class="prix-cellule">Prix unitaire</th>
                    <th class="prix-cellule">Montant</th>
                </tr>
            </thead>

            <tbody>
            <?php if ($lignes): ?>

                <?php foreach ($lignes as $ligne): ?>
                    <tr>
                        <td>#<?= (int) $ligne['idProd'] ?></td>

                        <td><?= e($ligne['designProd']) ?></td>

                        <td class="nombre-cellule">
                            <?= number_format(
                                (int) $ligne['qteCmd'],
                                0,
                                ',',
                                ' '
                            ) ?>
                        </td>

                        <td class="prix-cellule">
                            <?= fcfa($ligne['prixUnitaire']) ?> FCFA
                        </td>

                        <td class="prix-cellule">
                            <strong>
                                <?= fcfa($ligne['montant']) ?> FCFA
                            </strong>
                        </td>
                    </tr>
                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="5" style="text-align:center;padding:30px;">
                        Aucun article n'est associé à cette commande.
                    </td>
                </tr>

            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <section class="total-zone">
        <div class="total-box">

            <div class="total-ligne">
                <span>Nombre d'articles</span>
                <strong>
                    <?= number_format($totalQuantite, 0, ',', ' ') ?>
                </strong>
            </div>

            <div class="total-ligne">
                <span>Sous-total</span>
                <strong><?= fcfa($totalFacture) ?> FCFA</strong>
            </div>

            <div class="total-final">
                <span>TOTAL</span>
                <span><?= fcfa($totalFacture) ?> FCFA</span>
            </div>

        </div>
    </section>

    <div class="mention">
        <strong>Important :</strong>
        cette facture récapitule les articles associés à la commande.
        Les montants sont calculés à partir du prix unitaire enregistré
        pour chaque ligne de commande. Pour les anciennes lignes sans
        prix historique, le prix actuel du catalogue est utilisé.
    </div>

    <section class="signatures">

        <div class="signature">
            Signature du client
        </div>

        <div class="signature">
            Cachet et signature du responsable
        </div>

    </section>

    <footer class="pied-page">
        Gestion des commandes — Facture générée automatiquement<br>
        Merci pour votre confiance.
    </footer>

</main>

</body>
</html>
