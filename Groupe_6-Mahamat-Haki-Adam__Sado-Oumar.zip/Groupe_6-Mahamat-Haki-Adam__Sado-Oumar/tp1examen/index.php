
<?php
require_once __DIR__ . '/config/database.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Application de gestion des produits, clients et commandes. Projet universitaire 2026.">

    <title>Gestion des commandes | Présentation du projet</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fontawesome.css">

    <style>
        :root {
            --primary: #3457d5;
            --primary-dark: #243b91;
            --navy: #101a31;
            --text: #202b3c;
            --muted: #758198;
            --background: #f4f6fb;
            --border: #e6eaf2;
            --white: #ffffff;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            color: var(--text);
            background: var(--background);
            line-height: 1.6;
        }

        a {
            text-decoration: none;
        }

        .site-header {
            background: rgba(255, 255, 255, .97);
            border-bottom: 1px solid var(--border);
        }

        .nav-container {
            max-width: 1200px;
            margin: auto;
            padding: 16px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--navy);
        }

        .brand-icon {
            width: 46px;
            height: 46px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            color: white;
            background: var(--primary);
            font-size: 21px;
        }

        .brand-name {
            display: block;
            font-weight: 800;
            font-size: 1.03rem;
            letter-spacing: .3px;
        }

        .brand-subtitle {
            display: block;
            color: var(--muted);
            font-size: .77rem;
        }

        .nav-links {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 22px;
        }

        .nav-links a {
            color: #46536b;
            font-size: .92rem;
            font-weight: 600;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links .nav-button {
            background: var(--primary);
            color: white;
            padding: 10px 16px;
            border-radius: 9px;
        }

        .nav-links .nav-button:hover {
            background: var(--primary-dark);
            color: white;
        }

        .hero {
            position: relative;
            overflow: hidden;
            color: white;
            background:
                radial-gradient(circle at 85% 20%, rgba(88, 122, 255, .3), transparent 28%),
                linear-gradient(125deg, #101a31, #1b2e58 65%, #273f7b);
        }

        .hero-inner {
            max-width: 1200px;
            margin: auto;
            padding: 76px 24px 82px;
            display: grid;
            grid-template-columns: 1.2fr .8fr;
            gap: 50px;
            align-items: center;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 7px 12px;
            border: 1px solid rgba(255,255,255,.2);
            background: rgba(255,255,255,.08);
            border-radius: 30px;
            color: #dbe5ff;
            font-size: .83rem;
            margin-bottom: 22px;
        }

        .hero h1 {
            max-width: 720px;
            font-size: clamp(2.1rem, 5vw, 3.6rem);
            line-height: 1.13;
            letter-spacing: -1.2px;
            margin-bottom: 22px;
        }

        .hero h1 span {
            color: #91adff;
        }

        .hero-description {
            max-width: 630px;
            color: #d3dced;
            font-size: 1.05rem;
            margin-bottom: 28px;
        }

        .hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 46px;
            padding: 12px 18px;
            border-radius: 9px;
            font-size: .93rem;
            font-weight: 700;
            transition: transform .2s, background .2s;
        }

        .button:hover {
            transform: translateY(-2px);
        }

        .button-light {
            background: white;
            color: var(--navy);
        }

        .button-light:hover {
            background: #eaf0ff;
            color: var(--navy);
        }

        .button-outline {
            border: 1px solid rgba(255,255,255,.35);
            color: white;
        }

        .button-outline:hover {
            background: rgba(255,255,255,.1);
            color: white;
        }

        .hero-visual {
            min-height: 300px;
            display: grid;
            place-items: center;
            position: relative;
        }

        .visual-card {
            width: min(100%, 350px);
            padding: 27px;
            border-radius: 20px;
            background: rgba(255,255,255,.09);
            border: 1px solid rgba(255,255,255,.17);
            backdrop-filter: blur(8px);
            box-shadow: 0 25px 65px rgba(0,0,0,.18);
        }

        .visual-icon {
            width: 66px;
            height: 66px;
            display: grid;
            place-items: center;
            border-radius: 18px;
            background: #91adff;
            color: #13234a;
            font-size: 29px;
            margin-bottom: 20px;
        }

        .visual-card h2 {
            font-size: 1.3rem;
            margin-bottom: 8px;
        }

        .visual-card p {
            color: #d3dced;
            font-size: .92rem;
        }

        .visual-stat {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-top: 24px;
        }

        .visual-stat div {
            padding: 13px;
            background: rgba(255,255,255,.08);
            border-radius: 10px;
        }

        .visual-stat strong {
            display: block;
            font-size: 1.05rem;
        }

        .visual-stat span {
            color: #c9d4eb;
            font-size: .79rem;
        }

        .section {
            max-width: 1200px;
            margin: auto;
            padding: 65px 24px;
        }

        .section-heading {
            text-align: center;
            max-width: 700px;
            margin: 0 auto 34px;
        }

        .section-kicker {
            color: var(--primary);
            text-transform: uppercase;
            font-size: .79rem;
            font-weight: 800;
            letter-spacing: 1.3px;
            margin-bottom: 9px;
        }

        .section-heading h2 {
            color: var(--navy);
            font-size: clamp(1.7rem, 4vw, 2.35rem);
            line-height: 1.25;
            margin-bottom: 12px;
        }

        .section-heading p {
            color: var(--muted);
        }

        .module-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 19px;
        }

        .module-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 15px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            min-height: 240px;
            box-shadow: 0 7px 24px rgba(26, 40, 75, .035);
            transition: transform .2s, box-shadow .2s;
        }

        .module-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 34px rgba(26, 40, 75, .09);
        }

        .module-icon {
            width: 49px;
            height: 49px;
            display: grid;
            place-items: center;
            background: #edf1ff;
            color: var(--primary);
            border-radius: 13px;
            font-size: 21px;
            margin-bottom: 19px;
        }

        .module-card h3 {
            font-size: 1.08rem;
            margin-bottom: 8px;
            color: var(--navy);
        }

        .module-card p {
            color: var(--muted);
            font-size: .9rem;
            margin-bottom: 20px;
            flex: 1;
        }

        .module-link {
            color: var(--primary);
            font-size: .9rem;
            font-weight: 750;
        }

        .module-link i {
            margin-left: 5px;
            transition: transform .2s;
        }

        .module-link:hover i {
            transform: translateX(4px);
        }

        .video-section {
            background: white;
            border-top: 1px solid var(--border);
            border-bottom: 1px solid var(--border);
        }

        .video-layout {
            display: grid;
            grid-template-columns: 1.3fr .7fr;
            gap: 35px;
            align-items: center;
        }


        /* Conteneur de la vidéo */
        .video-frame {
            width: 100%;
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 15px;
            box-sizing: border-box;
        }

        /* Vidéo adaptée à l'écran */
        .video-frame video {
            display: block;
            width: 100%;
            height: auto;
            aspect-ratio: 16 / 9;
            object-fit: contain;
            border-radius: 12px;
            background-color: #000;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        /* Sur les petits écrans */
        @media (max-width: 768px) {
            .video-frame {
                padding: 0 8px;
                margin: 20px auto;
            }

            .video-frame video {
                border-radius: 8px;
            }
        }


        .video-caption {
            padding: 14px 17px;
            color: #d7e0f2;
            font-size: .84rem;
            background: #172442;
        }

        .video-copy .section-kicker {
            margin-bottom: 10px;
        }

        .video-copy h2 {
            font-size: clamp(1.65rem, 3.5vw, 2.3rem);
            color: var(--navy);
            line-height: 1.25;
            margin-bottom: 16px;
        }

        .video-copy p {
            color: var(--muted);
            margin-bottom: 16px;
        }

        .video-points {
            list-style: none;
            display: grid;
            gap: 12px;
            margin-top: 20px;
        }

        .video-points li {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            color: #46536b;
            font-size: .92rem;
        }

        .video-points i {
            color: #2d9a69;
            margin-top: 5px;
        }

        .presentation-tip {
            margin-top: 23px;
            padding: 15px;
            background: #f3f6ff;
            border-left: 3px solid var(--primary);
            border-radius: 8px;
            color: #53617a;
            font-size: .86rem;
        }

        .project-banner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 25px;
            padding: 30px;
            border-radius: 17px;
            background: linear-gradient(120deg, #eaf0ff, #f6f8ff);
            border: 1px solid #dce5ff;
        }

        .project-banner h2 {
            color: var(--navy);
            font-size: 1.4rem;
            margin-bottom: 7px;
        }

        .project-banner p {
            color: var(--muted);
            font-size: .94rem;
        }

        .site-footer {
            background: var(--navy);
            color: white;
            padding: 30px 24px;
        }

        .footer-inner {
            max-width: 1200px;
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .footer-inner p {
            color: #bdc8dd;
            font-size: .87rem;
        }

        .footer-brand {
            font-weight: 750;
        }

        @media (max-width: 1000px) {
            .module-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .hero-inner {
                grid-template-columns: 1fr .75fr;
                gap: 25px;
            }

            .video-layout {
                grid-template-columns: 1fr;
            }

            .video-copy {
                max-width: 720px;
            }
        }

        @media (max-width: 700px) {
            .nav-container {
                align-items: flex-start;
                flex-direction: column;
            }

            .nav-links {
                gap: 15px;
            }

            .hero-inner {
                grid-template-columns: 1fr;
                padding-top: 55px;
                padding-bottom: 55px;
            }

            .hero-visual {
                min-height: auto;
            }

            .visual-card {
                width: 100%;
            }

            .section {
                padding: 48px 18px;
            }

            .project-banner {
                align-items: flex-start;
                flex-direction: column;
                padding: 23px;
            }
        }

        @media (max-width: 440px) {
            .module-grid {
                grid-template-columns: 1fr;
            }

            .module-card {
                min-height: 205px;
            }

            .hero h1 {
                letter-spacing: -.5px;
            }

            .hero-actions .button {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<header class="site-header">
    <nav class="nav-container" aria-label="Navigation principale">

        <a href="index.php" class="brand">
            <span class="brand-icon">
                <i class="fa-solid fa-layer-group"></i>
            </span>
            <span>
                <span class="brand-name">GESTION DES COMMANDES</span>
                <span class="brand-subtitle">Application universitaire · 2026</span>
            </span>
        </a>

        <div class="nav-links">
            <a href="#fonctionnalites">Fonctionnalités</a>
            <a href="#presentation">Présentation vidéo</a>
            <a href="dashboard/index.php" class="nav-button">
                <i class="fa-solid fa-chart-line"></i>
                Ouvrir l'application
            </a>
        </div>

    </nav>
</header>

<main>

    <section class="hero">
        <div class="hero-inner">

            <div>
                <div class="eyebrow">
                    <i class="fa-solid fa-graduation-cap"></i>
                    Projet universitaire · Année 2026
                </div>

                <h1>
                    Une gestion des commandes
                    <span>simple, moderne et efficace.</span>
                </h1>

                <p class="hero-description">
                    Une application web conçue pour organiser les produits,
                    suivre les clients, gérer les commandes et consulter
                    les principales statistiques depuis une interface unique.
                </p>

                <div class="hero-actions">
                    <a href="dashboard/index.php" class="button button-light">
                        <i class="fa-solid fa-rocket"></i>
                        Découvrir l'application
                    </a>

                    <a href="#presentation" class="button button-outline">
                        <i class="fa-solid fa-circle-play"></i>
                        Voir la présentation
                    </a>
                </div>
            </div>

            <div class="hero-visual">
                <div class="visual-card">
                    <div class="visual-icon">
                        <i class="fa-solid fa-chart-pie"></i>
                    </div>

                    <h2>Tout au même endroit</h2>

                    <p>
                        Les informations essentielles de gestion,
                        réunies dans une interface claire et organisée.
                    </p>

                    <div class="visual-stat">
                        <div>
                            <strong>Produits</strong>
                            <span>Catalogue</span>
                        </div>

                        <div>
                            <strong>Commandes</strong>
                            <span>Suivi</span>
                        </div>

                        <div>
                            <strong>Clients</strong>
                            <span>Répertoire</span>
                        </div>

                        <div>
                            <strong>Statistiques</strong>
                            <span>Tableau de bord</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="section" id="fonctionnalites">

        <div class="section-heading">
            <div class="section-kicker">Les fonctionnalités</div>

            <h2>Une seule application, quatre espaces de travail</h2>

            <p>
                Accédez rapidement aux différentes parties de la gestion
                des commandes.
            </p>
        </div>

        <div class="module-grid">

            <article class="module-card">
                <div class="module-icon">
                    <i class="fa-solid fa-box-open"></i>
                </div>

                <h3>Gestion des produits</h3>

                <p>
                    Consultez les références, modifiez les informations
                    et suivez les quantités en stock.
                </p>

                <a href="produits/liste.php" class="module-link">
                    Accéder aux produits
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </article>

            <article class="module-card">
                <div class="module-icon">
                    <i class="fa-solid fa-cart-shopping"></i>
                </div>

                <h3>Gestion des commandes</h3>

                <p>
                    Consultez les commandes et gérez les produits
                    associés à chaque commande.
                </p>

                <a href="commandes/liste.php" class="module-link">
                    Accéder aux commandes
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </article>

            <article class="module-card">
                <div class="module-icon">
                    <i class="fa-solid fa-users"></i>
                </div>

                <h3>Gestion des clients</h3>

                <p>
                    Retrouvez les clients et consultez les informations
                    enregistrées dans le système.
                </p>

                <a href="clients/liste.php" class="module-link">
                    Accéder aux clients
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </article>

            <article class="module-card">
                <div class="module-icon">
                    <i class="fa-solid fa-chart-column"></i>
                </div>

                <h3>Tableau de bord</h3>

                <p>
                    Consultez les indicateurs et les statistiques
                    disponibles dans l'application.
                </p>

                <a href="dashboard/index.php" class="module-link">
                    Consulter les statistiques
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </article>

        </div>
    </section>

    <section class="video-section" id="presentation">
        <div class="section video-layout">


            <div class="video-frame">
                <video controls preload="metadata" playsinline>
                    <source
                        src="videos/presentation-etudiants.mp4"
                        type="video/mp4"
                    >

                    Votre navigateur ne prend pas en charge la lecture vidéo.
                </video>

                <div class="video-caption">
                    <i class="fa-solid fa-graduation-cap"></i>
                    Présentation du TP-examen par les étudiants
                </div>
            </div>

            <div class="video-copy">
                <div class="section-kicker">TP-Examen universitaire · 2026</div>

                <h2>Présentation et démonstration du travail réalisé</h2>

                <p>
                    Cette vidéo présente le travail pratique réalisé dans le cadre
                    de notre TP-examen universitaire. Elle met en évidence les
                    objectifs du travail, les fonctionnalités de l'application
                    développée et les connaissances informatiques mises en pratique.
                </p>

                <ul class="video-points">
                    <li>
                        <i class="fa-solid fa-circle-check"></i>
                        <span>Présentation du sujet et des objectifs du TP-examen.</span>
                    </li>

                    <li>
                        <i class="fa-solid fa-circle-check"></i>
                        <span>Démonstration de l'application et de ses principales fonctionnalités.</span>
                    </li>

                    <li>
                        <i class="fa-solid fa-circle-check"></i>
                        <span>Mise en pratique des compétences en conception et développement informatique.</span>
                    </li>
                </ul>

                <div class="presentation-tip">
                    <strong>Cadre académique :</strong>
                    ce travail a été réalisé dans un objectif d'apprentissage,
                    d'application des connaissances théoriques et d'évaluation
                    des compétences acquises au cours de la formation.
                </div>
            </div>

            </div>
            </section>

            <section class="section">
                <div class="project-banner">
                    <div>
                        <h2>Application réalisée dans le cadre du TP-examen</h2>

                        <p>
                            Explorez les fonctionnalités développées et observez
                            leur mise en œuvre à travers l'application.
                        </p>
                    </div>

                    <a href="dashboard/index.php"
                       class="button button-light"
                       style="background:#3457d5;color:#fff;">
                        <i class="fa-solid fa-laptop-code"></i>
                        Consulter l'application
                    </a>
                </div>
            </section>

            </main>

            <footer class="site-footer">
                <div class="footer-inner">
                    <p class="footer-brand">
                        <i class="fa-solid fa-layer-group"></i>
                        Gestion des commandes
                    </p>

                    <p>TP-Examen universitaire · 2026</p>

                    <p>Travail pratique réalisé dans le cadre de la formation informatique.</p>
                </div>


</footer>

<script src="js/bootstrap.js"></script>

</body>
</html>
