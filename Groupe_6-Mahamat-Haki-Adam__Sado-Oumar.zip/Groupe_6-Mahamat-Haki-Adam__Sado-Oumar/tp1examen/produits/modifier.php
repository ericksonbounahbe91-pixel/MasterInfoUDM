<?php

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| 1. Vérification de l'identifiant
|--------------------------------------------------------------------------
*/

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($id === false || $id === null || $id <= 0) {
    http_response_code(400);
    exit('Identifiant de produit invalide.');
}

$idProd = $id;

/*
|--------------------------------------------------------------------------
| 2. Fonction de protection HTML
|--------------------------------------------------------------------------
*/

function e($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| 3. Récupération du produit
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT idProd, designProd, qteStock, prixUProd, photoProd
    FROM Produit
    WHERE idProd = ?
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$idProd]);

$produit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$produit) {
    http_response_code(404);
    exit('Produit introuvable.');
}

/*
|--------------------------------------------------------------------------
| 4. Initialisation du formulaire
|--------------------------------------------------------------------------
*/

$designProd = (string) $produit['designProd'];
$qteStock = (string) $produit['qteStock'];
$prixUProd = str_replace(
    '.',
    ',',
    (string) $produit['prixUProd']
);

$message = '';
$typeMessage = '';

/*
|--------------------------------------------------------------------------
| 5. Traitement du formulaire
|--------------------------------------------------------------------------
*/


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $designProd = trim((string) ($_POST['designProd'] ?? ''));
    $qteSaisi = trim((string) ($_POST['qteStock'] ?? ''));
    $prixSaisi = trim((string) ($_POST['prixUProd'] ?? ''));

    $qteValide = filter_var($qteSaisi, FILTER_VALIDATE_INT);
    $prixNormalise = str_replace(',', '.', $prixSaisi);

    $prixValide = preg_match(
        '/^\d+(?:\.\d{1,2})?$/',
        $prixNormalise
    ) === 1;

    $qteStock = $qteSaisi;
    $prixUProd = $prixSaisi;

    // Conserver la photo actuelle par défaut.
    $photoFinale = $produit['photoProd'];

    // Vérifier si une nouvelle photo a été sélectionnée.
    $fichierPhoto = $_FILES['photoProd'] ?? null;
    $nouvellePhoto = false;
    $nomFichier = '';

    if ($fichierPhoto && $fichierPhoto['error'] !== UPLOAD_ERR_NO_FILE) {

        if ($fichierPhoto['error'] !== UPLOAD_ERR_OK) {
            $message = 'Erreur pendant l’envoi de la photo.';
            $typeMessage = 'erreur';

        } elseif ($fichierPhoto['size'] > 5 * 1024 * 1024) {
            $message = 'La photo ne doit pas dépasser 5 Mo.';
            $typeMessage = 'erreur';

        } else {
            $extensionAutorisee = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp'
            ];

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $typeReel = $finfo->file($fichierPhoto['tmp_name']);

            if (
                !isset($extensionAutorisee[$typeReel]) ||
                getimagesize($fichierPhoto['tmp_name']) === false
            ) {
                $message = 'Format invalide. Utilisez une image JPG, PNG ou WEBP.';
                $typeMessage = 'erreur';

            } else {
                $nomFichier = bin2hex(random_bytes(16))
                    . '.'
                    . $extensionAutorisee[$typeReel];

                $dossierPhoto = dirname(__DIR__) . '/uploads/produits';

                if (!is_dir($dossierPhoto) || !is_writable($dossierPhoto)) {
                    $message = 'Le dossier de stockage des photos est inaccessible.';
                    $typeMessage = 'erreur';
                } else {
                    $photoFinale = '../uploads/produits/' . $nomFichier;
                    $nouvellePhoto = true;
                }
            }
        }
    }

    if ($message === '' && $designProd === '') {
        $message = 'La désignation du produit est obligatoire.';
        $typeMessage = 'erreur';

    } elseif ($message === '' && mb_strlen($designProd, 'UTF-8') > 150) {
        $message = 'La désignation ne doit pas dépasser 150 caractères.';
        $typeMessage = 'erreur';

    } elseif (
        $message === '' &&
        ($qteValide === false || $qteValide === null || $qteValide < 0)
    ) {
        $message = 'La quantité doit être un entier positif ou nul.';
        $typeMessage = 'erreur';

    } elseif ($message === '' && !$prixValide) {
        $message = 'Le prix doit être valide avec au maximum deux décimales.';
        $typeMessage = 'erreur';

    } elseif ($message === '' && (float) $prixNormalise < 0) {
        $message = 'Le prix ne peut pas être négatif.';
        $typeMessage = 'erreur';
    }

    if ($message === '') {
        try {
            // Déplacer la photo seulement après validation du formulaire.
            if ($nouvellePhoto) {
                $cheminDestination = dirname(__DIR__)
                    . '/uploads/produits/'
                    . $nomFichier;

                if (!move_uploaded_file(
                    $fichierPhoto['tmp_name'],
                    $cheminDestination
                )) {
                    throw new RuntimeException(
                        'Impossible d’enregistrer la photo.'
                    );
                }
            }

            $sql = "
                UPDATE Produit
                SET designProd = ?,
                    qteStock = ?,
                    prixUProd = ?,
                    photoProd = ?
                WHERE idProd = ?
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $designProd,
                $qteValide,
                $prixNormalise,
                $photoFinale,
                $idProd
            ]);

            header('Location: liste.php?modification=succes');
            exit;

        } catch (Throwable $ex) {
            error_log(
                'Erreur modification produit : ' . $ex->getMessage()
            );

            // Supprimer la nouvelle image si l'enregistrement échoue.
            if ($nouvellePhoto && isset($cheminDestination)
                && is_file($cheminDestination)) {
                unlink($cheminDestination);
            }

            $message = 'Impossible d’enregistrer les modifications. Veuillez réessayer.';
            $typeMessage = 'erreur';
        }
    }
}

/*
|--------------------------------------------------------------------------
| 6. Valeurs de présentation
|--------------------------------------------------------------------------
*/

$prixActuel = number_format(
    (float) $produit['prixUProd'],
    2,
    ',',
    ' '
);

$nomProduit = (string) $produit['designProd'];

$initiale = mb_strtoupper(
    mb_substr($nomProduit, 0, 1, 'UTF-8'),
    'UTF-8'
);

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Modifier un produit | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

    <style>
        /* =========================================
           EN-TÊTE
        ========================================= */

        .edit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 18px;
            margin-bottom: 28px;
        }

        .edit-title {
            margin: 0 0 7px;
            color: var(--app-text, #202b3c);
            font-size: clamp(1.5rem, 3vw, 2rem);
            font-weight: 750;
        }

        .edit-subtitle {
            margin: 0;
            color: var(--app-muted, #8490a5);
            line-height: 1.6;
        }

        /* =========================================
           DISPOSITION
        ========================================= */

        .edit-layout {
            display: grid;
            grid-template-columns: minmax(0, 1.6fr) minmax(240px, .8fr);
            gap: 24px;
            align-items: start;
        }

        .edit-panel {
            min-width: 0;
            padding: 28px;
            background: #fff;
            border: 1px solid #e7ebf3;
            border-radius: 16px;
            box-shadow: 0 8px 28px rgba(20, 35, 70, .045);
        }

        .edit-panel h2 {
            margin: 0 0 8px;
            color: #202b3c;
            font-size: 1.12rem;
        }

        .edit-panel h2 i {
            margin-right: 8px;
            color: #3457d5;
        }

        .panel-description {
            margin: 0 0 25px;
            color: #8490a5;
            font-size: .92rem;
            line-height: 1.6;
        }

        /* =========================================
           FORMULAIRE
        ========================================= */

        .edit-field {
            margin-bottom: 21px;
        }

        .edit-field label {
            display: block;
            margin-bottom: 9px;
            color: #344054;
            font-size: .92rem;
            font-weight: 650;
        }

        .required-star {
            color: #d92d20;
        }

        .edit-field input {
            display: block;
            width: 100%;
            min-height: 47px;
            padding: 11px 13px;
            border: 1px solid #dce2ed;
            border-radius: 9px;
            background: #fff;
            color: #202b3c;
            font: inherit;
            box-sizing: border-box;
            transition: border-color .2s, box-shadow .2s;
        }

        .edit-field input:focus {
            outline: none;
            border-color: #3457d5;
            box-shadow: 0 0 0 3px rgba(52, 87, 213, .12);
        }

        .edit-help {
            display: block;
            margin-top: 7px;
            color: #8490a5;
            font-size: .82rem;
            line-height: 1.5;
        }

        /* =========================================
           MESSAGES
        ========================================= */

        .edit-alert {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 14px 15px;
            margin-bottom: 22px;
            border-radius: 9px;
            font-size: .93rem;
            line-height: 1.6;
        }

        .edit-alert.erreur {
            color: #a61b29;
            background: #fff0f1;
            border: 1px solid #ffd3d7;
        }

        /* =========================================
           BOUTONS
        ========================================= */

        .edit-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 28px;
        }

        .edit-button {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 9px;
            min-height: 45px;
            padding: 11px 17px;
            border: 0;
            border-radius: 9px;
            text-decoration: none;
            font-weight: 650;
            font-size: .92rem;
            cursor: pointer;
            transition: background .2s, transform .2s;
        }

        .edit-button:hover {
            transform: translateY(-1px);
        }

        .edit-button-primary {
            background: #3457d5;
            color: #fff;
        }

        .edit-button-primary:hover {
            background: #243b91;
            color: #fff;
        }

        .edit-button-secondary {
            background: #f1f4f9;
            color: #344054;
        }

        .edit-button-secondary:hover {
            background: #e5eaf3;
            color: #202b3c;
        }

        /* =========================================
           RÉSUMÉ DU PRODUIT
        ========================================= */

        .product-summary {
            text-align: center;
        }

        .product-summary-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 76px;
            height: 76px;
            margin: 0 auto 18px;
            border-radius: 20px;
            background: #edf1ff;
            color: #3457d5;
            font-size: 30px;
        }

        .product-summary h3 {
            margin: 0 0 8px;
            color: #202b3c;
            font-size: 1.1rem;
            overflow-wrap: anywhere;
        }

        .product-reference {
            display: inline-block;
            margin-bottom: 22px;
            color: #8490a5;
            font-size: .85rem;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            padding: 15px 0;
            border-top: 1px solid #edf0f5;
            text-align: left;
        }

        .summary-label {
            color: #8490a5;
            font-size: .9rem;
        }

        .summary-value {
            color: #202b3c;
            font-weight: 700;
            text-align: right;
            overflow-wrap: anywhere;
        }

        .edit-note {
            margin-top: 20px;
            padding: 14px;
            border-radius: 10px;
            background: #f5f7fc;
            color: #65728a;
            font-size: .87rem;
            line-height: 1.7;
        }

        .edit-note i {
            margin-right: 5px;
            color: #3457d5;
        }

        /* =========================================
           PIED DE PAGE
        ========================================= */

        .edit-footer {
            padding: 25px 10px 10px;
            color: #8490a5;
            text-align: center;
            font-size: .84rem;
            line-height: 1.6;
        }

        .edit-footer strong {
            color: #3457d5;
        }

        /* =========================================
           RESPONSIVE
        ========================================= */

        @media (max-width: 1000px) {
            .edit-layout {
                grid-template-columns: minmax(0, 1fr);
            }

            .edit-layout > aside {
                order: 2;
            }
        }

        @media (max-width: 600px) {
            .edit-header {
                align-items: stretch;
            }

            .edit-header > a {
                width: 100%;
                box-sizing: border-box;
            }

            .edit-panel {
                padding: 20px;
            }

            .edit-actions {
                flex-direction: column;
            }

            .edit-button {
                width: 100%;
                box-sizing: border-box;
            }

            .summary-row {
                gap: 8px;
            }
        }
    </style>
</head>

<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <!-- En-tête de la page -->
    <header class="edit-header">
        <div>
            <h1 class="edit-title">
                <i class="fa-solid fa-pen-to-square"></i>
                Modifier un produit
            </h1>

            <p class="edit-subtitle">
                Mettez à jour les informations du produit dans votre catalogue.
            </p>
        </div>

        <a href="liste.php" class="edit-button edit-button-secondary">
            <i class="fa-solid fa-arrow-left"></i>
            Retour aux produits
        </a>
    </header>

    <div class="edit-layout">

        <!-- Formulaire de modification -->
        <section class="edit-panel">

            <h2>
                <i class="fa-solid fa-box"></i>
                Informations du produit
            </h2>

            <p class="panel-description">
                Modifiez les champs nécessaires, puis enregistrez.
            </p>

            <?php if ($message !== ''): ?>
                <div class="edit-alert <?= e($typeMessage) ?>" role="alert">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?= e($message) ?></span>
                </div>
            <?php endif; ?>

            <form method="POST"
                  action="modifier.php?id=<?= (int) $idProd ?>"
                  enctype="multipart/form-data">

                <div class="edit-field">
                    <label for="designProd">
                        Désignation du produit
                        <span class="required-star">*</span>
                    </label>

                    <input
                        type="text"
                        id="designProd"
                        name="designProd"
                        maxlength="255"
                        value="<?= e($designProd) ?>"
                        placeholder="Ex. : Ordinateur portable"
                        autocomplete="off"
                        required
                    >
                </div>

                <div class="edit-field">
                    <label for="qteStock">
                        Quantité en stock
                        <span class="required-star">*</span>
                    </label>

                    <input
                        type="number"
                        id="qteStock"
                        name="qteStock"
                        min="0"
                        step="1"
                        value="<?= e($qteStock) ?>"
                        required
                    >

                    <span class="edit-help">
                        Saisissez un nombre entier positif ou nul.
                    </span>
                </div>

                <div class="edit-field">
                    <label for="prixUProd">
                        Prix unitaire (FCFA)
                        <span class="required-star">*</span>
                    </label>

                    <input
                        type="text"
                        id="prixUProd"
                        name="prixUProd"
                        inputmode="decimal"
                        pattern="[0-9]+([.,][0-9]{1,2})?"
                        value="<?= e($prixUProd) ?>"
                        placeholder="Ex. : 1500 ou 1500,50"
                        required
                    >

                    <span class="edit-help">
                        Utilisez un point ou une virgule pour les décimales.
                        Prix actuellement enregistré :
                        <?= e($prixActuel) ?> FCFA.
                    </span>
                </div>
                <div class="edit-field">
                    <label for="photoProd">Photo du produit</label>

                    <input
                        type="file"
                        id="photoProd"
                        name="photoProd"
                        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                    >

                    <span class="edit-help">
                        Formats autorisés : JPG, PNG et WEBP. Taille maximale : 5 Mo.
                        Laissez vide pour conserver la photo actuelle.
                    </span>
                </div>

                <div class="edit-actions">

                    <button
                        type="submit"
                        class="edit-button edit-button-primary"
                    >
                        <i class="fa-solid fa-floppy-disk"></i>
                        Enregistrer les modifications
                    </button>

                    <a
                        href="liste.php"
                        class="edit-button edit-button-secondary"
                    >
                        <i class="fa-solid fa-xmark"></i>
                        Annuler
                    </a>

                </div>

            </form>

        </section>

        <!-- Résumé du produit -->
        <aside class="edit-panel">

            <div class="product-summary">

                <div class="product-summary-icon">
                    <?php if (!empty($produit['photoProd'])): ?>
                        <img
                            src="<?= e($produit['photoProd']) ?>"
                            alt="<?= e($nomProduit) ?>"
                            style="width:100%;height:100%;object-fit:contain;border-radius:12px;"
                        >
                    <?php else: ?>
                        <i class="fa-solid fa-box-open"></i>
                    <?php endif; ?>
                </div>

                <h3><?= e($nomProduit) ?></h3>

                <span class="product-reference">
                    Référence produit #<?= (int) $produit['idProd'] ?>
                </span>

            </div>

            <div class="summary-row">
                <span class="summary-label">Stock enregistré</span>

                <span class="summary-value">
                    <?= number_format(
                        (int) $produit['qteStock'],
                        0,
                        ',',
                        ' '
                    ) ?>
                </span>
            </div>

            <div class="summary-row">
                <span class="summary-label">Prix enregistré</span>

                <span class="summary-value">
                    <?= e($prixActuel) ?> FCFA
                </span>
            </div>

            <div class="summary-row">
                <span class="summary-label">Identifiant</span>

                <span class="summary-value">
                    <?= (int) $produit['idProd'] ?>
                </span>
            </div>

            <div class="edit-note">
                <i class="fa-solid fa-circle-info"></i>

                <strong>À savoir :</strong>

                la modification du stock remplace la quantité actuelle.
                Vérifiez le stock réel avant d'enregistrer.

                <br><br>

                Vous pouvez ajouter une photo ou remplacer la photo actuelle
                en sélectionnant un nouveau fichier.
            </div>

        </aside>

    </div>

    <footer class="edit-footer">
        TP Examen — Gestion d'une ligne de commande
        <br>
        Développé avec <strong>YaraïDigital</strong>
    </footer>

</main>

</body>
</html>
