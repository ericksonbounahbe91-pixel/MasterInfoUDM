
<?php
require_once __DIR__ . '/../config/database.php';

$sql = "SELECT * FROM Produit ORDER BY idProd DESC";
$stmt = $pdo->query($sql);
$produits = $stmt->fetchAll();

$totalProduits = count($produits);
$valeurStock = 0;
$stockTotal = 0;
$stockFaible = 0;

foreach ($produits as $produit) {
    $stock = (float) $produit['qteStock'];
    $prix = (float) $produit['prixUProd'];

    $stockTotal += $stock;
    $valeurStock += $stock * $prix;

    if ($stock <= 5) {
        $stockFaible++;
    }
}

function e($valeur): string
{
    return htmlspecialchars((string) $valeur, ENT_QUOTES, 'UTF-8');
}

function nombre($valeur): string
{
    return number_format((float) $valeur, 0, ',', ' ');
}

function montant($valeur): string
{
    return number_format((float) $valeur, 2, ',', ' ') . ' FCFA';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

    <style>
        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
            margin-bottom: 26px;
        }

        .page-heading h1 {
            margin: 0 0 8px;
            font-size: clamp(1.5rem, 3vw, 2rem);
            color: var(--app-text, #202b3c);
        }

        .page-heading p {
            margin: 0;
            color: var(--app-muted, #8490a5);
        }

        .product-stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 26px;
        }

        .product-stat {
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
            padding: 22px;
            min-width: 0;
        }

        .product-stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 18px;
        }

        .product-stat-label {
            font-size: .9rem;
            color: #7b8799;
        }

        .product-stat-icon {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: #edf2ff;
            color: #3457d5;
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .product-stat strong {
            display: block;
            font-size: clamp(1.2rem, 2.2vw, 1.8rem);
            color: #202b3c;
            overflow-wrap: anywhere;
        }

        .product-panel {
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
            overflow: hidden;
        }

        .product-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            padding: 22px;
            border-bottom: 1px solid #edf0f5;
        }

        .product-panel-header h2 {
            margin: 0 0 5px;
            font-size: 1.1rem;
            color: #202b3c;
        }

        .product-panel-header p {
            margin: 0;
            color: #8490a5;
            font-size: .88rem;
        }

        .product-search {
            width: min(100%, 300px);
            padding: 11px 13px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            font-size: .9rem;
            outline: none;
        }

        .product-search:focus {
            border-color: #3457d5;
            box-shadow: 0 0 0 3px rgba(52, 87, 213, .10);
        }

        .product-table-wrap {
            overflow-x: auto;
        }

        .product-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 680px;
        }

        .product-table th {
            background: #f8f9fc;
            color: #748096;
            font-size: .76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .04em;
            padding: 15px 18px;
            text-align: left;
            white-space: nowrap;
        }

        .product-table td {
            padding: 15px 18px;
            border-top: 1px solid #edf0f5;
            color: #354155;
            vertical-align: middle;
        }

        .product-table tbody tr:hover {
            background: #fafbff;
        }

        .product-id {
            color: #8792a5;
            font-size: .86rem;
            font-weight: 600;
        }

        .product-name {
            font-weight: 700;
            color: #202b3c;
        }

        .product-image {
            width: 48px;
            height: 48px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #e7ebf3;
            display: block;
        }

        .product-image-placeholder {
            width: 48px;
            height: 48px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            background: #f0f3fa;
            color: #96a0b2;
            font-size: 1.2rem;
        }

        .stock-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: .8rem;
            font-weight: 700;
            background: #e8f7ee;
            color: #21834a;
            white-space: nowrap;
        }

        .stock-badge.low {
            background: #fff1e8;
            color: #c25c1a;
        }

        .product-price {
            font-weight: 700;
            white-space: nowrap;
        }

        .product-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 9px 12px;
            color: #3457d5;
            background: #edf2ff;
            border-radius: 8px;
            text-decoration: none;
            font-size: .85rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .product-action:hover {
            background: #dfe7ff;
        }

        .product-empty {
            text-align: center;
            padding: 48px 20px;
            color: #8490a5;
        }

        .product-empty i {
            display: block;
            font-size: 2rem;
            margin-bottom: 14px;
        }

        .product-table-footer {
            padding: 16px 22px;
            color: #8490a5;
            font-size: .85rem;
            border-top: 1px solid #edf0f5;
        }

        @media (max-width: 900px) {
            .product-stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 600px) {
            .product-stats {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .product-stat {
                padding: 17px;
            }

            .product-panel-header {
                padding: 17px;
            }

            .product-search {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <div class="page-heading">
        <div>
            <h1>Gestion des produits</h1>
            <p>Consultez les produits, leurs stocks et leurs prix unitaires.</p>
        </div>

        <a href="../index.php" class="product-action">
            <i class="fa-solid fa-house"></i>
            Retour à l'accueil
        </a>
    </div>

    <section class="product-stats">

        <article class="product-stat">
            <div class="product-stat-top">
                <span class="product-stat-label">Produits enregistrés</span>
                <span class="product-stat-icon">
                    <i class="fa-solid fa-boxes-stacked"></i>
                </span>
            </div>
            <strong><?= nombre($totalProduits) ?></strong>
        </article>

        <article class="product-stat">
            <div class="product-stat-top">
                <span class="product-stat-label">Quantité totale en stock</span>
                <span class="product-stat-icon">
                    <i class="fa-solid fa-cubes"></i>
                </span>
            </div>
            <strong><?= nombre($stockTotal) ?></strong>
        </article>

        <article class="product-stat">
            <div class="product-stat-top">
                <span class="product-stat-label">Valeur théorique du stock</span>
                <span class="product-stat-icon">
                    <i class="fa-solid fa-wallet"></i>
                </span>
            </div>
            <strong><?= montant($valeurStock) ?></strong>
        </article>

    </section>

    <section class="product-panel">

        <div class="product-panel-header">
            <div>
                <h2>Catalogue des produits</h2>
                <p>Liste des produits enregistrés dans la base de données.</p>
            </div>

            <input
                type="search"
                id="rechercheProduit"
                class="product-search"
                placeholder="Rechercher un produit..."
                aria-label="Rechercher un produit"
            >
        </div>

        <?php if ($totalProduits > 0): ?>

            <div class="product-table-wrap">
                <table class="product-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Produit</th>
                            <th>Stock</th>
                            <th>Prix unitaire</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="tableauProduits">
                    <?php foreach ($produits as $produit): ?>
                        <?php
                        $stockProduit = (float) $produit['qteStock'];
                        $stockEstFaible = $stockProduit <= 5;
                        ?>
                        <tr>
                            <td class="product-id">
                                <?= e($produit['idProd']) ?>
                            </td>

                            <td class="product-name">
                                <?= e($produit['designProd']) ?>
                            </td>

                            <td>
                                <span class="stock-badge <?= $stockEstFaible ? 'low' : '' ?>">
                                    <?= nombre($stockProduit) ?>
                                    <?= $stockEstFaible ? ' · Stock faible' : ' · Disponible' ?>
                                </span>
                            </td>

                            <td class="product-price">
                                <?= montant($produit['prixUProd']) ?>
                            </td>

                            <td>
                                <?php if (!empty($produit['photoProd'])): ?>
                                    <img
                                        class="product-image"
                                        src="<?= e($produit['photoProd']) ?>"
                                        alt="<?= e($produit['designProd']) ?>"
                                        loading="lazy"
                                    >
                                <?php else: ?>
                                    <span class="product-image-placeholder">
                                        <i class="fa-solid fa-image"></i>
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <a
                                    href="modifier.php?id=<?= rawurlencode((string) $produit['idProd']) ?>"
                                    class="product-action"
                                >
                                    <i class="fa-solid fa-pen-to-square"></i>
                                    Modifier
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="product-table-footer" id="compteurProduits">
                <?= nombre($totalProduits) ?> produit(s) affiché(s)
            </div>

        <?php else: ?>

            <div class="product-empty">
                <i class="fa-solid fa-box-open"></i>
                <strong>Aucun produit enregistré</strong>
                <p>Les produits apparaîtront ici lorsqu'ils seront présents dans la base.</p>
            </div>

        <?php endif; ?>

    </section>

    <footer style="text-align:center; color:#8490a5; padding:26px 10px; font-size:.85rem;">
        TP Examen — Gestion d'une ligne de commande
    </footer>

</main>

<script>
const rechercheProduit = document.getElementById('rechercheProduit');
const tableauProduits = document.getElementById('tableauProduits');
const compteurProduits = document.getElementById('compteurProduits');

if (rechercheProduit && tableauProduits) {
    rechercheProduit.addEventListener('input', function () {
        const terme = this.value.trim().toLocaleLowerCase('fr');
        const lignes = Array.from(tableauProduits.querySelectorAll('tr'));
        let visibles = 0;

        lignes.forEach(function (ligne) {
            const correspond = ligne.textContent.toLocaleLowerCase('fr').includes(terme);
            ligne.hidden = !correspond;

            if (correspond) {
                visibles++;
            }
        });

        if (compteurProduits) {
            compteurProduits.textContent =
                visibles + ' produit(s) affiché(s) sur ' + lignes.length;
        }
    });
}
</script>

</body>
</html>
