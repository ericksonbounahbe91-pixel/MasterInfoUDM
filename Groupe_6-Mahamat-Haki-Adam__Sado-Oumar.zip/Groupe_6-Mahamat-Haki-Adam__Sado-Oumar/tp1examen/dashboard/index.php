<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

/* =========================================================
   1. STATISTIQUES GENERALES
========================================================= */

$totalCommandes = (int) $pdo->query(
    "SELECT COUNT(*) FROM Commande"
)->fetchColumn();

$totalClients = (int) $pdo->query(
    "SELECT COUNT(*) FROM Client"
)->fetchColumn();

$totalProduits = (int) $pdo->query(
    "SELECT COUNT(*) FROM Produit"
)->fetchColumn();

$totalLignes = (int) $pdo->query(
    "SELECT COUNT(*) FROM ligneCommande"
)->fetchColumn();

$totalQuantites = (float) $pdo->query(
    "SELECT COALESCE(SUM(qteCmd), 0) FROM ligneCommande"
)->fetchColumn();

$totalMontant = (float) $pdo->query("
    SELECT COALESCE(
        SUM(lc.qteCmd * COALESCE(lc.prixUCmd, p.prixUProd)),
        0
    )
    FROM ligneCommande lc
    INNER JOIN Produit p ON p.idProd = lc.idProd
")->fetchColumn();

/* =========================================================
   2. PRODUIT LE PLUS COMMANDE
========================================================= */

$produitTop = $pdo->query("
    SELECT
        p.idProd,
        p.designProd,
        COALESCE(SUM(lc.qteCmd), 0) AS quantite
    FROM ligneCommande lc
    INNER JOIN Produit p ON p.idProd = lc.idProd
    GROUP BY p.idProd, p.designProd
    ORDER BY quantite DESC, p.designProd ASC
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC);

/* =========================================================
   3. STATISTIQUES PAR PRODUIT
========================================================= */

$statsProduits = $pdo->query("
    SELECT
        p.idProd,
        p.designProd,
        COALESCE(SUM(lc.qteCmd), 0) AS quantite,
        COALESCE(
            SUM(lc.qteCmd * COALESCE(lc.prixUCmd, p.prixUProd)),
            0
        ) AS montant
    FROM ligneCommande lc
    INNER JOIN Produit p ON p.idProd = lc.idProd
    GROUP BY p.idProd, p.designProd
    ORDER BY quantite DESC, p.designProd ASC
")->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   4. STATISTIQUES PAR COMMANDE
========================================================= */

$statsCommandes = $pdo->query("
    SELECT
        c.idCmd,
        c.dateCmd,
        cl.nomCli,
        cl.prenomCli,
        COALESCE(SUM(lc.qteCmd), 0) AS quantite,
        COALESCE(
            SUM(lc.qteCmd * COALESCE(lc.prixUCmd, p.prixUProd)),
            0
        ) AS montant
    FROM Commande c
    INNER JOIN Client cl ON cl.idCli = c.idCli
    INNER JOIN ligneCommande lc ON lc.idCmd = c.idCmd
    INNER JOIN Produit p ON p.idProd = lc.idProd
    GROUP BY
        c.idCmd,
        c.dateCmd,
        cl.nomCli,
        cl.prenomCli
    ORDER BY c.idCmd DESC
")->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   5. EVOLUTION MENSUELLE DES COMMANDES
========================================================= */

$commandesParMois = $pdo->query("
    SELECT
        DATE_FORMAT(dateCmd, '%Y-%m') AS mois,
        COUNT(*) AS nombre
    FROM Commande
    WHERE dateCmd IS NOT NULL
    GROUP BY DATE_FORMAT(dateCmd, '%Y-%m')
    ORDER BY mois ASC
")->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   6. FONCTIONS D'AFFICHAGE
========================================================= */

function e(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function nombre(mixed $value): string
{
    return number_format((float) $value, 0, ',', ' ');
}

function montant(mixed $value): string
{
    return number_format((float) $value, 2, ',', ' ');
}

function dateCommande(mixed $date): string
{
    if (empty($date)) {
        return 'Date indisponible';
    }

    $timestamp = strtotime((string) $date);

    return $timestamp !== false
        ? date('d/m/Y', $timestamp)
        : 'Date invalide';
}

/* =========================================================
   7. PREPARATION DES DONNEES DES GRAPHIQUES
========================================================= */

$produitsGraphique = array_slice($statsProduits, 0, 8);

$donneesProduits = json_encode(
    $produitsGraphique,
    JSON_HEX_TAG |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_HEX_AMP |
    JSON_INVALID_UTF8_SUBSTITUTE |
    JSON_THROW_ON_ERROR
);

$donneesCommandes = json_encode(
    $commandesParMois,
    JSON_HEX_TAG |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_HEX_AMP |
    JSON_INVALID_UTF8_SUBSTITUTE |
    JSON_THROW_ON_ERROR
);

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta
        name="description"
        content="Tableau de bord de gestion des commandes, des clients et des produits."
    >

    <title>Tableau de bord | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

    <style>
        :root {
            --dash-primary: #3457d5;
            --dash-primary-dark: #2442b0;
            --dash-primary-light: #edf1ff;
            --dash-green: #15966a;
            --dash-orange: #e99a24;
            --dash-purple: #805ad5;
            --dash-text: #202b3c;
            --dash-muted: #8490a5;
            --dash-border: #e7ebf3;
            --dash-background: #f4f6fb;
            --dash-white: #ffffff;
            --dash-radius: 16px;
            --dash-shadow: 0 5px 24px rgba(25, 40, 75, .045);
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--dash-background);
            color: var(--dash-text);
            font-family: "Segoe UI", Arial, sans-serif;
        }

        a {
            -webkit-tap-highlight-color: transparent;
        }

        /* CONTENU PRINCIPAL */

        .app-main {
            display: flex;
            flex-direction: column;
            min-width: 0;
            min-height: 100vh;
            margin-left: 255px;
            padding: 30px;
        }

        .dashboard-content {
            width: 100%;
            max-width: 1600px;
            margin: 0 auto;
        }

        /* EN-TETE */

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            width: 100%;
            margin: 0 0 26px;
            padding: 27px 28px;
            background: var(--dash-white);
            border: 1px solid var(--dash-border);
            border-radius: var(--dash-radius);
            box-shadow: var(--dash-shadow);
        }

        .dashboard-eyebrow {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0 0 9px;
            color: var(--dash-primary);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .dashboard-eyebrow::before {
            content: "";
            width: 8px;
            height: 8px;
            background: var(--dash-primary);
            border-radius: 50%;
        }

        .dashboard-title {
            margin: 0;
            font-size: clamp(25px, 3vw, 35px);
            font-weight: 800;
            letter-spacing: -1px;
            line-height: 1.2;
        }

        .dashboard-subtitle {
            margin: 10px 0 0;
            color: var(--dash-muted);
            font-size: 14px;
            line-height: 1.7;
        }

        .dashboard-date {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: #f8faff;
            border: 1px solid var(--dash-border);
            border-radius: 12px;
            color: var(--dash-muted);
            font-size: 13px;
            white-space: nowrap;
        }

        .dashboard-date i {
            color: var(--dash-primary);
            font-size: 16px;
        }

        /* TITRES DE SECTIONS */

        .section-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            margin: 0 0 15px;
        }

        .section-heading h2 {
            margin: 0;
            font-size: 18px;
            font-weight: 800;
        }

        .section-heading p {
            margin: 5px 0 0;
            color: var(--dash-muted);
            font-size: 12px;
            line-height: 1.6;
        }

        .section-label {
            padding: 7px 10px;
            color: var(--dash-primary);
            background: var(--dash-primary-light);
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
        }

        /* CARTES STATISTIQUES */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 28px;
        }

        .stat-card {
            position: relative;
            min-width: 0;
            overflow: hidden;
            padding: 23px;
            background: var(--dash-white);
            border: 1px solid var(--dash-border);
            border-radius: var(--dash-radius);
            box-shadow: var(--dash-shadow);
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(25, 40, 75, .08);
        }

        .stat-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 21px;
        }

        .stat-label {
            color: var(--dash-muted);
            font-size: 13px;
            font-weight: 600;
            line-height: 1.5;
        }

        .stat-icon {
            display: grid;
            width: 46px;
            height: 46px;
            flex-shrink: 0;
            place-items: center;
            border-radius: 14px;
            font-size: 18px;
        }

        .stat-icon.blue {
            color: var(--dash-primary);
            background: #edf1ff;
        }

        .stat-icon.green {
            color: var(--dash-green);
            background: #e8f8f1;
        }

        .stat-icon.orange {
            color: var(--dash-orange);
            background: #fff4e1;
        }

        .stat-icon.purple {
            color: var(--dash-purple);
            background: #f1eaff;
        }

        .stat-value {
            margin: 0;
            overflow-wrap: anywhere;
            font-size: clamp(24px, 2.2vw, 33px);
            font-weight: 800;
            letter-spacing: -1px;
            line-height: 1.25;
        }

        .stat-value.product-name {
            font-size: clamp(17px, 1.7vw, 22px);
            letter-spacing: -.3px;
        }

        .stat-description {
            margin-top: 9px;
            color: var(--dash-muted);
            font-size: 12px;
            line-height: 1.6;
        }

        /* RACCOURCIS */

        .quick-links {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 30px;
        }

        .quick-link {
            display: flex;
            align-items: center;
            gap: 13px;
            min-width: 0;
            padding: 17px;
            color: var(--dash-text);
            text-decoration: none;
            background: var(--dash-white);
            border: 1px solid var(--dash-border);
            border-radius: 14px;
            transition: .2s ease;
        }

        .quick-link:hover {
            color: var(--dash-primary);
            border-color: #c9d4ff;
            box-shadow: 0 8px 24px rgba(52, 87, 213, .08);
            transform: translateY(-2px);
        }

        .quick-link-icon {
            display: grid;
            width: 43px;
            height: 43px;
            flex-shrink: 0;
            place-items: center;
            color: var(--dash-primary);
            background: var(--dash-primary-light);
            border-radius: 12px;
            font-size: 17px;
        }

        .quick-link strong {
            display: block;
            font-size: 13px;
            line-height: 1.4;
        }

        .quick-link small {
            display: block;
            margin-top: 5px;
            color: var(--dash-muted);
            font-size: 11px;
            line-height: 1.4;
        }

        /* GRAPHIQUES */

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 28px;
        }

        .dashboard-panel {
            min-width: 0;
            overflow: hidden;
            background: var(--dash-white);
            border: 1px solid var(--dash-border);
            border-radius: var(--dash-radius);
            box-shadow: var(--dash-shadow);
        }

        .panel-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            padding: 22px 23px 17px;
        }

        .panel-heading h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 800;
            line-height: 1.45;
        }

        .panel-heading p {
            margin: 6px 0 0;
            color: var(--dash-muted);
            font-size: 12px;
            line-height: 1.6;
        }

        .chart-heading-icon {
            flex-shrink: 0;
            color: var(--dash-primary);
            font-size: 20px;
        }

        .chart-panel-wide {
            grid-column: 1 / -1;
        }

        .chart-container {
            position: relative;
            width: 100%;
            height: 300px;
            padding: 16px 22px 22px;
        }

        .chart-container-donut {
            height: 320px;
        }

        /* TABLEAUX */

        .table-section {
            margin-bottom: 25px;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
            scrollbar-width: thin;
            scrollbar-color: #c8d0df transparent;
        }

        .app-table {
            width: 100%;
            border-collapse: collapse;
            white-space: nowrap;
        }

        .app-table thead th {
            padding: 15px 20px;
            color: var(--dash-muted);
            background: #fafbfe;
            border-top: 1px solid var(--dash-border);
            border-bottom: 1px solid var(--dash-border);
            font-size: 10px;
            font-weight: 800;
            text-align: left;
            text-transform: uppercase;
            letter-spacing: .6px;
        }

        .app-table tbody td {
            padding: 16px 20px;
            border-bottom: 1px solid #f0f2f7;
            font-size: 13px;
            vertical-align: middle;
        }

        .app-table tbody tr:last-child td {
            border-bottom: 0;
        }

        .app-table tbody tr:hover {
            background: #fafbff;
        }

        .table-primary-text {
            font-weight: 700;
        }

        .table-secondary-text {
            margin-top: 5px;
            color: var(--dash-muted);
            font-size: 11px;
        }

        .table-badge {
            display: inline-block;
            padding: 7px 10px;
            color: var(--dash-primary);
            background: var(--dash-primary-light);
            border-radius: 8px;
            font-size: 11px;
            font-weight: 800;
        }

        .table-amount {
            color: #167653;
            font-weight: 800;
        }

        .empty-state {
            padding: 36px 20px !important;
            color: var(--dash-muted);
            text-align: center;
            white-space: normal;
            line-height: 1.7;
        }

        .empty-state i {
            display: block;
            margin-bottom: 12px;
            color: #b6c0d3;
            font-size: 27px;
        }

        /* PIED DE PAGE */

        .dashboard-footer {
            width: 100%;
            margin-top: auto;
            padding: 25px 12px 8px;
            border-top: 1px solid var(--dash-border);
            color: var(--dash-muted);
            font-size: 12px;
            line-height: 1.8;
            text-align: center;
        }

        .dashboard-footer strong {
            color: var(--dash-primary);
        }

        .footer-separator {
            margin: 0 6px;
            color: #c2c9d6;
        }

        /* TABLETTE */

        @media (max-width: 1100px) {
            .app-main {
                padding: 24px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .quick-links {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 900px) {
            .app-main {
                margin-left: 220px;
                padding: 20px;
            }

            .charts-grid {
                grid-template-columns: 1fr;
            }

            .chart-panel-wide {
                grid-column: auto;
            }
        }

        /* TELEPHONE */

        @media (max-width: 600px) {
            .app-main {
                width: 100%;
                margin-left: 0;
                padding: 16px 12px;
            }

            .dashboard-header {
                align-items: flex-start;
                padding: 20px 17px;
                margin-bottom: 20px;
            }

            .dashboard-title {
                font-size: 26px;
            }

            .dashboard-subtitle {
                font-size: 13px;
            }

            .dashboard-date {
                padding: 10px 12px;
                font-size: 12px;
            }

            .stats-grid,
            .quick-links {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .stat-card {
                padding: 18px;
            }

            .stat-top {
                margin-bottom: 15px;
            }

            .quick-link {
                padding: 15px;
            }

            .charts-grid {
                gap: 15px;
            }

            .panel-heading {
                padding: 18px 16px 14px;
            }

            .panel-heading h2 {
                font-size: 15px;
            }

            .chart-container,
            .chart-container-donut {
                height: 280px;
                padding: 12px;
            }

            .app-table thead th,
            .app-table tbody td {
                padding: 13px 14px;
            }

            .dashboard-footer {
                margin-top: 28px;
                padding: 20px 8px 8px;
            }
        }

        /* ACCESSIBILITE */

        a:focus-visible {
            outline: 3px solid rgba(52, 87, 213, .35);
            outline-offset: 3px;
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                transition-duration: .01ms !important;
                animation-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <div class="dashboard-content">

        <!-- EN-TETE PRINCIPAL -->
        <header class="dashboard-header">
            <div>
                <p class="dashboard-eyebrow">Espace de pilotage</p>

                <h1 class="dashboard-title">
                    Tableau de bord
                </h1>

                <p class="dashboard-subtitle">
                    Visualisez rapidement les commandes, les clients,
                    les produits et les performances de votre activité.
                </p>
            </div>

            <div class="dashboard-date">
                <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                <span><?= e(date('d/m/Y')) ?></span>
            </div>
        </header>

        <!-- STATISTIQUES -->
        <section aria-label="Statistiques générales">

            <div class="section-heading">
                <div>
                    <h2>Vue d'ensemble</h2>
                    <p>Les principaux indicateurs de votre activité.</p>
                </div>

                <span class="section-label">
                    <i class="fa-solid fa-chart-line" aria-hidden="true"></i>
                    Statistiques
                </span>
            </div>

            <div class="stats-grid">

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Commandes enregistrées</span>
                        <span class="stat-icon blue">
                            <i class="fa-solid fa-cart-shopping" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value"><?= nombre($totalCommandes) ?></p>

                    <div class="stat-description">
                        Nombre total de commandes créées
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Clients</span>
                        <span class="stat-icon green">
                            <i class="fa-solid fa-users" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value"><?= nombre($totalClients) ?></p>

                    <div class="stat-description">
                        Clients enregistrés dans l'application
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Produits</span>
                        <span class="stat-icon orange">
                            <i class="fa-solid fa-box-open" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value"><?= nombre($totalProduits) ?></p>

                    <div class="stat-description">
                        Produits disponibles dans le catalogue
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Quantités commandées</span>
                        <span class="stat-icon purple">
                            <i class="fa-solid fa-cubes-stacked" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value"><?= nombre($totalQuantites) ?></p>

                    <div class="stat-description">
                        Réparties sur <?= nombre($totalLignes) ?>
                        ligne(s) de commande
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Montant des commandes</span>
                        <span class="stat-icon green">
                            <i class="fa-solid fa-money-bill-wave" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value"><?= montant($totalMontant) ?></p>

                    <div class="stat-description">
                        FCFA, calculés à partir des prix des articles commandés
                    </div>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label">Produit le plus commandé</span>
                        <span class="stat-icon blue">
                            <i class="fa-solid fa-trophy" aria-hidden="true"></i>
                        </span>
                    </div>

                    <p class="stat-value product-name">
                        <?= $produitTop
                            ? e($produitTop['designProd'])
                            : 'Aucun produit' ?>
                    </p>

                    <div class="stat-description">
                        <?php if ($produitTop): ?>
                            <?= nombre($produitTop['quantite']) ?>
                            unité(s) commandée(s)
                        <?php else: ?>
                            Aucune ligne de commande enregistrée
                        <?php endif; ?>
                    </div>
                </article>

            </div>
        </section>

        <!-- RACCOURCIS -->
        <section aria-label="Accès rapides">

            <div class="section-heading">
                <div>
                    <h2>Accès rapides</h2>
                    <p>Accédez directement aux principales fonctionnalités.</p>
                </div>
            </div>

            <div class="quick-links">

                <a class="quick-link" href="/tp_commande/commandes/liste.php">
                    <span class="quick-link-icon">
                        <i class="fa-solid fa-cart-plus" aria-hidden="true"></i>
                    </span>

                    <span>
                        <strong>Commandes</strong>
                        <small>Consulter et gérer</small>
                    </span>
                </a>

                <a class="quick-link" href="/tp_commande/produits/liste.php">
                    <span class="quick-link-icon">
                        <i class="fa-solid fa-box" aria-hidden="true"></i>
                    </span>

                    <span>
                        <strong>Produits</strong>
                        <small>Gérer le catalogue</small>
                    </span>
                </a>

                <a class="quick-link" href="/tp_commande/clients/liste.php">
                    <span class="quick-link-icon">
                        <i class="fa-solid fa-user-group" aria-hidden="true"></i>
                    </span>

                    <span>
                        <strong>Clients</strong>
                        <small>Consulter les clients</small>
                    </span>
                </a>

                <a class="quick-link" href="/tp_commande/index.php">
                    <span class="quick-link-icon">
                        <i class="fa-solid fa-house" aria-hidden="true"></i>
                    </span>

                    <span>
                        <strong>Accueil</strong>
                        <small>Page de présentation</small>
                    </span>
                </a>

            </div>
        </section>

        <!-- GRAPHIQUES -->
        <section aria-label="Graphiques de suivi">

            <div class="section-heading">
                <div>
                    <h2>Analyse de l'activité</h2>
                    <p>Visualisez les quantités, les montants et l'évolution des commandes.</p>
                </div>
            </div>

            <div class="charts-grid">

                <article class="dashboard-panel chart-panel">
                    <div class="panel-heading">
                        <div>
                            <h2>Produits les plus commandés</h2>
                            <p>Comparaison des quantités par produit</p>
                        </div>

                        <i class="fa-solid fa-chart-column chart-heading-icon"
                           aria-hidden="true"></i>
                    </div>

                    <div class="chart-container">
                        <canvas id="graphiqueProduits"
                                role="img"
                                aria-label="Graphique des quantités commandées par produit">
                        </canvas>
                    </div>
                </article>

                <article class="dashboard-panel chart-panel">
                    <div class="panel-heading">
                        <div>
                            <h2>Répartition des montants</h2>
                            <p>Montants estimés par produit</p>
                        </div>

                        <i class="fa-solid fa-chart-pie chart-heading-icon"
                           aria-hidden="true"></i>
                    </div>

                    <div class="chart-container chart-container-donut">
                        <canvas id="graphiqueMontants"
                                role="img"
                                aria-label="Graphique de répartition des montants par produit">
                        </canvas>
                    </div>
                </article>

                <article class="dashboard-panel chart-panel chart-panel-wide">
                    <div class="panel-heading">
                        <div>
                            <h2>Évolution des commandes</h2>
                            <p>Nombre de commandes enregistrées par mois</p>
                        </div>

                        <i class="fa-solid fa-chart-line chart-heading-icon"
                           aria-hidden="true"></i>
                    </div>

                    <div class="chart-container">
                        <canvas id="graphiqueCommandes"
                                role="img"
                                aria-label="Graphique de l'évolution mensuelle des commandes">
                        </canvas>
                    </div>
                </article>

            </div>
        </section>

        <!-- PERFORMANCE DES PRODUITS -->
        <section class="table-section">

            <article class="dashboard-panel">
                <div class="panel-heading">
                    <div>
                        <h2>Performance des produits</h2>
                        <p>Classement selon la quantité commandée</p>
                    </div>

                    <i class="fa-solid fa-boxes-stacked chart-heading-icon"
                       aria-hidden="true"></i>
                </div>

                <div class="table-wrapper">
                    <table class="app-table">
                        <thead>
                            <tr>
                                <th>Produit</th>
                                <th>Quantité commandée</th>
                                <th>Montant estimé</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php if ($statsProduits): ?>

                            <?php foreach (array_slice($statsProduits, 0, 10) as $produit): ?>
                                <tr>
                                    <td>
                                        <div class="table-primary-text">
                                            <?= e($produit['designProd']) ?>
                                        </div>

                                        <div class="table-secondary-text">
                                            Référence : #<?= (int) $produit['idProd'] ?>
                                        </div>
                                    </td>

                                    <td>
                                        <span class="table-badge">
                                            <?= nombre($produit['quantite']) ?>
                                        </span>
                                    </td>

                                    <td class="table-amount">
                                        <?= montant($produit['montant']) ?> FCFA
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="3" class="empty-state">
                                    <i class="fa-solid fa-chart-simple"
                                       aria-hidden="true"></i>

                                    Aucune donnée disponible pour les produits.
                                    Ajoutez des articles aux commandes pour afficher
                                    les statistiques.
                                </td>
                            </tr>

                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </article>
        </section>

        <!-- DERNIERES COMMANDES -->
        <section class="table-section">

            <article class="dashboard-panel">
                <div class="panel-heading">
                    <div>
                        <h2>Dernières commandes avec articles</h2>
                        <p>Résumé des commandes et de leurs montants estimés</p>
                    </div>

                    <i class="fa-solid fa-receipt chart-heading-icon"
                       aria-hidden="true"></i>
                </div>

                <div class="table-wrapper">
                    <table class="app-table">
                        <thead>
                            <tr>
                                <th>Commande</th>
                                <th>Date</th>
                                <th>Client</th>
                                <th>Quantité totale</th>
                                <th>Montant estimé</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php if ($statsCommandes): ?>

                            <?php foreach (array_slice($statsCommandes, 0, 10) as $commande): ?>
                                <tr>
                                    <td>
                                        <span class="table-badge">
                                            CMD-<?= (int) $commande['idCmd'] ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= e(dateCommande($commande['dateCmd'])) ?>
                                    </td>

                                    <td>
                                        <div class="table-primary-text">
                                            <?= e(trim(
                                                (string) $commande['prenomCli'] . ' ' .
                                                (string) $commande['nomCli']
                                            )) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <?= nombre($commande['quantite']) ?>
                                    </td>

                                    <td class="table-amount">
                                        <?= montant($commande['montant']) ?> FCFA
                                    </td>
                                </tr>
                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="5" class="empty-state">
                                    <i class="fa-solid fa-receipt"
                                       aria-hidden="true"></i>

                                    Aucune commande avec des articles à afficher
                                    pour le moment.
                                </td>
                            </tr>

                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </article>
        </section>

    </div>

    <!-- PIED DE PAGE -->
    <footer class="dashboard-footer">
        <strong>Gestion des commandes</strong>
        <span class="footer-separator">•</span>
        Tableau de bord
        <span class="footer-separator">•</span>
        <?= e(date('Y')) ?>
    </footer>

</main>

<!-- Chart.js : bibliothèque des graphiques -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    const produits = <?= $donneesProduits ?>;
    const commandes = <?= $donneesCommandes ?>;

    const palette = [
        '#3457d5',
        '#22a06b',
        '#f59e0b',
        '#8b5cf6',
        '#06b6d4',
        '#ef4565',
        '#64748b',
        '#d946ef'
    ];

    const formatNombre = valeur =>
        Number(valeur || 0).toLocaleString('fr-FR', {
            maximumFractionDigits: 2
        });

    const formatMontant = valeur =>
        formatNombre(valeur) + ' FCFA';

    /*
     * Affiche un message si aucune donnée n'est disponible.
     */
    function afficherMessageVide(canvas, message) {
        if (!canvas) {
            return;
        }

        const parent = canvas.parentElement;

        if (!parent) {
            return;
        }

        canvas.style.display = 'none';

        const texte = document.createElement('p');

        texte.textContent = message;
        texte.style.position = 'absolute';
        texte.style.inset = '0';
        texte.style.display = 'flex';
        texte.style.alignItems = 'center';
        texte.style.justifyContent = 'center';
        texte.style.padding = '20px';
        texte.style.margin = '0';
        texte.style.color = '#8490a5';
        texte.style.fontSize = '13px';
        texte.style.textAlign = 'center';

        parent.appendChild(texte);
    }

    /*
     * Vérification de la disponibilité de Chart.js.
     */
    if (typeof Chart === 'undefined') {
        console.error(
            'Chart.js est indisponible. Vérifiez la connexion Internet.'
        );

        [
            'graphiqueProduits',
            'graphiqueMontants',
            'graphiqueCommandes'
        ].forEach(function (id) {
            afficherMessageVide(
                document.getElementById(id),
                'Les graphiques sont indisponibles. Vérifiez votre connexion Internet.'
            );
        });

        return;
    }

    Chart.defaults.font.family = '"Segoe UI", Arial, sans-serif';
    Chart.defaults.color = '#8490a5';

    /* GRAPHIQUE 1 : QUANTITES PAR PRODUIT */

    const canvasProduits = document.getElementById('graphiqueProduits');

    if (canvasProduits) {
        if (produits.length === 0) {
            afficherMessageVide(
                canvasProduits,
                'Aucune commande de produit à représenter pour le moment.'
            );
        } else {
            new Chart(canvasProduits, {
                type: 'bar',

                data: {
                    labels: produits.map(p => p.designProd),

                    datasets: [{
                        label: 'Quantité commandée',
                        data: produits.map(p => Number(p.quantite)),
                        backgroundColor: '#3457d5',
                        hoverBackgroundColor: '#2442b0',
                        borderRadius: 7,
                        maxBarThickness: 38
                    }]
                },

                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',

                    plugins: {
                        legend: {
                            display: false
                        },

                        tooltip: {
                            callbacks: {
                                label: function (context) {
                                    return ' Quantité : ' +
                                        formatNombre(context.parsed.x);
                                }
                            }
                        }
                    },

                    scales: {
                        x: {
                            beginAtZero: true,

                            ticks: {
                                precision: 0
                            },

                            grid: {
                                color: '#edf0f6'
                            }
                        },

                        y: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    }

    /* GRAPHIQUE 2 : MONTANTS PAR PRODUIT */

    const canvasMontants = document.getElementById('graphiqueMontants');

    if (canvasMontants) {
        const produitsAvecMontant = produits.filter(
            p => Number(p.montant) > 0
        );

        if (produitsAvecMontant.length === 0) {
            afficherMessageVide(
                canvasMontants,
                'Aucun montant à représenter pour le moment.'
            );
        } else {
            new Chart(canvasMontants, {
                type: 'doughnut',

                data: {
                    labels: produitsAvecMontant.map(p => p.designProd),

                    datasets: [{
                        data: produitsAvecMontant.map(
                            p => Number(p.montant)
                        ),

                        backgroundColor: palette,
                        borderColor: '#ffffff',
                        borderWidth: 3,
                        hoverOffset: 8
                    }]
                },

                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',

                    plugins: {
                        legend: {
                            position: 'bottom',

                            labels: {
                                padding: 15,
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },

                        tooltip: {
                            callbacks: {
                                label: function (context) {
                                    return ' ' + context.label +
                                        ' : ' + formatMontant(context.raw);
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    /* GRAPHIQUE 3 : COMMANDES PAR MOIS */

    const canvasCommandes = document.getElementById('graphiqueCommandes');

    if (canvasCommandes) {
        if (commandes.length === 0) {
            afficherMessageVide(
                canvasCommandes,
                'Aucune commande datée à afficher pour le moment.'
            );
        } else {
            const nomsMois = [
                'Janvier', 'Février', 'Mars', 'Avril',
                'Mai', 'Juin', 'Juillet', 'Août',
                'Septembre', 'Octobre', 'Novembre', 'Décembre'
            ];

            const libellesMois = commandes.map(function (commande) {
                const morceaux = String(commande.mois).split('-');

                if (morceaux.length !== 2) {
                    return commande.mois;
                }

                const annee = morceaux[0];
                const numeroMois = Number(morceaux[1]);

                if (numeroMois < 1 || numeroMois > 12) {
                    return commande.mois;
                }

                return nomsMois[numeroMois - 1] + ' ' + annee;
            });

            new Chart(canvasCommandes, {
                type: 'line',

                data: {
                    labels: libellesMois,

                    datasets: [{
                        label: 'Nombre de commandes',

                        data: commandes.map(
                            c => Number(c.nombre)
                        ),

                        borderColor: '#3457d5',
                        backgroundColor: 'rgba(52, 87, 213, 0.12)',
                        fill: true,
                        tension: 0.35,
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBackgroundColor: '#3457d5'
                    }]
                },

                options: {
                    responsive: true,
                    maintainAspectRatio: false,

                    plugins: {
                        legend: {
                            display: false
                        },

                        tooltip: {
                            callbacks: {
                                label: function (context) {
                                    return ' Commandes : ' +
                                        formatNombre(context.parsed.y);
                                }
                            }
                        }
                    },

                    scales: {
                        y: {
                            beginAtZero: true,

                            ticks: {
                                precision: 0
                            },

                            grid: {
                                color: '#edf0f6'
                            }
                        },

                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    }
});
</script>

</body>
</html>
