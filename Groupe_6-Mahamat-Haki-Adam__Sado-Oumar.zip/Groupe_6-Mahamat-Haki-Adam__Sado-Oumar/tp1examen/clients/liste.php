
<?php
require_once __DIR__ . '/../config/database.php';

$sql = "
    SELECT
        c.idCli,
        c.nomCli,
        c.prenomCli,
        c.email,
        c.photo,
        r.nomRegion,
        d.nomDep
    FROM Client c
    INNER JOIN Region r ON c.idRegion = r.idRegion
    INNER JOIN Departement d ON r.idDep = d.idDep
    ORDER BY c.idCli DESC
";

$stmt = $pdo->query($sql);
$clients = $stmt->fetchAll();

$totalClients = count($clients);
$avecEmail = 0;
$avecPhoto = 0;
$regions = [];

foreach ($clients as $client) {
    if (!empty($client['email'])) {
        $avecEmail++;
    }

    if (!empty($client['photo'])) {
        $avecPhoto++;
    }

    $regions[$client['nomRegion']] = true;
}

$totalRegions = count($regions);

function e($valeur): string
{
    return htmlspecialchars(
        (string) $valeur,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Clients | Gestion des commandes</title>

    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/styles.css">

    <style>
        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
            margin-bottom: 26px;
        }

        .page-heading h1 {
            margin: 0 0 8px;
            font-size: clamp(1.5rem, 3vw, 2rem);
            color: var(--app-text, #202b3c);
        }

        .page-heading p {
            margin: 0;
            color: var(--app-muted, #8490a5);
        }

        .client-stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 26px;
        }

        .client-stat {
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
            padding: 22px;
            min-width: 0;
        }

        .client-stat-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
        }

        .client-stat-label {
            color: #7b8799;
            font-size: .9rem;
        }

        .client-stat-icon {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: #edf2ff;
            color: #3457d5;
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .client-stat strong {
            display: block;
            color: #202b3c;
            font-size: clamp(1.3rem, 2.2vw, 1.8rem);
        }

        .client-panel {
            background: #fff;
            border: 1px solid var(--app-border, #e7ebf3);
            border-radius: 14px;
            overflow: hidden;
        }

        .client-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            padding: 22px;
            border-bottom: 1px solid #edf0f5;
        }

        .client-panel-header h2 {
            margin: 0 0 5px;
            font-size: 1.1rem;
            color: #202b3c;
        }

        .client-panel-header p {
            margin: 0;
            color: #8490a5;
            font-size: .88rem;
        }

        .client-search {
            width: min(100%, 320px);
            padding: 11px 13px;
            border: 1px solid #dfe5ef;
            border-radius: 9px;
            font-size: .9rem;
            outline: none;
        }

        .client-search:focus {
            border-color: #3457d5;
            box-shadow: 0 0 0 3px rgba(52, 87, 213, .10);
        }

        .client-table-wrap {
            overflow-x: auto;
        }

        .client-table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        .client-table th {
            background: #f8f9fc;
            color: #748096;
            font-size: .76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .04em;
            text-align: left;
            padding: 15px 18px;
            white-space: nowrap;
        }

        .client-table td {
            padding: 14px 18px;
            border-top: 1px solid #edf0f5;
            color: #354155;
            vertical-align: middle;
        }

        .client-table tbody tr:hover {
            background: #fafbff;
        }

        .client-id {
            color: #8792a5;
            font-weight: 600;
            font-size: .86rem;
        }

        .client-identity {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 175px;
        }

        .client-avatar {
            width: 43px;
            height: 43px;
            flex-shrink: 0;
            border-radius: 50%;
            display: grid;
            place-items: center;
            background: #e9efff;
            color: #3457d5;
            font-weight: 800;
            overflow: hidden;
        }

        .client-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .client-name {
            color: #202b3c;
            font-weight: 700;
        }

        .client-email {
            color: #3457d5;
            text-decoration: none;
            overflow-wrap: anywhere;
        }

        .client-email:hover {
            text-decoration: underline;
        }

        .client-location {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: #657187;
            white-space: nowrap;
        }

        .client-location i {
            color: #9aa5b6;
        }

        .client-empty {
            padding: 48px 20px;
            text-align: center;
            color: #8490a5;
        }

        .client-empty i {
            display: block;
            margin-bottom: 14px;
            font-size: 2rem;
        }

        .client-footer {
            padding: 16px 22px;
            color: #8490a5;
            font-size: .85rem;
            border-top: 1px solid #edf0f5;
        }

        @media (max-width: 900px) {
            .client-stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 600px) {
            .client-stats {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .client-stat {
                padding: 17px;
            }

            .client-panel-header {
                padding: 17px;
            }

            .client-search {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<?php require __DIR__ . '/../includes/sidebar.php'; ?>

<main class="app-main">

    <div class="page-heading">
        <div>
            <h1>Gestion des clients</h1>
            <p>Consultez les clients et leurs informations géographiques.</p>
        </div>

        <a href="../index.php" class="product-action">
            <i class="fa-solid fa-house"></i>
            Retour à l'accueil
        </a>
    </div>

    <section class="client-stats">

        <article class="client-stat">
            <div class="client-stat-top">
                <span class="client-stat-label">Clients enregistrés</span>
                <span class="client-stat-icon">
                    <i class="fa-solid fa-users"></i>
                </span>
            </div>
            <strong><?= number_format($totalClients, 0, ',', ' ') ?></strong>
        </article>

        <article class="client-stat">
            <div class="client-stat-top">
                <span class="client-stat-label">Clients avec email</span>
                <span class="client-stat-icon">
                    <i class="fa-solid fa-envelope"></i>
                </span>
            </div>
            <strong><?= number_format($avecEmail, 0, ',', ' ') ?></strong>
        </article>

        <article class="client-stat">
            <div class="client-stat-top">
                <span class="client-stat-label">Régions représentées</span>
                <span class="client-stat-icon">
                    <i class="fa-solid fa-map-location-dot"></i>
                </span>
            </div>
            <strong><?= number_format($totalRegions, 0, ',', ' ') ?></strong>
        </article>

    </section>

    <section class="client-panel">

        <div class="client-panel-header">
            <div>
                <h2>Répertoire des clients</h2>
                <p>Informations personnelles et localisation.</p>
            </div>

            <input
                type="search"
                id="rechercheClient"
                class="client-search"
                placeholder="Rechercher un client..."
                aria-label="Rechercher un client"
            >
        </div>

        <?php if ($totalClients > 0): ?>

            <div class="client-table-wrap">
                <table class="client-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Client</th>
                            <th>Email</th>
                            <th>Région</th>
                            <th>Département</th>
                        </tr>
                    </thead>

                    <tbody id="tableauClients">

                    <?php foreach ($clients as $client): ?>
                        <?php
                        $nomComplet = trim(
                            (string) $client['prenomCli'] . ' ' .
                            (string) $client['nomCli']
                        );

                        $initiales = mb_strtoupper(
                            mb_substr((string) $client['prenomCli'], 0, 1, 'UTF-8') .
                            mb_substr((string) $client['nomCli'], 0, 1, 'UTF-8'),
                            'UTF-8'
                        );
                        ?>

                        <tr>
                            <td class="client-id">
                                <?= e($client['idCli']) ?>
                            </td>

                            <td>
                                <div class="client-identity">
                                    <div class="client-avatar">
                                        <?php if (!empty($client['photo'])): ?>
                                            <img
                                                src="<?= e($client['photo']) ?>"
                                                alt="<?= e($nomComplet) ?>"
                                                loading="lazy"
                                            >
                                        <?php else: ?>
                                            <?= e($initiales) ?>
                                        <?php endif; ?>
                                    </div>

                                    <span class="client-name">
                                        <?= e($nomComplet) ?>
                                    </span>
                                </div>
                            </td>

                            <td>
                                <?php if (!empty($client['email'])): ?>
                                    <a
                                        class="client-email"
                                        href="mailto:<?= e($client['email']) ?>"
                                    >
                                        <?= e($client['email']) ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color:#9aa5b6;">Non renseigné</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="client-location">
                                    <i class="fa-solid fa-location-dot"></i>
                                    <?= e($client['nomRegion']) ?>
                                </span>
                            </td>

                            <td>
                                <?= e($client['nomDep']) ?>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

            <div class="client-footer" id="compteurClients">
                <?= number_format($totalClients, 0, ',', ' ') ?>
                client(s) affiché(s)
            </div>

        <?php else: ?>

            <div class="client-empty">
                <i class="fa-solid fa-user-group"></i>
                <strong>Aucun client trouvé</strong>
                <p>Aucun client correspondant aux jointures géographiques n'est enregistré.</p>
            </div>

        <?php endif; ?>

    </section>

    <footer style="text-align:center;color:#8490a5;padding:26px 10px;font-size:.85rem;">
        TP Examen — Gestion d'une ligne de commande
    </footer>

</main>

<script>
const rechercheClient = document.getElementById('rechercheClient');
const tableauClients = document.getElementById('tableauClients');
const compteurClients = document.getElementById('compteurClients');

if (rechercheClient && tableauClients) {
    rechercheClient.addEventListener('input', function () {
        const terme = this.value.trim().toLocaleLowerCase('fr');
        const lignes = Array.from(tableauClients.querySelectorAll('tr'));
        let visibles = 0;

        lignes.forEach(function (ligne) {
            const correspond = ligne.textContent
                .toLocaleLowerCase('fr')
                .includes(terme);

            ligne.hidden = !correspond;

            if (correspond) {
                visibles++;
            }
        });

        if (compteurClients) {
            compteurClients.textContent =
                visibles + ' client(s) affiché(s) sur ' + lignes.length;
        }
    });
}
</script>

</body>
</html>
