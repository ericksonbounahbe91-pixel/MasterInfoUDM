<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| MENU LATERAL PRINCIPAL
|--------------------------------------------------------------------------
| Fichier commun aux pages de l'application.
*/

$scriptActuel = basename($_SERVER['SCRIPT_NAME'] ?? '');

$menuActif = match ($scriptActuel) {
    'index.php' => str_contains(
        str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''),
        '/dashboard/'
    ) ? 'dashboard' : 'accueil',

    'liste.php' => str_contains(
        str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''),
        '/commandes/'
    ) ? 'commandes' : (
        str_contains(
            str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''),
            '/produits/'
        ) ? 'produits' : (
            str_contains(
                str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''),
                '/clients/'
            ) ? 'clients' : ''
        )
    ),

    'facture.php',
    'ajouter_ligne.php',
    'supprimer_ligne.php' => 'commandes',

    'modifier.php' => 'produits',

    default => ''
};
?>

<style>
/* Le menu possède ses propres styles pour ne pas dépendre
   uniquement du fichier styles.css. */

.app-sidebar,
.app-sidebar * {
    box-sizing: border-box;
}

.app-sidebar {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    z-index: 1000;

    display: flex;
    flex-direction: column;

    width: 255px;
    height: 100vh;
    min-height: 100vh;
    padding: 25px 16px 18px;

    overflow-y: auto;

    color: #ffffff;
    background: linear-gradient(180deg, #172554 0%, #101a38 100%);

    font-family: "Segoe UI", Arial, sans-serif;
    box-shadow: 8px 0 30px rgba(15, 23, 42, .08);
}

.sidebar-brand {
    display: flex;
    align-items: center;
    gap: 12px;

    padding: 0 7px 25px;
    border-bottom: 1px solid rgba(255, 255, 255, .12);

    color: #ffffff;
    text-decoration: none;
}

.sidebar-logo {
    display: grid;
    width: 46px;
    height: 46px;
    flex-shrink: 0;
    place-items: center;

    border-radius: 14px;
    color: #ffffff;
    background: linear-gradient(135deg, #5578ff, #3457d5);

    font-size: 21px;
    font-weight: 800;
    box-shadow: 0 6px 16px rgba(52, 87, 213, .35);
}

.sidebar-brand-text {
    min-width: 0;
}

.sidebar-brand-text strong {
    display: block;
    color: #ffffff;
    font-size: 16px;
    font-weight: 800;
    letter-spacing: .2px;
}

.sidebar-brand-text span {
    display: block;
    margin-top: 5px;
    color: #aab8d6;
    font-size: 11px;
}

.sidebar-caption {
    margin: 27px 10px 12px;
    color: #8798bd;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.sidebar-link {
    display: flex;
    align-items: center;
    gap: 13px;

    min-height: 48px;
    padding: 12px 14px;

    color: #c4cde0;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 11px;

    font-size: 13px;
    font-weight: 600;
    text-decoration: none;

    transition:
        background .2s ease,
        color .2s ease,
        border-color .2s ease,
        transform .2s ease;
}

.sidebar-link i {
    display: grid;
    width: 20px;
    flex-shrink: 0;
    place-items: center;
    font-size: 16px;
}

.sidebar-link:hover {
    color: #ffffff;
    background: rgba(255, 255, 255, .08);
    border-color: rgba(255, 255, 255, .05);
    transform: translateX(2px);
}

.sidebar-link.active {
    color: #ffffff;
    background: linear-gradient(
        100deg,
        rgba(69, 104, 235, .95),
        rgba(52, 87, 213, .72)
    );
    border-color: rgba(255, 255, 255, .12);
    box-shadow: 0 5px 15px rgba(0, 0, 0, .12);
}

.sidebar-link.active i {
    color: #ffffff;
}

.sidebar-bottom {
    margin-top: auto;
    padding-top: 25px;
}

.sidebar-status {
    padding: 15px;
    background: rgba(255, 255, 255, .06);
    border: 1px solid rgba(255, 255, 255, .1);
    border-radius: 12px;
}

.sidebar-status-top {
    display: flex;
    align-items: center;
    gap: 9px;
    color: #e2e8f5;
    font-size: 12px;
    font-weight: 700;
}

.sidebar-status-dot {
    width: 8px;
    height: 8px;
    flex-shrink: 0;
    background: #34d399;
    border-radius: 50%;
    box-shadow: 0 0 0 4px rgba(52, 211, 153, .12);
}

.sidebar-status p {
    margin: 9px 0 0;
    color: #9eaccb;
    font-size: 11px;
    line-height: 1.7;
}

.sidebar-copyright {
    margin: 17px 0 0;
    color: #7889ad;
    font-size: 10px;
    text-align: center;
}

/* Tablette */

@media (max-width: 900px) {
    .app-sidebar {
        width: 220px;
        padding: 22px 12px 16px;
    }

    .sidebar-brand-text strong {
        font-size: 14px;
    }

    .sidebar-link {
        gap: 10px;
        padding: 11px;
        font-size: 12px;
    }
}

/* Téléphone */

@media (max-width: 600px) {
    .app-sidebar {
        position: relative;
        top: auto;
        bottom: auto;
        left: auto;

        width: 100%;
        height: auto;
        min-height: auto;

        padding: 15px;
        overflow: visible;
        box-shadow: 0 5px 20px rgba(15, 23, 42, .12);
    }

    .sidebar-brand {
        padding-bottom: 15px;
    }

    .sidebar-caption {
        margin-top: 18px;
    }

    .sidebar-nav {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 7px;
    }

    .sidebar-link {
        min-width: 0;
        min-height: 43px;
        padding: 10px;
        font-size: 12px;
    }

    .sidebar-bottom {
        padding-top: 15px;
    }

    .sidebar-status {
        padding: 12px;
    }

    .sidebar-copyright {
        margin-top: 12px;
    }
}


/* =========================================
   CONTENU PRINCIPAL DES PAGES
   ========================================= */

.app-main {
    min-height: 100vh;
    margin-left: 255px;
    width: calc(100% - 255px);
    padding: 30px;
    box-sizing: border-box;
    min-width: 0;
}

/* Empêcher les éléments de dépasser */
.app-main img,
.app-main input,
.app-main select,
.app-main textarea {
    max-width: 100%;
}

/* Tableaux adaptatifs */
.app-main .table-responsive {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
}

/* Écrans intermédiaires */
@media (max-width: 900px) {
    .app-main {
        margin-left: 220px;
        width: calc(100% - 220px);
        padding: 20px;
    }
}

/* Téléphones */
@media (max-width: 600px) {
    .app-main {
        margin-left: 0;
        width: 100%;
        padding: 16px;
    }
}

</style>

<aside class="app-sidebar">

    <!-- IDENTITE DE L'APPLICATION -->
    <a class="sidebar-brand" href="/tp_commande/dashboard/index.php">
        <span class="sidebar-logo">GC</span>

        <span class="sidebar-brand-text">
            <strong>Gestion Commandes</strong>
            <span>Espace d'administration</span>
        </span>
    </a>

    <!-- NAVIGATION -->
    <p class="sidebar-caption">Menu principal</p>

    <nav class="sidebar-nav" aria-label="Navigation principale">

        <a
            href="/tp_commande/dashboard/index.php"
            class="sidebar-link <?= $menuActif === 'dashboard' ? 'active' : '' ?>"
            <?= $menuActif === 'dashboard' ? 'aria-current="page"' : '' ?>
        >
            <i class="fa-solid fa-gauge-high" aria-hidden="true"></i>
            <span>Tableau de bord</span>
        </a>

        <a
            href="/tp_commande/commandes/liste.php"
            class="sidebar-link <?= $menuActif === 'commandes' ? 'active' : '' ?>"
            <?= $menuActif === 'commandes' ? 'aria-current="page"' : '' ?>
        >
            <i class="fa-solid fa-cart-shopping" aria-hidden="true"></i>
            <span>Commandes</span>
        </a>

        <a
            href="/tp_commande/produits/liste.php"
            class="sidebar-link <?= $menuActif === 'produits' ? 'active' : '' ?>"
            <?= $menuActif === 'produits' ? 'aria-current="page"' : '' ?>
        >
            <i class="fa-solid fa-box-open" aria-hidden="true"></i>
            <span>Produits</span>
        </a>

        <a
            href="/tp_commande/clients/liste.php"
            class="sidebar-link <?= $menuActif === 'clients' ? 'active' : '' ?>"
            <?= $menuActif === 'clients' ? 'aria-current="page"' : '' ?>
        >
            <i class="fa-solid fa-users" aria-hidden="true"></i>
            <span>Clients</span>
        </a>

    </nav>

    <!-- INFORMATIONS EN BAS DU MENU -->
    <div class="sidebar-bottom">

        <div class="sidebar-status">
            <div class="sidebar-status-top">
                <span class="sidebar-status-dot"></span>
                Application disponible
            </div>

            <p>
                Gestion locale des clients, produits et commandes.
            </p>
        </div>

        <p class="sidebar-copyright">
            &copy; <?= date('Y') ?> Gestion Commandes
        </p>

    </div>

</aside>
