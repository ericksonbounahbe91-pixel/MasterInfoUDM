<?php
require 'config.php';
$id = $_GET['id'] ?? '';
$etu = ['idEtu'=>'','nomEtu'=>'','prenomEtu'=>'','dateNaiss'=>'','emailEtu'=>'','numTelEtu'=>'','regEtu'=>'','departEtu'=>'','arrondisEtu'=>'','mentionEtu'=>'','cycleEtu'=>'','ParcoursEtu'=>''];
if($id){ $s=$pdo->prepare('SELECT * FROM etudiant WHERE idEtu=?'); $s->execute([$id]); $etu=$s->fetch()?:$etu; }
if($_SERVER['REQUEST_METHOD']=='POST'){
 $d=[ $_POST['idEtu'], $_POST['nomEtu'], $_POST['prenomEtu'], $_POST['dateNaiss'], $_POST['emailEtu'], $_POST['numTelEtu'], $_POST['regEtu'], $_POST['departEtu'], $_POST['arrondisEtu'], $_POST['mentionEtu'], $_POST['cycleEtu'], $_POST['ParcoursEtu'] ];
 if(!empty($_POST['id_original'])){
  $pdo->prepare('UPDATE etudiant SET idEtu=?,nomEtu=?,prenomEtu=?,dateNaiss=?,emailEtu=?,numTelEtu=?,regEtu=?,departEtu=?,arrondisEtu=?,mentionEtu=?,cycleEtu=?,ParcoursEtu=? WHERE idEtu=?')->execute([...$d,$_POST['id_original']]);
 }else{
  $pdo->prepare('INSERT INTO etudiant(idEtu,nomEtu,prenomEtu,dateNaiss,emailEtu,numTelEtu,regEtu,departEtu,arrondisEtu,mentionEtu,cycleEtu,ParcoursEtu) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')->execute($d);
 }
 header('Location: index.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>Formulaire</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial}
body{background:#eef4ff}
.header{background:#083d77;color:white;padding:12px 25px}
.header a{color:white;text-decoration:none;margin-left:15px;font-size:13px}
.box{display:flex;justify-content:center;padding:20px}
.card{background:white;width:100%;max-width:500px;padding:25px;border-radius:10px;box-shadow:0 5px 20px rgba(0,0,0,.1)}
h2{text-align:center;color:#083d77;font-size:18px;margin-bottom:15px}
label{font-size:12px;font-weight:bold;display:block;margin-top:12px;margin-bottom:3px}
input,select{width:100%;padding:9px;border:1px solid #ccc;border-radius:6px;font-size:13px}
.section{background:#eef4ff;border-left:4px solid #083d77;padding:6px 10px;margin-top:18px;font-size:11px;font-weight:bold;color:#083d77}
.btns{display:flex;gap:10px;margin-top:20px}
.btn{flex:1;padding:10px;text-align:center;border-radius:6px;text-decoration:none;font-weight:bold;border:none;cursor:pointer;font-size:13px}
.save{background:#083d77;color:white}.cancel{background:#eee;color:#333}
</style>
</head>
<body>
<div class="header"><b>TP1 - Gestion Etudiants</b> <a href="index.php">Tableau de bord</a></div>
<div class="box"><div class="card">
<h2>Ajouter un nouveau Etudiant</h2>
<form method="post">
<?php if($id): ?><input type="hidden" name="id_original" value="<?= htmlspecialchars($id) ?>"><?php endif; ?>

<div class="section">1. IDENTIFICATION</div>
<label>Matricule</label><input type="text" name="idEtu" value="<?= htmlspecialchars($etu['idEtu']) ?>" required>
<label>Nom</label><input type="text" name="nomEtu" value="<?= htmlspecialchars($etu['nomEtu']) ?>" required>
<label>Prénom</label><input type="text" name="prenomEtu" value="<?= htmlspecialchars($etu['prenomEtu']) ?>" required>
<label>Date de Naissance</label><input type="date" name="dateNaiss" value="<?= htmlspecialchars($etu['dateNaiss']) ?>" required>

<div class="section">2. CONTACT & ORIGINE</div>
<label>Email</label><input type="email" name="emailEtu" value="<?= htmlspecialchars($etu['emailEtu']) ?>" required>
<label>Téléphone</label><input type="text" name="numTelEtu" value="<?= htmlspecialchars($etu['numTelEtu']) ?>" required>
<label>Région</label><input type="text" name="regEtu" value="<?= htmlspecialchars($etu['regEtu']) ?>" required>
<label>Département</label><input type="text" name="departEtu" value="<?= htmlspecialchars($etu['departEtu']) ?>" required>
<label>Arrondissement</label><input type="text" name="arrondisEtu" value="<?= htmlspecialchars($etu['arrondisEtu']) ?>" required>

<div class="section">3. ACADEMIQUE</div>
<label>Cycle</label><select name="cycleEtu" required><option value="">-- Choisir --</option><option <?= $etu['cycleEtu']=='Licence 1'?'selected':'' ?>>Licence 1</option><option <?= $etu['cycleEtu']=='Licence 2'?'selected':'' ?>>Licence 2</option><option <?= $etu['cycleEtu']=='Licence 3'?'selected':'' ?>>Licence 3</option><option <?= $etu['cycleEtu']=='Master 1'?'selected':'' ?>>Master 1</option><option <?= $etu['cycleEtu']=='Master 2'?'selected':'' ?>>Master 2</option></select>
<label>Mention</label><input type="text" name="mentionEtu" value="<?= htmlspecialchars($etu['mentionEtu']) ?>" required>
<label>Parcours</label><input type="text" name="ParcoursEtu" value="<?= htmlspecialchars($etu['ParcoursEtu']) ?>" required>

<div class="btns"><a href="index.php" class="btn cancel">Annuler</a><button type="submit" class="btn save">Enregistrer</button></div>
</form>
</div></div>
</body></html>