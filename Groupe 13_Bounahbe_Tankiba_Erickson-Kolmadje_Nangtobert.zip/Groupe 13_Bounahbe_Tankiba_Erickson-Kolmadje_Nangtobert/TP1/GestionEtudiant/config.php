<?php
define('CHAMPS', ['idEtu','nomEtu','prenomEtu','dateNaiss','emailEtu','numTelEtu','regEtu','departEtu','arrondisEtu','mentionEtu','cycleEtu','ParcoursEtu']);
function h($s){ return htmlspecialchars($s?? '', ENT_QUOTES, 'UTF-8'); }
$host='localhost'; $db='MasTMonde'; $user='root'; $pass=''; $charset='utf8mb4';
$dsn="mysql:host=$host;dbname=$db;charset=$charset";
$pdo=new PDO($dsn,$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
?>