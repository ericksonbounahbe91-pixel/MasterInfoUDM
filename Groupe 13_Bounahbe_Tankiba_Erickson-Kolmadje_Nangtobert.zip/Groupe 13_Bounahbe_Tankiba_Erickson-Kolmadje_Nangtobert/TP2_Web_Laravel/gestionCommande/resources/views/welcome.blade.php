<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion Commande</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Inter',sans-serif;background:#eceef2;letter-spacing:-0.2px}
.card{box-shadow:0 2px 12px rgba(0,0,0,0.06);border:1px solid #f0f0f0}
</style>
</head>
<body class="p-6">
<div class="max-w-[1400px] mx-auto flex gap-6">
<!-- SIDEBAR -->
<aside class="w-[220px] bg-white rounded-2xl card p-5 flex flex-col justify-between h-[820px]">
<div>
<div class="flex items-center gap-2 mb-8">
<div class="w-9 h-9 bg-black rounded-lg flex items-center justify-center text-white font-black text-[20px]">G<div class="w-4 h-4 bg-[#ff1f1f] rounded-full text-[9px] flex items-center justify-center -mt-2 ml-0.5">G</div></div>
<div class="font-extrabold text-[14px] leading-[1]">Gestion<br>Commande</div>
</div>
<p class="text-[10px] font-bold text-gray-400 tracking-widest mb-3">MENU</p>
<div class="space-y-1 text-[13px]">
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-500 font-medium"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 11h-2"/><path d="M20 9v4"/></svg>Clients</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-500 font-medium"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>Produits</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-[#ffe5e7] text-[#c21e1e] font-bold border-l-[4px] border-red-500"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M9 8h6"/><path d="M9 12h6"/><path d="M9 16h4"/></svg>Commandes</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-gray-500 font-medium"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Factures</a>
</div>
</div>
<div class="border-t pt-4">
<div class="flex items-center gap-2"><img src="https://i.pravatar.cc/40?img=68" class="w-8 h-8 rounded-full"><div><div class="text-[12px] font-bold">Admin</div><div class="text-[10px] text-gray-400">admin@gestioncommande.fr</div></div></div>
<div class="mt-4 flex items-center gap-2 text-[12px] text-gray-400 font-medium">↔ Déconnexion</div>
</div>
</aside>

<!-- MAIN -->
<main class="flex-1">
<div class="flex justify-between items-center mb-5">
<div><h1 class="text-[24px] font-extrabold">Commandes</h1><p class="text-[11px] text-gray-500 font-medium">Tableau de bord / Commandes</p></div>
<div class="flex items-center gap-3"><div class="bg-white card rounded-full px-4 py-2 text-[11px] text-gray-500 flex items-center gap-2 w-[260px]"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="6"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>Rechercher une commande...</div><div class="bg-white card w-8 h-8 rounded-full flex items-center justify-center">🔔</div><div class="bg-white card w-8 h-8 rounded-full flex items-center justify-center">⚙️</div></div>
</div>

<div class="grid grid-cols-4 gap-4 mb-5">
<div class="bg-white rounded-xl card p-4 flex gap-3 items-center"><div class="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-blue-600"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg></div><div><div class="text-[11px] bg-gray-100 px-2 py-0.5 rounded font-semibold inline-block">Total Commandes</div><div class="text-[22px] font-extrabold">124</div><div class="text-[11px] text-green-600 font-bold">+12% ce mois ↗</div></div></div>
<div class="bg-white rounded-xl card p-4 flex gap-3 items-center"><div class="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center text-green-600"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg></div><div><div class="text-[11px] bg-gray-100 px-2 py-0.5 rounded font-semibold inline-block">Chiffre d'affaires</div><div class="text-[22px] font-extrabold">12 450 €</div><div class="text-[11px] text-green-600 font-bold">+8% ce mois</div></div></div>
<div class="bg-white rounded-xl card p-4 flex gap-3 items-center"><div class="w-10 h-10 bg-orange-50 rounded-full flex items-center justify-center text-orange-500"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div><div class="text-[11px] bg-gray-100 px-2 py-0.5 rounded font-semibold inline-block">En cours</div><div class="text-[22px] font-extrabold">18</div><div class="text-[11px] text-orange-500 font-bold">3 en attente</div></div></div>
<div class="bg-white rounded-xl card p-4 flex gap-3 items-center"><div class="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center text-purple-600"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg></div><div><div class="text-[11px] bg-gray-100 px-2 py-0.5 rounded font-semibold inline-block">Clients</div><div class="text-[22px] font-extrabold">56</div><div class="text-[11px] text-green-600 font-bold">+5 nouveaux</div></div></div>
</div>

<div class="flex gap-5">
<div class="flex-1 bg-white rounded-xl card p-5">
<div class="flex justify-between items-center mb-4"><h2 class="font-bold text-[16px]">Liste des commandes</h2><button class="bg-[#e53935] hover:bg-red-600 text-white text-[11px] font-bold px-4 py-2 rounded-lg">+ Nouvelle Commande</button></div>
<table class="w-full text-[12px]"><thead><tr class="bg-[#f7f7f8] text-[11px] text-gray-500 font-semibold"><th class="text-left p-2.5 rounded-l-lg">ID</th><th class="text-left p-2.5">Client</th><th class="text-left p-2.5">Date</th><th class="text-left p-2.5">Montant</th><th class="text-left p-2.5">Statut</th><th class="text-left p-2.5 rounded-r-lg">Action</th></tr></thead>
<tbody class="font-medium">
<tr class="border-b border-gray-100"><td class="p-3 font-bold">#CMD-1024</td><td>Sophie Martin</td><td>12/10/2024</td><td>350,00 €</td><td><span class="bg-[#16a34a] text-white px-3 py-1 rounded-full text-[10px] font-bold">✔ Livrée</span></td><td>•••</td></tr>
<tr class="border-b border-gray-100"><td class="p-3 font-bold">#CMD-1023</td><td>Lucas Bernard</td><td>12/10/2024</td><td>120,50 €</td><td><span class="bg-white border border-blue-500 text-blue-600 px-3 py-1 rounded-full text-[10px] font-bold">◷ En cours</span></td><td>•••</td></tr>
<tr class="border-b border-gray-100"><td class="p-3 font-bold">#CMD-1022</td><td>Emma Dubois</td><td>11/10/2024</td><td>89,00 €</td><td><span class="bg-[#fef3c7] border border-yellow-400 text-yellow-800 px-3 py-1 rounded-full text-[10px] font-bold">◷ En attente</span></td><td>•••</td></tr>
<tr class="border-b border-gray-100"><td class="p-3 font-bold">#CMD-1021</td><td>Paul Lefevre</td><td>10/10/2024</td><td>540,00 €</td><td><span class="bg-[#16a34a] text-white px-3 py-1 rounded-full text-[10px] font-bold">✔ Livrée</span></td><td>•••</td></tr>
<tr><td class="p-3 font-bold">#CMD-1020</td><td>Camille Renault</td><td>09/10/2024</td><td>210,00 €</td><td><span class="bg-white border border-red-500 text-red-600 px-3 py-1 rounded-full text-[10px] font-bold">✕ Annulée</span></td><td>•••</td></tr>
</tbody></table>
</div>

<div class="w-[360px] space-y-5">
<div class="bg-white rounded-xl card p-5"><h3 class="font-bold text-[14px] mb-2">Ventes des 7 derniers jours</h3><svg viewBox="0 0 300 80" class="w-full h-[85px]"><polyline fill="none" stroke="#dc2626" stroke-width="2" points="5,60 30,58 70,35 110,50 140,45 180,10 220,30 260,35 285,32"/><circle cx="180" cy="10" r="4" fill="#dc2626"/></svg><div class="flex justify-between text-[10px] text-gray-400 mt-1 font-medium"><span>Lun 07</span><span>Mar 08</span><span>Mer 09</span><span>Jeu 10</span><span>Ven 11</span><span>Sam 12</span><span>Dim 13</span></div></div>
<div><h3 class="font-bold text-[14px] mb-3">Produits populaires</h3><div class="grid grid-cols-3 gap-3">
<div class="bg-white rounded-xl card p-2"><div class="bg-[#f5f5f7] rounded-lg h-[70px] flex items-center justify-center"><img src="https://cdn-icons-png.flaticon.com/512/548/548203.png" class="w-10 h-10 object-contain"></div><p class="text-[10px] font-bold mt-2 leading-tight">Casque Bluetooth Pro</p><p class="text-[#dc2626] font-extrabold text-[12px]">89,00 €</p><p class="text-[8px] text-gray-400">Stock: 24 • En stock</p></div>
<div class="bg-white rounded-xl card p-2"><div class="bg-[#f5f5f7] rounded-lg h-[70px] flex items-center justify-center"><img src="https://cdn-icons-png.flaticon.com/512/3652/3652191.png" class="w-10 h-10 object-contain"></div><p class="text-[10px] font-bold mt-2 leading-tight">Montre Connectée X2</p><p class="text-[#dc2626] font-extrabold text-[12px]">149,00 €</p><p class="text-[8px] text-gray-400">Stock: 12 • En stock</p></div>
<div class="bg-white rounded-xl card p-2"><div class="bg-[#f5f5f7] rounded-lg h-[70px] flex items-center justify-center"><img src="https://cdn-icons-png.flaticon.com/512/1087/1087815.png" class="w-8 h-8 object-contain"></div><p class="text-[10px] font-bold mt-2 leading-tight">Souris Sans Fil</p><p class="text-[#dc2626] font-extrabold text-[12px]">35,00 €</p><p class="text-[8px] text-gray-400">Stock: 5 • Stock faible</p></div>
</div></div>
</div>
</div>
<p class="text-center text-[11px] text-gray-500 mt-6 font-medium">Gestion Commande — v1.2.0 • Laravel 10 • © 2024 Tous droits réservés</p>
</main>
</div>
</body>
</html>