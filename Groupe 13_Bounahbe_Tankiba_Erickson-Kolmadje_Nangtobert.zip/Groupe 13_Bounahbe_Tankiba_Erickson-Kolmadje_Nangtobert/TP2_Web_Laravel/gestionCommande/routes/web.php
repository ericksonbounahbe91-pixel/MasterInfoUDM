<?php
use App\Http\Controllers\CommandeController;
Route::get('/', [CommandeController::class, 'index']);
Route::get('/commandes', [CommandeController::class, 'index']);